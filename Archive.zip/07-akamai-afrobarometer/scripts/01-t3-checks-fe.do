
*cd "C:\Users\jacci\Dropbox (Personal)\internet_replication\replies-to-replicators\09-akamai-afrobarometer"
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
clear all
set more off

* dhs
* please note that dhs data must be applied for

use "${pathdataraw}\dhs_res_final.dta"

* grid size
glo	gridsize10 = 0.1 // side of each square in degrees
* generate grid cell variable
g 	latitude_grid10 = 100*${gridsize10}*round(latitude/${gridsize10})
g 	longitude_grid10 = 100*${gridsize10}*round(longitude/${gridsize10})
tostring latitude_grid10 longitude_grid10, replace force
g 	grid10 = latitude_grid10 + "_" + longitude_grid10

* country x time FE's
drop country_year
egen country_year = group(country year)
egen country_quarter = group(country time)
* grid-cell x connected FE's
drop grid_connect
egen grid_connect = group(grid10 connected)

areg employed treatment i.country_quarter if distance < 0.1, a(grid_connect) cluster(grid10)
estadd ysumm, mean
eststo reg1


clear

* afrobarometer
* please note that lowest level afrobarometer geo info must be applied for

use "${pathdataraw}\afro_res_final.dta"

* country x time FE's
drop country_year
egen country_year = group(country year)
egen country_quarter = group(country time)
* grid-cell x connected FE's
drop grid_connect
egen grid_connect = group(grid10 connected)


areg employed treatment i.country_quarter if employment != -9 & age < 65 & distance < 0.1, a(grid_connect) cluster(grid10)
estadd ysumm, mean
eststo reg2



clear

* sa-qlfs

use "${pathdataraw}\qlfs_final.dta"


areg employed treatment i.time if time < 20103 & distance < 0.1, a(eacode) cluster(eacode)
estadd ysumm, mean
eststo reg3

replace loghours = ln(hoursworked + (hoursworked^2 + 1)^(1/2))
replace loghours = 0 if hoursworked == . & employed == 0

areg loghours treatment i.time if time < 20103 & distance < 0.1, a(eacode) cluster(eacode)
estadd ysumm, mean
eststo reg11

areg morework treatment i.time if time < 20103 & distance < 0.1, a(eacode) cluster(eacode)
estadd ysumm, mean
eststo reg22


areg formal treatment i.time if time < 20103 & distance < 0.1, a(eacode) cluster(eacode)
estadd ysumm, mean
eststo reg33

areg informal treatment i.time if time < 20103 & distance < 0.1, a(eacode) cluster(eacode)
estadd ysumm, mean
eststo reg44

label var treatment "\textbf{SubmarineCables $\times$ Connected}"

esttab reg1 reg2 reg3 , replace se b(3) stats(N ymean, fmt(0  %9.2f)  labels("Observations" "Mean of Outcome")) label alignment(center) nogaps fragment nonumbers mlabels(none) drop(*quarter* *time* _cons) collabels()  nocon starlevels(* 0.10 ** 0.05 *** 0.01) nolines
esttab reg1 reg2 reg3 using "${pathtab}\t3a.tex", replace se b(3) stats(N ymean, fmt(0  %9.2f)  labels("Observations" "Mean of Outcome")) label alignment(center) nogaps fragment nonumbers mlabels(none) drop(*quarter* *time* _cons) collabels()  nocon starlevels(* 0.10 ** 0.05 *** 0.01) nolines
*esttab reg11 reg22 reg33 reg44 using "t3b.tex", replace se b(3) stats(N ymean, fmt(0  %9.2f)  labels("Observations" "Mean of Outcome")) label alignment(center) nogaps fragment nonumbers mlabels(none) drop(*time* _cons) collabels()  nocon starlevels(* 0.10 ** 0.05 *** 0.01) nolines
