
*cd "C:\Users\jacci\Dropbox (Personal)\internet_replication\replies-to-replicators\09-akamai-afrobarometer"
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

** Column 4-7
use "${pathdataraw}\afro_internet.dta", clear
keep if country == "BJ" | country == "GH" | country == "KE" | country == "MG" | country == "MZ" | country == "NG" | country == "SN" | country == "TZ" | country == "ZA"

* drop large cities so that only smaller cities/towns/villages are used in the analysis
gen large = 1 if city == "BUJUMBURA" | city == "GABORONE" | city == "FRANCISTOWN" |  city == "KINSHASA" | city == "LUBUMBASHI" | city == "MBUJIMAYI" | city == "DJIBOUTI" |  city == "ADISABEBA" |  city == "NAIROBI" | city == "MOMBASA" | city == "KISUMU" |  city == "MORONI" | city == "ANTANANARIVO" |  city == "LILONGWE" | city == "BLANTYRE" |  city == "MAPUTO" | city == "BEIRA" |  city == "WINDHOEK" | city == "WALVISBAY" | city == "KIGALI" | city == "KHARTOUM" | city == "PORTSUDAN" | city == "MOGADISHU" | city == "HARGEISA" | city == "BOSASO" | city == "DARESSALAAM" | city == "MWANZA" | city == "ARUSHA" | city == "KAMPALA" | city == "JOHANNESBURG" | city == "PRETORIA" | city == "DURBAN" | city == "LUSAKA" | city == "NDOLA" | city == "KITWE" | city == "HARARE" | city == "BULAWAYO" | city == "LUANDA" | city == "HUAMBO" | city == "LOBITO" | city == "COTONOU" | city == "ABOMEY" | city == "DJOUGOU" | city == "KINSHASA" | city == "LUBUMBASHI" | city == "MBUJIMAYI" | city == "ABIDJAN" | city == "BOUAKE" | city == "DOUALA" | city == "YAOUNDE" | city == "LIBREVILLE" | city == "PORTGENTIL" | city == "FRANCEVILLE" | city == "ACCRA" | city == "KUMASI" | city == "TAMALE" | city == "SERREKUNDA" | city == "CAMAYENNE" | city == "CONAKRY" | city == "NZEREKORE" | city == "BATA" | city == "MALABO" | city == "MONROVIA" | city == "NOUAKCHOTT" | city == "NOUADHIBOU" | city == "WINDHOEK" | city == "WALVISBAY" | city == "LAGOS" | city == "KANO" | city == "IBADAN" | city == "FREETOWN" | city == "BO" | city == "DAKAR" | city == "NEVES" | city == "SAOTOME" | city == "ACCRA" | city == "KUMASI" | city == "TAMALE" | city == "CASABLANCA" | city == "RABAT" | city == "FES" | city == "NOUAKCHOTT" | city == "NOUADHIBOU" | city == "LAGOS" | city == "KANO" | city == "IBADAN" | city == "DAKAR" | city == "PORTLOUIS" | city == "VACOAS" | city == "CUREPIPE" | city == "NAIROBI" | city == "MOMBASA" | city == "KISUMU" | city == "OUAGADOUGOU" | city == "BOBODIOULASSO" | city == "COTONOU" | city == "ABOMEY" | city == "DJOUGOU" | city == "ABIDJAN" | city == "BOUAKE" | city == "ACCRA" | city == "KUMASI" | city == "TAMALE" | city == "CASABLANCA" | city == "RABAT" | city == "FES" | city == "LAGOS" | city == "KANO" | city == "IBADAN" | city == "DAKAR" | city == "LOME" | city == "DJIBOUTI" | city == "NAIROBI" | city == "MOMBASA" | city == "KISUMU" | city == "MAPUTO" | city == "BEIRA" | city == "DARESSALAAM" | city == "MWANZA" | city == "ARUSHA" | city == "KINSHASA" | city == "LUBUMBASHI" | city == "MBUJIMAYI" | city == "NAIROBI" | city == "MOMBASA" | city == "KISUMU" | city == "KIGALI" | city == "KAMPALA" | city == "JOHANNESBURG" | city == "PRETORIA" | city == "DURBAN" | city == "HARARE" | city == "BULAWAYO" | city == "NAIROBI" | city == "MOMBASA" | city == "KISUMU" | city == "LUANDA" | city == "HUAMBO" | city == "LOBITO" | city == "KINSHASA" | city == "LUBUMBASHI" | city == "MBUJIMAYI" | city == "BRAZZAVILLE" | city == "POINTENOIRE" | city == "ABIDJAN" | city == "BOUAKE" | city == "DOUALA" | city == "YAOUNDE" | city == "PRAIA" | city == "LIBREVILLE" | city == "PORTGENTIL" | city == "FRANCEVILLE" | city == "ACCRA" | city == "KUMASI" | city == "TAMALE" | city == "WINDHOEK" | city == "WALVISBAY" | city == "LAGOS" | city == "KANO" | city == "IBADAN" | city == "LOME" | city == "CAPETOWN" | city == "CLAREMONT" | city == "GREENPOINT" | city == "MARSHALLTOWN" | city == "SILVERTON" | city == "WAVERLEY" | city == "WAVERLY" | city == "ABUJA" | city == "BLOEMFONTEIN" | city == "KWAZULU" | city == "MPUMALANGA" | city == "HELDERBERG" | city == "LONDON" | city == "LYNNWOOD" | city == "MEDUNSA" | city == "MIDRAND" | city == "MODDERFONTEIN" | city == "NEWLANDS" | city == "PARKVIEW" | city == "RIVONIA" | city == "ROSSLYN" | city == "WYNBERG"
replace large = 0 if large == .

* country x time FE's
egen country_year = group(country year)

* country x time FE's
egen country_quarter= group(country time)

gen connected = (distance<0.005)

* nonlinear trends
cap drop dtime*
tab time, gen(dtime)
forvalues i = 1/9 {
gen difftrends`i' = dtime`i' * connected
}
replace submarines = (submarines>0)
gen treatment = submarines*connected

cap drop useinternet
cap drop anyuse
** internet  
est clear
gen useinternet = (inlist(internet,4))   if !inlist(internet,-1,9)
gen anyuse      = (inlist(internet,3,4)) if !inlist(internet,-1,9)

*est clear
areg useinternet treatment i.country_quarter if internet != 9 & internet != -1 & large == 0 & distance < 0.1  , a(city) cluster(city)
estadd ysumm, mean
eststo reg4
gen sample = e(sample)
areg useinternet treatment difftrends* i.country_quarter if internet != 9 & internet != -1 & large == 0 & distance < 0.1, a(city) cluster(city)
estadd ysumm, mean
eststo reg5


areg anyuse treatment i.country_quarter if internet != 9 & internet != -1 & large == 0 & distance < 0.1, a(city) cluster(city)
estadd ysumm, mean
eststo reg6

areg anyuse treatment difftrends* i.country_quarter if internet != 9 & internet != -1 & large == 0 & distance < 0.1, a(city) cluster(city)
estadd ysumm, mean
eststo reg7



label var treatment "\textbf{SubmarineCables $\times$ Connected}"

esttab reg4 reg5 reg6 reg7 using "${pathtab}\t2.tex", replace se b(3) stats(N ymean, fmt(0  %9.2f) labels("Observations" "Mean of Outcome")) label alignment(center) nogaps fragment nonumbers mlabels(none) drop(*quarter* *trends* _cons) collabels()  nocon starlevels(* 0.10 ** 0.05 *** 0.01) nolines