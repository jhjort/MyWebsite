*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
version 17.0
*version 18.0
clear all
macro drop _all 
cap log close

********************************************************************************
** # 0. Setting 
********************************************************************************

local PC = "EGUIO"

if "`PC'"=="EG"{
	global id = "C:\Users\ASUS\Dropbox\internet_replication\newpackage\replies-to-replicators\07-akamai-afrobarometer"
} 
if "`PC'"=="EGUIO"{
	global id = "C:\Users\emiliogu\Dropbox\internet_replication\newpackage\replies-to-replicators\07-akamai-afrobarometer"
} 

cd "${id}"
global pathdo 	   = "${id}\scripts"
global pathtemp    = "${id}\processed"
global pathout 	   = "${id}\results"
global pathfig	   = "${id}\results\Figures"
global pathtab     = "${id}\results\Tables"
global pathdataraw = "${id}\raw_data"
global pathdata    = "${id}\final"

* Folders creation
cap mkdir "${pathdo}"
cap mkdir "${pathtemp}"
cap mkdir "${pathout}"
cap mkdir "${pathfig}"
cap mkdir "${pathtab}"
cap mkdir "${pathdata}"
cap mkdir "${pathdataraw}"


********************************************************************************
* # 1.- Tables and Figures
********************************************************************************

* # 01-t2-checks-fe
do "${pathdo}\01-t2-checks-fe.do"
*Produces t2.tex

* # 01-t3-checks-fe
do "${pathdo}\01-t3-checks-fe.do"
*Produces t3a.tex
