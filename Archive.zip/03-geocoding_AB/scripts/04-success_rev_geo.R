# Compute success rate of reverse geocoding (MAPS; OSM; GEONAMES)
# using the townvill/district/region string as per the AER information

# Set working directory - and clean environment
rm(list=ls())
setwd("C:/Users/emiliogu/Dropbox") # DB directory
#setwd("C:/Users/ASUS/Dropbox") # DB directory

# Load required packages
library(dplyr)

# Load data and 3 versions
full <- read.csv("internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/processed/reverse_n_all-sample.csv")
full <- full %>% mutate(across(everything(), ~ifelse(. == "", NA, .))) # make empty strings NAs
full <- full %>% subset(country %in% c("BJ", "GH", "KE", "MG", "MZ", "NG", "SN", "TZ", "ZA")) # drop outside of 9 countries
intersection <- full %>% subset(type_of_sample == "Matched (3)")
aid_only <- full %>% subset(type_of_sample == "Master only (1)")
t3 <- read.csv("internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/processed/reverse_n_enteringT3.csv")
t3 <- t3 %>% mutate(across(everything(), ~ifelse(. == "", NA, .))) # make empty strings NAs

# Define function checking for match row by row (delete brackets, accents, etc.)
grepl_loop <- function(pattern_vec, string_vec) {
  # Initialize an empty logical vector to store the results
  result <- logical(length(pattern_vec))
  
  # Drop accents
  pattern_vec <- iconv(tolower(pattern_vec), from = "UTF-8", to = "ASCII//TRANSLIT")
  string_vec <- iconv(tolower(string_vec), from = "UTF-8", to = "ASCII//TRANSLIT")
  
  # Loop over each element of pattern_vec and string_vec
  for (i in seq_along(pattern_vec)) {
    # If the pattern is not NA, escape any special regex characters
    if (!is.na(pattern_vec[i])) {
      pattern_vec[i] <- gsub("([().])", "\\\\\\1", pattern_vec[i])
    }
    
    # If string_vec[i] is NA, then result[i] is NA
    if (is.na(string_vec[i])) {
      result[i] <- NA
    } else {
      # Apply grepl() to the i-th elements of pattern_vec and string_vec
      result[i] <- grepl(pattern_vec[i], string_vec[i], ignore.case = TRUE)
    }
  }
  
  return(result)
}
# Extract stats on vectors with grepl_loop()
stats <- function(vector) {
  # Remove NA's
  vector <- vector %>% subset(!is.na(vector))
  # Compute statistics - and assemble in dataframe
  data <- data.frame(c(paste0(sprintf("%.2f", sum(vector)/length(vector)*100), "\\%"), # success (%) with 2 decimal points
                       sprintf("%.0f", length(vector)))) # no. obs. with no decimal point
  return(data)
}
# Construct vectors with info they geocoded for - AER: note/town; AID: place_name
int_note_town <- ifelse(!is.na(intersection$note), intersection$note, intersection$townvill) # note when available, town o/w
int_place_name <- intersection$place_nameAID
aid_place_name <- aid_only$place_nameAID
t3_note_town <- ifelse(!is.na(t3$note), t3$note, t3$townvill)
t3_place_name <- t3$place_nameaid

# Check success rate across 3 datasets (for AER and AID)
success_int_AER <- cbind(stats(grepl_loop(int_note_town, intersection$reverse_AER_maps)),
                         stats(grepl_loop(int_note_town, intersection$reverse_AER_osm)),
                         stats(grepl_loop(int_note_town, intersection$reverse_AER_geonames)),
                         row.names = c("Success (%)", "No. of Obs."))
success_int_AID <- cbind(stats(grepl_loop(int_place_name, intersection$reverse_AID_maps)),
                         stats(grepl_loop(int_place_name, intersection$reverse_AID_osm)),
                         stats(grepl_loop(int_place_name, intersection$reverse_AID_geonames)),
                         row.names = c("Success (%)", "No. of Obs."))


success_aid_AID <- cbind(stats(grepl_loop(aid_place_name, aid_only$reverse_AID_maps)),
                         stats(grepl_loop(aid_place_name, aid_only$reverse_AID_osm)),
                         stats(grepl_loop(aid_place_name, aid_only$reverse_AID_geonames)), 
                         row.names = c("Success (%)", "No. of Obs."))

success_t3_AER <- cbind(stats(grepl_loop(t3_note_town, t3$reverse_aer_maps)),
                        stats(grepl_loop(t3_note_town, t3$reverse_aer_osm)),
                        stats(grepl_loop(t3_note_town, t3$reverse_aer_geonames)),
                        row.names = c("Success (%)", "No. of Obs."))
success_t3_AID <- cbind(stats(grepl_loop(t3_place_name, t3$reverse_aid_maps)),
                        stats(grepl_loop(t3_place_name, t3$reverse_aid_osm)),
                        stats(grepl_loop(t3_place_name, t3$reverse_aid_geonames)),
                        row.names = c("Success (%)", "No. of Obs."))

# Convert to .tex format the two tables
table_tex <- function(row_names, tab) {
  create_latex_row <- function(row) {
    # Add '&' separator and ' \\' for line break in LaTeX
    return(paste(row, collapse = " & "))
  }
  
  latex_rows <- apply(tab, 1, create_latex_row) # apply to each row of the data frame
  latex_string <- paste(row_names, latex_rows, collapse = "\\\\\n") # combine all rows into a single string
  return(latex_string)
}
writeLines(table_tex(c("Within address &", "Observations &"), success_int_AER),
           "internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/results/Tables/success_int_AER.tex") # save output
writeLines(table_tex(c("Within address &", "Observations &"), success_int_AID),
           "internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/results/Tables/success_int_AID.tex")
writeLines(table_tex(c("Within address &", "Observations &"), success_aid_AID),
           "internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/results/Tables/success_aid_AID.tex")
