*cd "C:\Users\giaco\Dropbox (UCL)\internet_replication"

import delimited using "${pathtemp}\reverse_n_all-sample.csv", clear
keep if type_of_sample == "Matched (3)"
tempfile temp
save "`temp'"

use "${pathdataraw}\afro_res_final.dta", clear
count

merge m:m townvill district region country using "`temp'", force

keep if _merge == 3 // | _merge == 1

keep if employment != -9 & age < 65 & distance < 0.1 & employed != . // conditions of T3

replace reverse_aer_geonames = "" if reverse_aer_geonames == "NA"
replace reverse_aid_geonames = "" if reverse_aid_geonames == "NA"
replace districtaid = "" if districtaid == "NA"


keep townvill townvillaid district districtaid region country distance longitude latitude reverse* latitudeaid longitudeaid note place_nameaid idgeocoding geoname_adm_nameaid

* Drop duplicates (keep at townvill level; only 1st instance)
sort townvill district region country
duplicates report townvill district region country
gen first_instance = 0
by townvill district region country: replace first_instance = 1 if _n == 1
keep if first_instance == 1
drop first_instance
tab townvill // some townvills will be present more than once but because, e.g., the district is different

export delimited "${pathtemp}\reverse_n_enteringT3.csv", replace

