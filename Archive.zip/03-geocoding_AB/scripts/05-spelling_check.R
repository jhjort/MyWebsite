# Check which district coord fall in

# Set working directory - and clean environment
rm(list=ls())
#setwd("C:/Users/emiliogu/Dropbox") # DB directory
setwd("C:/Users/ASUS/Dropbox") # DB directory

# Load required packages
library(geodata)
library(sf)
library(stringdist)
library(dplyr)
library(stringr)

# Load data (run each time with different data
full <- read.csv("internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/processed/reverse_n_all-sample.csv")
full <- full %>% mutate(across(everything(), ~ifelse(. == "", NA, .))) # make empty strings NAs
full <- full %>% subset(country %in% c("BJ", "GH", "KE", "MG", "MZ", "NG", "SN", "TZ", "ZA")) # drop outside of 9 countries
full <- within(full, { # convert latitutde/longitude = 0 with NA
  latitude <- ifelse(latitude == 0 & longitude == 0, NA, latitude)
  longitude <- ifelse(latitude == 0 & is.na(longitude), NA, longitude)
})
intersection <- full %>% subset(type_of_sample == "Matched (3)")
aid_only <- full %>% subset(type_of_sample == "Master only (1)")
t3 <- read.csv("internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/processed/reverse_n_enteringt3.csv")
t3 <- t3 %>% mutate(across(everything(), ~ifelse(. == "", NA, .))) # make empty strings NAs
t3 <- t3 %>% rename(districtAID = districtaid, townvillAID = townvillaid, geoname_adm_nameAID = geoname_adm_nameaid,
                    longitudeAID = longitudeaid, latitudeAID = latitudeaid, place_nameAID = place_nameaid)

# Assign data to analsis dataframe (T3, aid_only, intersection) - as well as var. to match for
data <- intersection # or aid_only, or t3

# Get the first entry after the country in geonames - and convert to lower character
geoname <- gsub("Earth\\|Africa\\|", "", data$geoname_adm_nameAID)
geonames <- str_extract(geoname, "\\|([^|]+)\\|")
geonames[is.na(geonames)] <- sapply(strsplit(geoname[is.na(geonames)], "\\|"), tail, 1)
geonames <- gsub("\\|", "", geonames)
geonames <- ifelse(geonames == data$place_nameAID, NA, geonames) # make NA if identical to place_nameAID
data$geonames <- iconv(tolower(geonames), from = "UTF-8", to = "ASCII//TRANSLIT") # encoding issues

# Get Roxanne's note/townvill
data$note_townvill <- ifelse(is.na(data$note), data$townvill, data$note)

# Assign analysis matching variable and subset when unavailable
data$region_copy <- data$region # to store the region from AER when renamed
data <- data %>% rename(to_matchAER = district) # or region, townvill, townvillAID, district, region, etc.
data <- data %>% rename(to_matchAID = geonames)

# Load shapefiles of the 9 countries - highest lvl possible for each (but SA)
path <- "internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/raw_data"
# path <- "C:/Users/giaco/Dropbox (UCL)/internet_replication/geocoding/_new/data"
ghana2 <- st_as_sf(gadm("GHA", level = 2, path, version = "latest", resolution = 1))
nigeria2 <- st_as_sf(gadm("NGA", level = 2, path, version = "latest", resolution = 1))
benin3 <- st_as_sf(gadm("BEN", level = 3, path, version = "latest", resolution = 1))
kenya3 <- st_as_sf(gadm("KEN", level = 3, path, version = "latest", resolution = 1))
mozambique3 <- st_as_sf(gadm("MOZ", level = 3, path, version = "latest", resolution = 1))
tanzania3 <- st_as_sf(gadm("TZA", level = 3, path, version = "latest", resolution = 1))
madagascar4 <- st_as_sf(gadm("MDG", level = 4, path, version = "latest", resolution = 1))
senegal4 <- st_as_sf(gadm("SEN", level = 4, path, version = "latest", resolution = 1))
south3 <- st_as_sf(gadm("ZAF", level = 3, path, version = "latest", resolution = 1)) # lvl 3 cause NAME_4 is unhelpful (just a number)

# Bind all shapefiles in one (and name country with code not name)
countries <- bind_rows(ghana2, nigeria2, benin3, kenya3, mozambique3,
                       tanzania3, madagascar4, senegal4, south3)
countries <- countries %>%
  mutate(across(c(NAME_1, NAME_2, NAME_3, NAME_4), ~ iconv(tolower(.), from = "UTF-8", to = "ASCII//TRANSLIT")))
country_codes <- c(
  Benin = "BJ",
  Ghana = "GH",
  Kenya = "KE",
  Madagascar = "MG",
  Mozambique = "MZ",
  Nigeria = "NG",
  Senegal = "SN",
  `South Africa` = "ZA",
  Tanzania = "TZ"
)
countries$COUNTRY <- country_codes[countries$COUNTRY]

# Function to get which polygon the coordinates fall in
get_polygon_info <- function(df, lon_col_name, lat_col_name, countries) {
  # Maintain original
  df_og <- df
  
  # Subset the duplicated coordinate pairs
  df <- df_og[!duplicated(df[, c(lat_col_name, lon_col_name)]), c(lat_col_name, lon_col_name)]
  
  # Store the longitude and latitude columns (geometry will drop them)
  lon <- df[[lon_col_name]]
  lat <- df[[lat_col_name]]
  
  # Convert the dataframe to an sf object, setting the coordinates
  df <- st_as_sf(df, coords = c(lon_col_name, lat_col_name), crs = st_crs(countries))
  
  # Use the st_join function to join the countries to the points in the dataframe
  df <- st_join(df, countries[,c("COUNTRY", "NAME_1", "NAME_2", "NAME_3", "NAME_4", "geometry")]) # NA for unmatched ones
  
  # Discard the geometry column
  df <- st_drop_geometry(df)
  
  # Add the longitude and latitude columns back to the dataframe
  df[[lon_col_name]] <- lon
  df[[lat_col_name]] <- lat
  
  # Merge back onto the original dataframe
  merged <- merge(df_og, df, by = c(lat_col_name, lon_col_name))
  
  return(merged)
}
# Function to compute JW similarity by row
calculate_jw <- function(df, to_match_col, name_cols) {
  
  df$max_sim_score <- NA  # to store the maximum similarity score for each row
  df$max_sim_col <- NA  # to store the column name with the maximum similarity score
  df$max_sim_val <- NA  # to store the matching string for maximum similarity score
  
  # loop through each row
  for (i in 1:nrow(df)) {
    # get the geonames entry for the current row
    to_match <- df[[to_match_col]][i]
    
    if (is.na(to_match)) {
      # If to_match is NA, set the max similarity variables to NA and skip further processing
      df$max_sim_score[i] <- NA
      df$max_sim_col[i] <- NA
      df$max_sim_val[i] <- NA
      next
    }
    
    # calculate the similarity scores, accounting for possible NA values in the comparison columns
    scores <- sapply(name_cols, function(name_col) {
      if (is.na(df[[name_col]][i])) {
        return(0) # no match
      } else {
        return(1 - stringdist::stringdistmatrix(to_match, df[[name_col]][i], method = "jw")) # similarity score
      }
    })
    
    # find the maximum similarity score
    max_score_index <- which.max(scores)
    df$max_sim_score[i] <- scores[max_score_index]
    df$max_sim_col[i] <- name_cols[max_score_index]
    df$max_sim_val[i] <- df[[name_cols[max_score_index]]][i]
  }
  
  # Keep only variables of interest
  df <- df[, c("country", to_match_col, "max_sim_score", "max_sim_col", "max_sim_val",
               "latitude", "longitude", "latitudeAID", "longitudeAID", "idgeocoding"
  )]
  
  return(df)
}
# Function to generate per country match output
generate_dataframe <- function(combined_matched, to_matchAER, to_matchAID) {
  # Initialize an empty matrix for the new dataframe
  df <- matrix(ncol = 10, nrow = 4)
  
  # Initialize a vector for the country names
  countries <- c("GH", "NG", "BJ", "KE", "MZ", "TZ", "MG", "SN", "ZA", "Tot.")
  
  # Subset dataframe if matching col is NA
  matched_aer <- combined_matched %>% subset(!is.na(to_matchAER))
  matched_aid <- combined_matched %>% subset(!is.na(to_matchAID))
  
  # Loop over each country
  for (i in 1:9) {
    country <- countries[i]
    
    # Row 1: # obs. in combined_matched (where to_matchAER is available)
    df[1, i] <- nrow(matched_aer[matched_aer$country == country,])
    
    # Row 2: percentage of obs. in combined_matched with match == 1
    df[2, i] <- sum(matched_aer$match[matched_aer$country == country] == 1) / df[1, i] * 100
    
    # Row 3: # obs. in combined_matched (where to_matchAID is available)
    df[3, i] <- nrow(matched_aid[matched_aid$country == country,])
    
    # Row 4: like (3) but using match_AID instead
    df[4, i] <- sum(matched_aid$match_AID[matched_aid$country == country] == 1) / df[3, i] * 100
  }
  
  # Compute total for each row
  df[1, 10] <- sum(df[1, 1:9])
  df[2, 10] <- sum(df[2, 1:9] * df[1, 1:9]) / df[1, 10]
  df[3, 10] <- sum(df[3, 1:9])
  df[4, 10] <- sum(df[4, 1:9] * df[3, 1:9]) / df[3, 10]
  
  # Create a dataframe from the matrix
  df <- as.data.frame(df)
  
  # Name rows and columns
  row.names(df) <- c("AER obs.", "AER matched", "AID obs.", "AID matched")
  colnames(df) <- c(countries)
  
  # Format entries
  df[c(1,3), ] <- lapply(df[c(1,3), ], function(x) formatC(as.numeric(x), format = "f", digits = 0, big.mark = ","))
  df[c(2,4), ] <- lapply(df[c(2,4), ], function(x) paste0(round(as.numeric(x), 2), "\\%"))
  
  return(df)
  }

# Function to generate LaTeX table
to_latex <- function(caption, data){
  
  # Function to format data frame row as a LaTeX table row
  format_row <- function(row_data, row_name){
    row_string <- paste(row_data, collapse = " & ")
    return(paste(row_name, " & ", row_string, " \\\\"))
  }
  
  # Define row names
  row_names <- c("HP2019 Obs.", "HP2019 Match", "AID Obs.", "AID Match")
  
  # Format each row
  row_strings <- mapply(format_row, as.data.frame(t(data)), row_names, USE.NAMES = FALSE)
  
  # Construct the LaTeX table string
  latex_table <- paste(
    "\\begin{table}[H]\n",
    "\t\\centering\n",
    "\t\\caption{", caption, "}\n",
    "\t\\vspace{1ex}\n",
    "\t\\renewcommand{\\arraystretch}{1.5}",
    "\t\\begin{adjustbox}{width=1\\textwidth}\n",
    "\t\t\\small\n",
    "\t\t\\begin{tabular}{lcccccccccc}\n",
    "\t\t\t\\hline\\hline\n",
    "\t\t\t& \\textbf{Ghana} & \\textbf{Nigeria} & \\textbf{Benin} & \\textbf{Kenya} & \\textbf{Mozambique} & \\textbf{Tanzania} & \\textbf{Madagascar} & \\textbf{Senegal} & \\textbf{South Africa} & \\textbf{Total} \\\\\n",
    "\t\t\t\\hline\n",
    "\t\t\t\\textit{Panel A.} & \\multicolumn{10}{l}{\\textit{HP2019 coordinates matching the polygon's names.}} \\\\\n",
    row_strings[2], "\n",
    row_strings[1], "\n",
    "\t\t\t\\hline\n",
    "\t\t\t\\textit{Panel B.} & \\multicolumn{10}{l}{\\textit{AID coordinates matching the polygon's names.}} \\\\\n",
    row_strings[4], "\n",
    row_strings[3], "\n",
    "\t\t\t\\hline\\hline\n",
    "\t\t\\end{tabular}\n",
    "\t\\end{adjustbox}\n",
    "\\end{table}\n", 
    sep = "")
  
  return(latex_table)
}
# Function to convert strings to lower cases
convert_strings_to_ascii <- function(dataframe, columns) {
  for (col in columns) {
    dataframe[[col]] <- iconv(tolower(dataframe[[col]]), from = "UTF-8", to = "ASCII//TRANSLIT")
  }
  return(dataframe)
}

# Check fuzzy match across all levels
data_aer <- get_polygon_info(data, "longitude", "latitude", countries)
data_aer <- convert_strings_to_ascii(data_aer, c("to_matchAER", "to_matchAID", "NAME_1", "NAME_2", "NAME_3", "NAME_4"))
data_aid <- get_polygon_info(data, "longitudeAID", "latitudeAID", countries)
data_aid <- convert_strings_to_ascii(data_aid, c("to_matchAER", "to_matchAID", "NAME_1", "NAME_2", "NAME_3", "NAME_4"))
data_aer_matched <- calculate_jw(data_aer, "to_matchAER", c("NAME_1", "NAME_2", "NAME_3", "NAME_4")) 
data_aid_matched <- calculate_jw(data_aid, "to_matchAID", c("NAME_1", "NAME_2", "NAME_3", "NAME_4"))  
data_aid_matched <- data_aid_matched %>% rename(max_sim_score_AID = max_sim_score,
                                                max_sim_col_AID = max_sim_col,
                                                max_sim_val_AID = max_sim_val)
combined_matched <- data_aid_matched
combined_matched <- merge(data_aer_matched, data_aid_matched) # combine (merge all in one, same obs.)
nrow(combined_matched) == nrow(data)
combined_matched$match <- ifelse(combined_matched$max_sim_score >= 0.9, 1, 0)
combined_matched$match_AID <- ifelse(combined_matched$max_sim_score_AID >= 0.9, 1, 0)
results <- generate_dataframe(combined_matched, "to_matchAER", "to_matchAID")

# Conver to LaTeX and save
caption <- 
save_file <- 
latex <- to_latex(caption, results)
writeLines(latex, save_file)
