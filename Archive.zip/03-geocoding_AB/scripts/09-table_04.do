*cd "C:\Users\jacci\Dropbox (Personal)\internet_replication\replies-to-replicators\05-geocoding_AB\geocoding_checks"
*global out      = "C:\Users\jacci\Dropbox (Personal)\internet_replication\replies-to-replicators\05-geocoding_AB\geocoding_checks"
********************************************************************
** # 0.- Create database with Aid merged with AER geocoing
********************************************************************
// First, we need all the afrobarometer obs from the raw data
use "${pathdataraw}\afro_final.dta", clear
replace submarines = 1 if submarines > 0
gen connected     = 1 if distance <= 0.005
replace connected = 0 if connected == .
gen treatment     = connected * submarines
egen country_year = group(country year)
egen grid_connect = group(grid connected)
rename q1 age

* grid size
glo   gridsize10 = 0.1 // side of each square in degrees
* generate grid cell variable
g  latitude_grid10 = 100*${gridsize10}*round(latitude/${gridsize10})
g  longitude_grid10 = 100*${gridsize10}*round(longitude/${gridsize10})
tostring latitude_grid10 longitude_grid10, replace force
g  grid10 = latitude_grid10 + "_" + longitude_grid10

keep resp year country employed treatment town submarines employment age distance grid10 latitude longitude grid_connect connected country_year
foreach var in employed treatment employment townvill age submarines distance grid10 latitude longitude grid_connect connected country_year {
   rename `var' `var'_hp
}
tempfile aer_raw
save `aer_raw'

********************************************************************
** # 1.- Replicate result of Table 3
********************************************************************
use "${pathdataraw}\afro_res_final.dta", clear
gen placerox = townvill 
replace placerox = note if note!="Since I couldn't find exact coordinates for 10e arrond, I used coordinates for Cotonou." & !mi(note)
foreach var in placerox  {
   replace `var'    = ustrlower(ustrregexra(ustrnormalize(strtrim(`var'), "nfd" ) , "\p{Mark}", "" )  )
   replace `var'    = upper(`var')
}

* country x time FE's
drop country_year
egen country_year = group(country year)

* grid-cell x connected FE's
drop grid_connect
egen grid_connect = group(grid10 connected)


areg employed treatment i.country_year if employment != -9 & age < 65 & distance < 0.1, a(grid_connect) cluster(grid10)
estadd ysumm, mean
unique grid10 if e(sample)==1
estadd scalar ngrid = r(unique)
eststo reg1
gen sample_hp = e(sample)
keep if sample==1
keep resp year country employed treatment townvill  submarines employment age distance grid10 place latitude longitude grid_connect connected sample_hp country_year
foreach var in employed treatment employment townvill age submarines distance grid10 latitude longitude grid_connect connected country_year {
	rename `var' `var'_hp
}
tempfile data
save `data'
********************************************************************
** # 2.- Using New geocoding
********************************************************************
use "${pathdata}\afro_aid.dta", clear
gen placeaid = place_name
foreach var in placeaid {
   replace `var'    = ustrlower(ustrregexra(ustrnormalize(strtrim(`var'), "nfd" ) , "\p{Mark}", "" )  )
   replace `var'    = upper(`var')
}

*Keep only the 9 countries
keep if inlist(year,2008,2011,2012,2013)
keep if inlist(country,"BJ","GH","KE","MG","MZ","NG","SN","TZ","ZA")

// filter by grid points: Keep only twice
preserve,
gen count = 1
collapse count, by(grid10 year)
duplicates tag grid10, gen(dups)
keep if dups == 1
keep grid10 year
tempfile to_keep
save `to_keep', replace
restore
merge m:1 grid10 year using `to_keep'
keep if _merge == 3
drop _merge

areg employed treatment i.country_year if employment != -9 & age < 65 & distance < 0.1, a(grid_connect) cluster(grid10)
estadd ysumm, mean
unique grid10 if e(sample)==1
estadd scalar ngrid = r(unique)
eststo reg2
gen sample_aid = e(sample)
keep if sample==1

********************************************************************
** # 3.- Merge both databases and compare
********************************************************************
keep resp year country employed treatment townvill employment age distance ///
	 grid10 latitude longitude grid_connect connected sample_aid country_year submarines precision placeaid

foreach var in employed treatment employment age townvill distance  submarines grid10 latitude longitude precision grid_connect connected country_year {
	rename `var' `var'_aid
}	 

merge 1:1 resp year country using `data'


// Both Model HP
local x ="_hp"
cap drop treatment
gen treatment = treatment`x'
areg employed`x' treatment i.country_year`x' if employment`x' != -9 & age`x' < 65 & distance`x' < 0.1 & sample_aid==1 & sample_hp==1 & _merge==3, a(grid_connect`x') cluster(grid10`x')
estadd ysumm, mean
unique grid10`x' if e(sample)==1
estadd scalar ngrid = r(unique)
eststo reg3

local x ="_aid"
cap drop treatment
gen treatment = treatment`x'
areg employed`x' treatment i.country_year`x' if employment`x' != -9 & age`x' < 65 & distance`x' < 0.1 & sample_aid==1 & sample_hp==1 & _merge==3, a(grid_connect`x') cluster(grid10`x')
estadd ysumm, mean
unique grid10`x' if e(sample)==1
estadd scalar ngrid = r(unique)
eststo reg4

// Only in HP
local x ="_hp"
cap drop treatment
gen treatment = treatment`x'
areg employed`x' treatment i.country_year`x' if employment`x' != -9 & age`x' < 65 & distance`x' < 0.1 & sample`x' & _merge!=3, a(grid_connect`x') cluster(grid10`x')
estadd ysumm, mean
unique grid10`x' if e(sample)==1
estadd scalar ngrid = r(unique)
eststo reg5

// Only in Aid
local x ="_aid"
cap drop treatment
gen treatment = treatment`x'
areg employed`x' treatment i.country_year`x' if employment`x' != -9 & age`x' < 65 & distance`x' < 0.1 & sample`x' & _merge!=3, a(grid_connect`x') cluster(grid10`x')
estadd ysumm, mean
unique grid10`x' if e(sample)==1
estadd scalar ngrid = r(unique)
eststo reg6


// AER geocoding but the AID sample
preserve,
*keep Aid sample only
local x = "_aid"
keep if sample`x'==1
keep resp year country employed`x' treatment`x' employment`x' age`x' distance`x' ///
    grid10`x' latitude`x' longitude`x' grid_connect`x' connected`x' sample`x' country_year`x' submarines`x'
* merge with raw aer geocoding
merge 1:1 resp year country  using `aer_raw', keep(3) nogen

// Aid-sample but HP geocoding
local x ="_hp"
cap drop treatment
gen treatment = treatment`x'
areg employed`x' treatment i.country_year`x' if sample_aid==1 , a(grid_connect`x') cluster(grid10`x')
estadd ysumm, mean
unique grid10`x' if e(sample)==1
estadd scalar ngrid = r(unique)
eststo reg12
restore

// Export table
*esttab reg1 reg2 reg3 reg4 reg5 reg6 reg12 using "${pathtab}\table_04.tex", replace se b(3) stats(N ymean ngrid, fmt(0  %9.2f 0)  labels("Observations" "Mean of Outcome" "\# grids")) label alignment(center) nogaps fragment nonumbers mlabels(none) drop(*year* _cons) collabels()  nocon starlevels(* 0.10 ** 0.05 *** 0.01) nolines

/////////////////////////////////////////////////////////////////////////////////////////////
// Intersection swichitng  treatment
/////////////////////////////////////////////////////////////////////////////////////////////

tab connected_aid connected_hp if sample_aid==1 & sample_hp==1 & _merge==3
gen same_treatment 	  = (connected_aid==connected_hp) 	if sample_aid==1 & sample_hp==1 & _merge==3
gen same_grid 		     = (grid10_hp==grid10_aid)		 	if sample_aid==1 & sample_hp==1 & _merge==3

label var same_treatment "Same Connected status"
label var same_grid      "Same grid"
collect table same_grid same_treatment ,  stat(freq)  notot
collect style cell, nformat(%8.0f)  border(right, pattern(nil))
collect preview
collect style tex, nobegintable
collect preview


*collect export "${pathtab}\table_04_status.tex",  tableonly replace 

// Table samples : intersection and remains
foreach x in _hp _aid {
cap drop treatment
gen treatment = treatment`x'
areg employed`x' treatment i.country_year`x' if  _merge==3, a(grid_connect`x') cluster(grid10`x')
estadd ysumm, mean
unique grid10`x' if e(sample)==1
estadd scalar ngrid = r(unique)
eststo reg7
areg employed`x' treatment i.country_year`x' if  same_grid!=1 & same_treatment!=1 &_merge==3, a(grid_connect`x') cluster(grid10`x')
estadd ysumm, mean
unique grid10`x' if e(sample)==1
estadd scalar ngrid = r(unique)
eststo reg8
areg employed`x' treatment i.country_year`x' if  same_grid!=1 & same_treatment==1 &_merge==3, a(grid_connect`x') cluster(grid10`x')
estadd ysumm, mean
unique grid10`x' if e(sample)==1
estadd scalar ngrid = r(unique)
eststo reg9
areg employed`x' treatment i.country_year`x' if  same_grid==1 & same_treatment!=1 &_merge==3, a(grid_connect`x') cluster(grid10`x')
estadd ysumm, mean
unique grid10`x' if e(sample)==1
estadd scalar ngrid = r(unique)
eststo reg10
areg employed`x' treatment i.country_year`x' if  same_grid==1 & same_treatment==1 &_merge==3, a(grid_connect`x') cluster(grid10`x')
estadd ysumm, mean
unique grid10`x' if e(sample)==1
estadd scalar ngrid = r(unique)
eststo reg11
esttab reg7 reg8 reg11 using "${pathtab}\table_04_intersect`x'.tex", replace se b(3) stats(N ymean, fmt(0  %9.2f 0)  labels("Observations" "Mean of Outcome")) label alignment(center) nogaps fragment nonumbers mlabels(none) drop(*year* _cons) collabels()  nocon starlevels(* 0.10 ** 0.05 *** 0.01) nolines
}
*reg9 reg10
save "${pathdata}\intersection.dta",replace
/////////////////////////////////////////////////////////////////////////////////////////////
// Intersection  grid distribution
/////////////////////////////////////////////////////////////////////////////////////////////
** # Grid Level
keep if sample_aid==1 | sample_hp==1
local x ="_hp"
preserve,
gen unit  = 1 
keep if sample`x'==1
collapse (sum) unit same_grid same_treatment, by(grid10`x')
foreach var in unit same_grid same_treatment{
	rename `var' `var'`x'
}
rename grid10`x' grid
tempfile data
save `data'
restore


local x ="_aid"
gen unit  = 1 
keep if sample`x'==1
collapse (sum) unit same_grid same_treatment, by(grid10`x')
foreach var in unit same_grid same_treatment{
	rename `var' `var'`x'
}
rename grid10`x' grid

merge 1:1 grid using `data'

// Intersection
tw (hist unit_aid if _merge==3, color(blue%30) percent width(1)) ///
   (hist unit_hp  if _merge==3, color(red%30 ) percent width(1)) ///
   , legend(order(1 "Aid" 2 "HP") pos(6) col(2))  xtitle("Observations per grid")
   graph export "${pathfig}\hist_intersection_grids.pdf", replace

// Differences when grid points are the same
cap drop dif*
gen dif =  unit_hp - unit_aid  if _merge==3  
sum dif* ,d
tw (hist dif, color(red%30 ) percent width(1)) , xtitle("Diff = HP - Aid")
   graph export "${pathfig}\hist_intersection_diff.pdf", replace


tw (hist unit_aid if _merge==1, color(blue%30) percent width(1)) ///
   (hist unit_hp  if _merge==2, color(red%30 ) percent width(1)) ///
   , legend(order(1 "only Aid" 2 "only HP") pos(6) col(2)) xtitle("Observations per grid")
   graph export "${pathfig}\hist_each_grids.pdf", replace
