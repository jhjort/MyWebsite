est clear

*global out      = "${id}"


********************************************************************
** # 0.- Create database with AER
********************************************************************
use "${pathdata}\intersection.dta", clear 

keep if _merge==3
foreach var in placerox placeaid {
	// Homogenizing strings 
	cap drop tocomparetown tocompareplace
	gen tocomparetown 	  = strtrim(townvill_aid) 
	replace tocomparetown = upper(tocomparetown)

	gen tocompareplace 	  = ustrlower(ustrregexra(ustrnormalize(strtrim(`var'), "nfd" ) , "\p{Mark}", "" )  )
	replace tocompareplace= upper(tocompareplace)

	// Create index
	cap drop scoreplace similscore
	matchit tocomparetown tocompareplace,  sim(token_soundex)
	ren similscore scoreplace
	cap drop similscore
	matchit tocomparetown tocompareplace

	// Create categories
	gen index_`var' = 0
	replace  index_`var' =1 if (tocomparetown==tocompareplace)
	replace  index_`var' =2*(similscore>=.5&scoreplace>=.5) if tocomparetown!=tocompareplace
}

*merge m:1 townvill_hp using "${out}\index_townvill.dta", keep(1 3) nogen

*merge m:1 townvill_aid using "${out}\index_townvill_aid.dta", keep(1 3) nogen


foreach x in _hp _aid {
	cap drop treatment
	gen treatment = treatment`x'
	areg employed`x' treatment i.country_year`x' if  same_grid!=1 & same_treatment!=1 & _merge==3, a(grid_connect`x') cluster(grid10`x')
	cap drop col_sample`x'
	gen col_sample`x' = e(sample)
}
// Because it's the intersection, the have the same sample
tab col_sample_*
// Let's check how they differ
label define index  0 "Different spelling" 1 "Exactly the same" 2 "Similar" 3 "Missing value", replace
label value index_placerox index
label value index_placeaid index


** Table 1 : 
global filename = "table_05_intserct_col3"
cap file close ${filename}
file open  ${filename} using "${pathtab}\\${filename}.tex", write replace
file write ${filename} "" _n
*file write ${filename} "  & Different & Exactly the same & Similar \\" _n
forval j =0(1)2{
	count if index_placerox==0 &  index_placeaid==`j' & col_sample_hp==1
	local r1 	= string(`r(N)'	,  "%16.0fc")
	count if index_placerox==1 &  index_placeaid==`j'	& col_sample_hp==1
	local r2 	= string(`r(N)'	,  "%16.0fc")
	count if index_placerox==2 &  index_placeaid==`j'	& col_sample_hp==1
	local r3 	= string(`r(N)'	,  "%16.0fc")
	count if 	 index_placeaid==`j'	& col_sample_hp==1
	local tot	= string(`r(N)'	,  "%16.0fc")
	local lab : label index  `j'
	dis in red("Category : `lab'")
	file write ${filename} " `lab' & `r1' & `r2' & `r3' & `tot'\\" _n
}
forval j =0(1)2{
	count if index_placerox==`j'	& col_sample_hp==1
	local r`j' 	= string(`r(N)'	,  "%16.0fc")
}
count if 	 col_sample_hp==1
local tot	= string(`r(N)'	,  "%16.0fc")
file write ${filename} " \hline" _n
file write ${filename} " Total & `r0' & `r1' & `r2' & `tot'\\" _n
cap file close ${filename}


keep town* place* index*
duplicates drop
br if index_placerox==1 & index_placeaid!=1

