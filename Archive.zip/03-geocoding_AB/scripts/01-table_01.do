
// Import reverse geocoding
use "${pathdataraw}\afrobarometer-with-aid-geocode-townlevel-allsamples.dta", clear

bys country: egen tokeep = max(type_of_sample)
keep if tokeep==3
drop tokeep

* #1 Create the categories for 
// Assume townvill in both database is the same
count
count if townvill==townvillAID /* same townvills for the versions of afrobarometer */
ren place_nameAID placeaid
gen placerox = townvill 
replace placerox = note if note!="Since I couldn't find exact coordinates for 10e arrond, I used coordinates for Cotonou." & !mi(note)
foreach var in placerox placeaid {
	replace `var' 	  = ustrlower(ustrregexra(ustrnormalize(strtrim(`var'), "nfd" ) , "\p{Mark}", "" )  )
	replace `var' 	  = upper(`var')
}
foreach var in placerox placeaid {
	// Homogenizing strings 
	cap drop tocomparetown tocompareplace
	gen tocomparetown 	  = strtrim(townvillAID) 
	replace tocomparetown = upper(tocomparetown)

	gen tocompareplace 	  = ustrlower(ustrregexra(ustrnormalize(strtrim(`var'), "nfd" ) , "\p{Mark}", "" )  )
	replace tocompareplace= upper(tocompareplace)

	// Create index
	cap drop scoreplace similscore
	matchit tocomparetown tocompareplace,  sim(token_soundex)
	ren similscore scoreplace
	cap drop similscore
	matchit tocomparetown tocompareplace

	// Create categories
	gen index_`var' = 0
	replace  index_`var' =1 if (tocomparetown==tocompareplace)
	replace  index_`var' =2*(similscore>=.5&scoreplace>=.5) if tocomparetown!=tocompareplace
}


////////////////////////////////////////////////////////////////////////////////////
// TABLE 1.- 
////////////////////////////////////////////////////////////////////////////////////

// Export the table to a LaTeX file
// Label categories
label define index  0 "Different spelling" 1 "Exactly the same" 2 "Similar (using an index)", replace

// Sample: intersection
preserve,
	keep if type_of_sample==3 

	// We drop latitude and longitude that AER couldn't geocode
	drop if latitude==0 | longitude==0

	** Table 1 : 
	global filename = "table_1a"
	cap file close ${filename}
	file open  ${filename} using "${pathtab}\\${filename}.tex", write replace
	file write ${filename} "" _n
	forval j =0(1)2{
		count if index_placerox==`j'
		local rox 	= string(`r(N)'	,  "%16.0fc")
		count if index_placeaid==`j'
		local aid 	= string(`r(N)'	,  "%16.0fc")	
		local lab : label index  `j'
		dis in red("Category : `lab'")
		file write ${filename} " `lab' & `rox' & `aid' \\" _n
	}
		count if !mi(index_placerox)
		local rox 	= string(`r(N)'	,  "%16.0fc")
		count if !mi(index_placeaid)
		local aid 	= string(`r(N)'	,  "%16.0fc")	
	file write ${filename} " Total & `rox' & `aid' \\" _n
	cap file close ${filename}
restore

//////////////////////////////////////////////////////////////////////////////////////////
