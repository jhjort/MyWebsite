# Clean environment
rm(list=ls())

# Select directory (DropBox) -- may need change according to user
#setwd("C:/Users/emiliogu/Dropbox")
setwd("C:/Users/ASUS/Dropbox")

# Create function to amend script (in temp copy) and run it
run_script <- function(data, caption, to_matchAER, to_matchAID, save_file) {
  message("Loading script contents...")
  script_og <- readLines("internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/scripts/05-spelling_check.R")
  
  # Change lines
  script_mod <- gsub("data <- intersection", data, script_og)
  script_mod <- gsub("data <- data %>% rename\\(to_matchAER = district\\)", 
                     paste0("data <- data %>% rename(to_matchAER = \"", to_matchAER, "\")"), script_mod)
  script_mod <- gsub("data <- data %>% rename\\(to_matchAID = geonames\\)", 
                     paste0("data <- data %>% rename(to_matchAID = \"", to_matchAID, "\")"), script_mod)
  script_mod <- gsub("caption <-", 
                     paste0("caption <- \"", caption, "\""), script_mod)
  script_mod <- gsub("save_file <-",
                     paste0("save_file <- \"", save_file, "\""), script_mod)
  
  # Discard panel A - i.e., AER info - if data is aid_only
  if (data == "data <- aid_only") {
    message("-------------------------AID-only data: no panel A-------------------------")
    script_mod <- script_mod[-c(227:230, 252, 253, 256, 262:264)]
  } else {
    script_mod <- script_mod
  }
  
  # Make temp file
  tmp_file <- tempfile(pattern = "modified_", fileext = ".R")
  writeLines(script_mod, tmp_file)
  new_env <- new.env(parent=globalenv())
  
  message("Taking snapshot of current files in the working directory...")
  snapshot_before <- fileSnapshot()
  
  message("Running the modified script...")
  source(tmp_file, local = new_env)
  
  message("Removing temporary file...")
  file.remove(tmp_file)
  
  message("Script has been executed successfully.")
}

# 1. Intersection data with AER districts and Geonames (2nd entry) if different from place_name
run_script(data = "data <- intersection",
           caption = "Spelling check with the District/Geonames -- Intersection Data",
           to_matchAER = "district",
           to_matchAID = "geonames",
           save_file = "internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/results/Tables/spelling_int_district.tex"
)

# 2. Intersection data with AER townvill/note and AID place_name
run_script(data = "data <- intersection",
           caption = "Spelling check with the townvill-note/place-name -- Intersection Data",
           to_matchAER = "note_townvill",
           to_matchAID = "place_nameAID",
           save_file = "internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/results/Tables/spelling_int_town.tex"
)


# 3. Intersection data with AER regions (AID region is a number)
run_script(data = "data <- intersection",
           caption = "Spelling check with the HP2019 Regions -- Intersection Data",
           to_matchAER = "region",
           to_matchAID = "region_copy",
           save_file = "internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/results/Tables/spelling_int_region.tex"
)
