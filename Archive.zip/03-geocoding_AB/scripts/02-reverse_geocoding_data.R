# Compute reverse geocoded address using Maps; OSM; Geonames
# Then, create a dataset with all the corresponging info

# Set working directory - and clean environment
rm(list=ls())
setwd("C:/Users/emiliogu/Dropbox")
#setwd("C:/Users/giaco/Dropbox (UCL)") # DB directory

# Load required packages
library(dplyr)
library(ggmap) # Maps API
library(tidygeocoder) # OSM API

# Load Google Maps API key 
register_google(key = "0000000") # key has to be valid and active

# Load data - keep only obs. in 9 countries of analysis
all <- read.csv("internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/raw_data/afrobarometer-with-aid-geocode-townlevel-allsamples.csv")
all <- all %>% mutate(across(everything(), ~ifelse(. == "", NA, .))) # make empty strings NAs
all$type_of_sample[all$longitude == 0 & all$latitude == 0 &
                     !is.na(all$longitude) & !is.na(all$latitude)] <- "Master only (1)" # type_of_sample is AID only when AER coords are 0
table(all$country)

# For AER, keep only obs. with lat/lng and unique
roxanne <- all %>% subset(type_of_sample == "Using only (2)" | type_of_sample == "Matched (3)") # keep obs. where we have data for AER
roxanne <- roxanne[!duplicated(roxanne[, c("latitude", "longitude")]), c("latitude", "longitude")] # to speed up computations

# For AID, keep only obs. within 9 countries
aid <- all %>% subset(!is.na(latitudeAID) & !is.na(longitudeAID)) # only obs. AID-data geocoded successfully (all of them)
aid <- aid %>% subset(country %in% c("BJ", "GH", "KE", "MG", "MZ", "NG", "SN", "TZ", "ZA"))
aid <- aid[!duplicated(aid[, c("latitudeAID", "longitudeAID")]), c("latitudeAID", "longitudeAID")] # to speed up computations

# Reverse Geocode -- Maps & OSM
roxanne$reverse_AER_maps <- sapply(1:nrow(roxanne), function(i) {
  revgeocode(unlist(roxanne[i,c("longitude", "latitude")]), output = "address")
}) # Multiple addresses found, the first will be returned
roxanne$reverse_AER_osm <- reverse_geo(lon = roxanne$longitude, roxanne$latitude, method = "osm")$address
aid$reverse_AID_maps <- sapply(1:nrow(aid), function(i) {
  revgeocode(unlist(aid[i,c("longitudeAID", "latitudeAID")]), output = "address")
}) # Multiple addresses found, the first will be returned
aid$reverse_AID_osm <- reverse_geo(lon = aid$longitudeAID, aid$latitudeAID, method = "osm")$address

# Merge all back into nick and save output
merged <- merge(all, roxanne, all.x = T)
merged <- merge(merged, aid, all.x = T)
write.csv(merged, "internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/processed/reverse_nick_all-sample.csv")

# Remove data and load it again
rm(list=ls())
data <- read.csv("internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/processed/reverse_nick_all-sample.csv")

# For AER, keep only obs. with lat/lng and unique
roxanne <- data %>% subset(type_of_sample == "Using only (2)" | type_of_sample == "Matched (3)") # keep obs. where we have data for AER
roxanne <- roxanne[!duplicated(roxanne[, c("latitude", "longitude")]), c("latitude", "longitude")] # to speed up computations

# For AID, keep only obs. within 9 countries
aid <- data %>% subset(!is.na(latitudeAID) & !is.na(longitudeAID)) # only obs. AID-data geocoded successfully (all of them)
aid <- aid %>% subset(country %in% c("BJ", "GH", "KE", "MG", "MZ", "NG", "SN", "TZ", "ZA"))
aid <- aid[!duplicated(aid[, c("latitudeAID", "longitudeAID")]), c("latitudeAID", "longitudeAID")] # to speed up computations

# Add GeoNames rev geocoding
library(geonames) # Geonames API

reverse_geonames <- function(data, lat_col, lon_col, radius_km, usernames) {
  results <- character(nrow(data))
  
  # Create progress bar
  pb <- txtProgressBar(min = 0, max = nrow(data), style = 3)
  
  # Counter for API calls
  call_counter <- 0
  
  # Index for the usernames list
  username_index <- 1
  
  # Counter for the number of usernames used
  username_counter <- 0
  
  # Set the initial username
  options(geonamesUsername = usernames[username_index])
  
  # Loop over each row of the data frame
  for (i in 1:nrow(data)) {
    # Get the latitude and longitude for this row
    lat <- data[[lat_col]][i]
    lon <- data[[lon_col]][i]
    
    # Find closest populated place within radius (in km's)
    reverse_geonames <- GNfindNearbyPlaceName(lat, lon, radius = radius_km, maxRows = 1, style = "FULL") # max verbosity
    
    # Check if reverse_geonames is empty
    if(nrow(reverse_geonames) > 0) {
      # Paste output as unique string
      address_string <- paste(reverse_geonames$name, 
                              reverse_geonames$adminName1, 
                              reverse_geonames$adminName2, 
                              reverse_geonames$countryName, sep = ", ")
      
      results[i] <- address_string
    } else {
      # If reverse_geonames is empty, store a placeholder
      results[i] <- NA
    }
    
    # Update progress bar
    setTxtProgressBar(pb, i)
    
    # Update the API call counter
    call_counter <- call_counter + 1
    
    # If 325 API calls have been made, change the geonamesUsername option
    if(call_counter %% 174 == 0) {
      # Increment the username_index, loop back to 1 if end of list is reached
      username_index <- username_index %% length(usernames) + 1
      
      # Increment the username_counter
      username_counter <- username_counter + 1
      
      # Change the geonamesUsername option
      options(geonamesUsername = usernames[username_index])
    }
  }
  
  # Close progress bar
  close(pb)
  
  return(results)
}

usernames1 <- c("geogiacomo", "geogiacomo1", "geogiacomo2", "geogiacomo3", "geogiacomo4", "geogiacomo5", "geogiacomo6",
                "jac1", "jac2", "jac3", "jac4", "jac5", "jac6")
usernames2 <- c("geogiacomo3", "geogiacomo4", "geogiacomo5", "geogiacomo6",
                "jac1", "jac2", "jac3", "jac4", "jac5", "jac6")

roxanne$reverse_AER_geonames <- reverse_geonames(roxanne, "latitude", "longitude", 5, usernames)
# Wait ...
reverse_AID_geonames <- reverse_geonames(aid[1:3250,], "latitudeAID", "longitudeAID", 5, usernames1)
reverse_AID_geonames2 <- reverse_geonames(aid[3251:nrow(aid),], "latitudeAID", "longitudeAID", 5, usernames1)

aid$reverse_AID_geonames <- c(reverse_AID_geonames, reverse_AID_geonames2)

# Merge all back into nick and save output
data <- data[ , !(names(data) %in% c("reverse_AID_geonames"))] # drop cols
data <- data[ , !(names(data) %in% c("X", "X.1", "X.2"))] 
merged <- merge(data, roxanne, all.x = T)
merged <- merge(data, aid, all.x = T)
write.csv(merged, "internet_replication/newpackage/replies-to-replicators/03-geocoding_AB/processed/reverse_n_all-sample.csv")
