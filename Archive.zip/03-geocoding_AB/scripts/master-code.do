*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
version 17.0
*version 18.0
clear all
macro drop _all 
cap log close

********************************************************************************
** # 0. Setting 
********************************************************************************

local PC = "EGUIO"

if "`PC'"=="EG"{
	global id = "C:\Users\ASUS\Dropbox\internet_replication\newpackage\replies-to-replicators\03-geocoding_AB"
} 
if "`PC'"=="EGUIO"{
	global id = "C:\Users\emiliogu\Dropbox\internet_replication\newpackage\replies-to-replicators\03-geocoding_AB"
} 

cd "${id}"
global pathdo 	   = "${id}\scripts"
global pathtemp    = "${id}\processed"
global pathout 	   = "${id}\results"
global pathfig	   = "${id}\results\Figures"
global pathtab     = "${id}\results\Tables"
global pathdataraw = "${id}\raw_data"
global pathdata    = "${id}\final"

* Folders creation
cap mkdir "${pathdo}"
cap mkdir "${pathtemp}"
cap mkdir "${pathout}"
cap mkdir "${pathfig}"
cap mkdir "${pathtab}"
cap mkdir "${pathdata}"
cap mkdir "${pathdataraw}"


*global out = "${id}"



********************************************************************************
* # 1.- Tables and Figures
********************************************************************************
*NOTE: The directory "C:\Program Files\R\R-4.3.2\bin\x64\R.exe" should be modified according to the location of R in the replicator's computer

* # t1
do "${pathdo}\01-table_01.do"

* # t2
shell "C:\Program Files\R\R-4.3.2\bin\x64\R.exe" CMD BATCH "${pathdo}\02-reverse_geocoding_data.R"
*Uses Google API Key
*Produces "data/afro/processed/reverse_n_all-sample.csv"

do "${pathdo}\03-merge_sampleT3.do"
*Produces  "data/afro/processed/reverse_n_enteringT3.csv"

shell "C:\Program Files\R\R-4.3.2\bin\x64\R.exe" CMD BATCH "${pathdo}\04-success_rev_geo.R"
*Uses the databases from the previous codes to produce "success_int_AER.tex" and "success_int_AID.tex", which are used for Table 2

* # t3, t4 and t5
shell "C:\Program Files\R\R-4.3.2\bin\x64\R.exe" CMD BATCH "${pathdo}\05-spelling_check.R"
*This code is later run by 06-A-run_05

shell "C:\Program Files\R\R-4.3.2\bin\x64\R.exe" CMD BATCH "${pathdo}\06-A-run_05.R"
*Runs 04-spelling_check and produces:
*spelling_int_region.tex (Table 3)
*spelling_int_district.tex (Table 4)
*spelling_int_town.tex (Table 5)


* #Create afro_aid.dta
shell "C:\Program Files\R\R-4.3.2\bin\x64\R.exe" CMD BATCH "${pathdo}\07-aid_distance_to_network.R"
do "${pathdo}\08-table_04_create_data.do"
*Creates afro_aid.dta (used by 09-table_04.do)

* # table 16 and 18
do "${pathdo}\09-table_04.do"
*Produces table_04_intersect_hp.tex and table_04_intersect_aid.tex
*Produces hist_each_grids, hist_intersection_diff and hist_intersection_grid (Figure 1)
*Creates "data/afro/processed/intersection.dta" that is then used by 10-checking-estimate-04

* # table
do "${pathdo}\10-checking-estimate-04.do"
*Produces table_05_intserct_col3.tex

* # % of geocoded obs from AB sample
do "${pathdo}\11-number_obs_geocoded.do"
*94.2%

