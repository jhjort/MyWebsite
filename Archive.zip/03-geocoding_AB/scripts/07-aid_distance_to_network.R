# Clean env. and set directory
rm(list=ls())
#setwd("C:/Users/giaco/DropBox (UCL)") # DropBox folder
setwd("C:/Users/ASUS/Dropbox/internet_replication/newpackage/replies-to-replicators/03-geocoding_AB")

# Load required packages
library(sf)
library(dplyr)
library(rje)

# Load network SS2014 (w/o Ghana NITA)
ss_cables <- st_read("raw_data/ss_cables/ss_cables.shp")
st_crs(ss_cables) <- NA # change CRS to get angular distances

# Load AID data
aid <- read.csv("raw_data/afrobarometer-allsamples-aid.csv")

# To ease computations drop points with same longitude and latitude (distance will be the same)
aid_coords <- aid[!duplicated(aid[, c("longitude", "latitude")]), c("longitude", "latitude")]

# Construct function to compute distance to nearest cable and return the cable's name
nearest_cable <- function(data, network) {
  data_geometry <- st_as_sf(data, coords = c("longitude", "latitude"))
  dist_matrix <- st_distance(data_geometry$geometry, network$geometry)
  closest_cable_idx <- apply(dist_matrix, 1, which.min)
  shortest_distance <- as.numeric(rowMins(dist_matrix))
  join_name <- network$Name[closest_cable_idx]
  data <- data.frame(shortest_distance = shortest_distance, join_retrieved = join_name)
  return(data)
}
aid_dist <- nearest_cable(aid_coords, ss_cables)
aid_dist <- cbind(aid_coords, aid_dist)

# Merge back to original dataframe
merged <- merge(aid, aid_dist)
merged <- merged %>% rename(distanceAID = shortest_distance)

# Save output
write.csv(merged, "processed/afrobarometer-allsamples-aid_distance.csv")
