*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
version 17.0
clear all
*macro drop _all 
cap log close

import delimited "${pathdataraw}\town_villages_distances.csv"

keep if !mi(latitude)|!mi(longitude)
keep if latitude!=0
keep if longitude!=0
keep if inlist(country,"benin","ghana","kenya","madagascar","mozambique","nigeria","senegal","tanzania","south africa")

keep townvill latitude longitude
keep if !mi(latitude)|!mi(longitude)
keep if latitude!=0
keep if longitude!=0

count
*4,341


clear all
use "${pathdata}\afro_aid.dta"
keep if inlist(year,2008,2011,2012,2013)
keep if inlist(country,"BJ","GH","KE","MG","MZ","NG","SN","TZ","ZA")

keep townvill latitude longitude
keep if !mi(latitude)|!mi(longitude)
keep if latitude!=0
keep if longitude!=0
duplicates drop
count
*4610

dis 4341/4610
*94.2 %