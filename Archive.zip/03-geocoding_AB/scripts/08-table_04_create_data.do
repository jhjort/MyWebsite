*global pathdataraw ="C:\Users\jacci\Dropbox\Internet,data centers,ISPs,shutdowns\Data\input"

*------------------------------------------------------------------------------*
** Import distance
*------------------------------------------------------------------------------*

import delimited using "${pathtemp}\afrobarometer-allsamples-aid_distance.csv", clear 
keep respno distanceaid year country_name place_name

generate str name_string = respno
replace respno = ""
compress respno
replace respno = name_string
drop name_string
describe respno
duplicates drop 
save "${pathtemp}\aid_distance.dta", replace

*------------------------------------------------------------------------------*
** Round 2
*------------------------------------------------------------------------------*
import delimited "${pathdataraw}\afb_full_r2.csv", clear 
drop if inlist(dateintr,"#NULL!") | inlist(country,"#NULL!")

* Generate country variable
gen country_name = substr(respno, 1, 3)	

* Generate time variable
split dateintr, parse("-")
gen year 	 = .
replace year = 2002 	if dateintr3=="02"
replace year = 2003 	if dateintr3=="03"
replace year = 2004 	if dateintr3=="04"
assert(mi(year)==0)

* Generate time variable
gen     quarter = 1 if inlist(dateintr2, "Jan", "Feb", "Mar")
replace quarter = 2 if inlist(dateintr2, "Apr", "May", "Jun")
replace quarter = 3 if inlist(dateintr2, "Jul", "Aug", "Sep")
replace quarter = 4 if inlist(dateintr2, "Oct", "Nov", "Dec")
assert(mi(quarter)==0)

tostring year, replace
tostring quarter, replace
gen time = year + quarter
destring time, replace

* Variable renames
rename *, lower
rename q89 	employment
rename q84 	education
rename q80	age

gen survey = 2

keep respno time country_name locationlevel1 latitude longitude survey townvill employment year dateintr age education precision_code
destring _all, replace
compress
tempfile data2
save `data2', replace
*------------------------------------------------------------------------------*
** Round 3
*------------------------------------------------------------------------------*
import delimited "${pathdataraw}\afb_full_r3.csv", clear 

* Generate country variable
gen country_name = substr(respno, 1, 3)	

* Generate time variable
drop if inlist(dateintr,"#NULL!")
split dateintr, parse("-")
gen year 	 = .
replace year = 2005 	if dateintr3=="05"
replace year = 2006 	if dateintr3=="06"

assert(mi(year)==0)

* Generate time variable
gen     quarter = 1 if inlist(dateintr2, "Jan", "Feb", "Mar")
replace quarter = 2 if inlist(dateintr2, "Apr", "May", "Jun")
replace quarter = 3 if inlist(dateintr2, "Jul", "Aug", "Sep")
replace quarter = 4 if inlist(dateintr2, "Oct", "Nov", "Dec")
assert(mi(quarter)==0)

tostring year, replace
tostring quarter, replace
gen time = year + quarter
destring time, replace



* Variable renames
rename *, lower
rename q94  employment
rename q90 	education
rename q1 	age
gen survey = 3

keep respno  time country_name townvill latitude longitude survey townvill employment year dateintr age education precision_code
destring _all, replace
compress
tempfile data3
save `data3', replace
*------------------------------------------------------------------------------*
** Round 4
*------------------------------------------------------------------------------*
import delimited "${pathdataraw}\afb_full_r4.csv", clear 

* Generate country variable
gen country_name = substr(respno, 1, 3)	

* Generate time variable
drop if inlist(dateintr,"#NULL!")
split dateintr, parse("-")
gen year 	 = .
replace year = 2008 	if dateintr3=="08"
replace year = 2009 	if dateintr3=="09"

assert(mi(year)==0)

* Generate time variable
gen     quarter = 1 if inlist(dateintr2, "Jan", "Feb", "Mar")
replace quarter = 2 if inlist(dateintr2, "Apr", "May", "Jun")
replace quarter = 3 if inlist(dateintr2, "Jul", "Aug", "Sep")
replace quarter = 4 if inlist(dateintr2, "Oct", "Nov", "Dec")
assert(mi(quarter)==0)

tostring year, replace
tostring quarter, replace
gen time = year + quarter
destring time, replace



* Variable renames
rename *, lower
rename q94 	employment
rename q89 	education
rename q88c internet
rename q88d commute10km
rename q1   age
gen survey = 4

keep respno  time  country_name townvill latitude longitude survey townvill employment year dateintr thisint age education internet commute10km precision_code
destring _all, replace
compress
tempfile data4
save `data4', replace
*------------------------------------------------------------------------------*
** Round 5
*------------------------------------------------------------------------------*
import delimited "${pathdataraw}\afb_full_r5.csv", clear 


* Generate country variable
gen country_name = substr(respno, 1, 3)	

* Generate time variable
drop if inlist(dateintr,"#NULL!")
split dateintr, parse("-")
gen year 	 = .
replace year = 2011 	if dateintr3=="11"
replace year = 2012 	if dateintr3=="12"
replace year = 2013 	if dateintr3=="13"
assert(mi(year)==0)

* Generate time variable
gen     quarter = 1 if inlist(dateintr2, "Jan", "Feb", "Mar")
replace quarter = 2 if inlist(dateintr2, "Apr", "May", "Jun")
replace quarter = 3 if inlist(dateintr2, "Jul", "Aug", "Sep")
replace quarter = 4 if inlist(dateintr2, "Oct", "Nov", "Dec")
assert(mi(quarter)==0)

tostring year, replace
tostring quarter, replace
gen time = year + quarter
destring time, replace


* Variable renames
rename *, lower
rename q1   age
rename q96 	employment
rename q97 	education
rename q91b internet
gen survey = 5

keep respno  time  country_name townvill locationlevel1 latitude longitude survey  townvill employment year dateintr thisint age education internet precision_code
destring _all, replace
compress
tempfile data5
save `data5', replace
*------------------------------------------------------------------------------*
** Round 6
*------------------------------------------------------------------------------*
import delimited "${pathdataraw}\afb_full_r6.csv", clear 

* Generate country variable
gen country_name = substr(respno, 1, 3)	

* Generate time variable
drop if inlist(dateintr,"#NULL!")
split dateintr, parse("-")
gen year 	 = .
replace year = 2014 	if dateintr3=="14"
replace year = 2015 	if dateintr3=="15"
assert(mi(year)==0)

* Generate time variable
gen     quarter = 1 if inlist(dateintr2, "Jan", "Feb", "Mar")
replace quarter = 2 if inlist(dateintr2, "Apr", "May", "Jun")
replace quarter = 3 if inlist(dateintr2, "Jul", "Aug", "Sep")
replace quarter = 4 if inlist(dateintr2, "Oct", "Nov", "Dec")
assert(mi(quarter)==0)

tostring year, replace
tostring quarter, replace
gen time = year + quarter
destring time, replace


* Variable renames
rename *, lower
rename q1  	age
rename q95 	employment
rename q97 	education
rename q92b internet
gen survey = 6

keep respno  time country_name locationlevel1 townvill latitude longitude survey townvill employment year dateintr thisint age education internet precision_code
destring _all, replace
compress
tempfile data6
save `data6', replace

*------------------------------------------------------------------------------*
** Append
*------------------------------------------------------------------------------*
clear all
use `data2', clear
append using `data3' ///
			 `data4' ///
			 `data5' ///
			 `data6' 
** Destring variables
destring _all ,replace
duplicates drop 

// Merge with distance
generate str name_string = respno
replace respno = ""
compress respno
replace respno = name_string
drop name_string
describe respno
merge 1:1 year respno country_name using "${pathtemp}\aid_distance.dta", keep(3) keepusing(distanceaid place_name) nogen


** Checking some consistency  
replace country_name = "LIB" if country_name=="LIb"
unique country_name
tab country_name survey
duplicates drop 

** Homogenize country names and codes
rename country code
gen country_name = ""
replace country = "algeria" if code == "ALG"
replace country = "burundi" if code == "BDI"
replace country = "benin" if code == "BEN"
replace country = "burkina faso" if code == "BFO"
replace country = "botswana" if code == "BOT"
replace country = "cameroon" if code == "CAM"
replace country = "ivory coast" if code == "CDI"
replace country = "cape verde" if code == "CVE"
replace country = "egypt" if code == "EGY"
replace country = "ethiopia" if code == "ETH"
replace country = "gabon" if code == "GAB"
replace country = "ghana" if code == "GHA"
replace country = "guinea" if code == "GUI"
replace country = "kenya" if code == "KEN"
replace country = "lesotho" if code == "LES"
replace country = "liberia" if code == "LIB"
replace country = "madagascar" if code == "MAD"
replace country = "mauritius" if code == "MAU"
replace country = "mali" if code == "MLI"
replace country = "malawi" if code == "MLW"
replace country = "morocco" if code == "MOR"
replace country = "mozambique" if code == "MOZ"
replace country = "mauritania" if code == "MRC"
replace country = "malawi" if code == "MWI"
replace country = "namibia" if code == "NAM"
replace country = "niger" if code == "NGR"
replace country = "nigeria" if code == "NIG"
replace country = "south africa" if code == "SAF"
replace country = "senegal" if code == "SEN"
replace country = "sri lanka" if code == "SRL"
replace country = "sao tome and principe" if code == "STP"
replace country = "sudan" if code == "SUD"
replace country = "swaziland" if code == "SWZ"
replace country = "tanzania" if code == "TAN"
replace country = "tanzania" if code == "TNZ"
replace country = "togo" if code == "TOG"
replace country = "tunisia" if code == "TUN"
replace country = "uganda" if code == "UGA"
replace country = "zambia" if code == "ZAM"
replace country = "zimbabwe" if code == "ZIM"

ren code country_code
** Labels
label var country_name 	"Country name - Afrobarometer"
label var country_code 	"Country code - Afrobarometer"
label var respno 		"Survey id    - Afrobarometer"
label var townvill 		"Name of village"
label var dateintr  	"Date of survey - Afrobarometer"
label var employment 	"Do you have a job that pays a cash income? If yes, is it full-time or part-time? If no, are you presently looking for a job?"
label var age 			"How old are you?"
label var education     "What is your highest level of education?"
label var latitude 		"Latitude Afrobarometer"
label var longitude 	"longitude Afrobarometer"
label var survey 		"Round of the survey"
label var internet 		"How often do you use: The Internet?"
label var commute10km	"How often do you travel 10 km?"
label var precision_code"precision code of geocoding"

sort year respno, stable
egen id  = group(year survey respno)
** Minimum requirement
* 1) Geolocalization
count if mi(latitude) | mi(longitude)
drop  if mi(latitude) | mi(longitude)
drop  if latitude==0 | longitude==0
* 2) Uniquely defined by id-year
bys country_name respno year: gen f = _N
tab f
drop if f!=1 
drop f

gen country = ""
replace country = "BJ" if country_name == "benin"
replace country = "BW" if country_name == "botswana"
replace country = "BF" if country_name == "burkina faso"
replace country = "GH" if country_name == "ghana"
replace country = "KE" if country_name == "kenya"
replace country = "LS" if country_name == "lesotho"
replace country = "MG" if country_name == "madagascar"
replace country = "ML" if country_name == "mali"
replace country = "MZ" if country_name == "mozambique"
replace country = "NG" if country_name == "nigeria"
replace country = "SN" if country_name == "senegal"
replace country = "ZA" if country_name == "south africa"
replace country = "TZ" if country_name == "tanzania"
replace country = "ZM" if country_name == "zambia"
replace country = "ZW" if country_name == "zimbabwe"

// Countries in the sample
gen tokeep 		= 1 if inlist(country, "BJ", "BW", "BF", "GH", "KE", "LS", "MG", "ML")
replace tokeep	= 1 if inlist(country, "MZ", "NG", "SN", "ZA", "TZ","ZM", "ZW")
keep if tokeep==1
drop tokeep

// Restricting to the year used in the paper
*keep if inrange(year, 2008,2014)
keep if inlist(year, 2008, 2011,2012,2013,2014)


*** Create outcome variables ***
gen employed = 1 if employment == 2 | employment == 3 | employment == 4 | employment == 5
replace employed = 0 if employment == 1 & employment != 9

gen employed2 = 1 if employment == 2 | employment == 3 | employment == 4 | employment == 5
replace employed2 = 0 if employment == 0 & employment != 9 | employment == 1 & employment != 9


*** Generate additative submarine cable indicator ***
gen cable20093 = 1 if country == "DJ" & time >= 20093 | country == "KE" & time >= 20093 | country == "MZ" & time >= 20093 | country == "TZ" & time >= 20093 | country == "ZA" & time >= 20093
replace cable20093 = 0 if cable20093 == .

gen cable20093_2 = 1 if country == "KE" & time >= 20093
replace cable20093_2 = 0 if cable20093_2 == .

gen cable20094 = 1 if country == "MU" & time >= 20094
replace cable20094 = 0 if cable20094 == .

gen cable20103 = 1 if country == "DJ" & time >= 20103 | country == "KE" & time >= 20103 | country == "KM" & time >= 20103 | country == "MG" & time >= 20103 | country == "MZ" & time >= 20103 | country == "SD" & time >= 20103 | country == "SO" & time >= 20103 | country == "TZ" & time >= 20103
replace cable20103 = 0 if cable20103 == .

gen cable20103_2 = 1 if country == "BF" & time >= 20103 | country == "BJ" & time >= 20103 | country == "CI" & time >= 20103 | country == "GH" & time >= 20103 | country == "MA" & time >= 20103 | country == "NG" & time >= 20103 | country == "SN" & time >= 20103 | country == "TG" & time >= 20103
replace cable20103_2 = 0 if cable20103_2 == .

gen cable20112 = 1 if country == "GH" & time >= 20112 | country == "MA" & time >= 20112 | country == "MR" & time >= 20112 | country == "NG" & time >= 20112 | country == "SN" & time >= 20112
replace cable20112 = 0 if cable20112 == .

gen cable20122 = 1 if country == "KE" & time >= 20122
replace cable20122 = 0 if cable20122 == .

gen cable20122_2 = 1 if country == "KE" & time >= 20122 | country == "RW" & time >= 20122 | country == "UG" & time >= 20122 | country == "ZA" & time >= 20122 | country == "ZW" & time >= 20122
replace cable20122_2 = 0 if cable20122_2 == .

gen cable20122_3 = 1 if country == "AO" & time >= 20122 | country == "CD" & time >= 20122 | country == "CG" & time >= 20122 | country == "CI" & time >= 20122 | country == "CM" & time >= 20122 | country == "CV" & time >= 20122 | country == "GA" & time >= 20122 | country == "GH" & time >= 20122 | country == "NA" & time >= 20122 | country == "NG" & time >= 20122 | country == "TG" & time >= 20122
replace cable20122_3 = 0 if cable20122_3 == .

gen cable20124 = 1 if country == "AO" & time >= 20124 | country == "BJ" & time >= 20124 | country == "CD" & time >= 20124 | country == "CI" & time >= 20124 | country == "CM" & time >= 20124 | country == "GA" & time >= 20124 | country == "GH" & time >= 20124 | country == "GM" & time >= 20124 | country == "GN" & time >= 20124 | country == "GQ" & time >= 20124 | country == "LR" & time >= 20124 | country == "MR" & time >= 20124 | country == "MR" & time >= 20124 | country == "NA" & time >= 20124 | country == "NG" & time >= 20124 | country == "SL" & time >= 20124 | country == "SN" & time >= 20124 | country == "ST" & time >= 20124
replace cable20124 = 0 if cable20124 == .



sort country year
egen submarines = rowtotal(cable20093 cable20093_2 cable20094 cable20103 cable20103_2 cable20112 cable20122 cable20122_2 cable20122_3 cable20124)

* grid size
glo	gridsize10 = 0.1 // side of each square in degrees
* generate grid cell variable
g 	latitude_grid10 = 100*${gridsize10}*round(latitude/${gridsize10})
g 	longitude_grid10 = 100*${gridsize10}*round(longitude/${gridsize10})
tostring latitude_grid10 longitude_grid10, replace force
g 	grid10 = latitude_grid10 + "_" + longitude_grid10

// Cells with requirement


** Treatment
sum distance*, d

replace submarines = 1 if submarines > 0
gen connected = 1 if distance <= 0.005
replace connected = 0 if connected == .
gen treatment = connected * submarines

egen country_year = group(country year)
egen grid_connect = group(grid connected)


* create educational variables to match those of dhs
gen noeducation = 1 if education == 0 | education == 1 | education == 2
replace noeducation = 0 if noeducation == . & education != 99
gen primary = 1 if education == 3 | education == 4
replace primary = 0 if primary == . & education != 99
gen secondary = 1 if education == 5
replace secondary = 0 if secondary == . & education != 99
gen higher = 1 if education == 6 | education == 7 | education == 8
replace higher = 0 if higher == . & education != 99

* interactions
gen intnoedu 	= treatment * noeducation
gen intprimary = treatment * primary
gen intsecondary = treatment * secondary
gen inthigh = treatment * higher

save "${pathdata}\afro_aid.dta", replace
