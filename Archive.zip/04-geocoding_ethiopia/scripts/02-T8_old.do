clear all
*cd "${id}"
*cd "C:\Users\giaco\Dropbox (UCL)\internet_replication"

* Load LMMIS data with old coords (hence connected and grid * connected)
use "${pathdataraw}\lmmis.dta", clear

* employment regs
areg l internet i.indyear if distance < 0.1, a(grid_connect) cluster(grid)
eststo reg1
areg l internet i.year if distance < 0.1, a(Id) cluster(grid)
eststo reg2

areg s internet i.indyear if distance < 0.1, a(grid_connect) cluster(grid)
eststo reg3
areg s internet i.year if distance < 0.1, a(Id) cluster(grid)
eststo reg4

areg u internet i.indyear if distance < 0.1, a(grid_connect) cluster(grid)
eststo reg5
areg u internet i.year if distance < 0.1, a(Id) cluster(grid)
eststo reg6

esttab reg2 reg1 reg4 reg3 reg6 reg5 using "${pathtab}\OLD_col1_6.csv" , replace l compress title("Employment results") ///
keep(internet) b(3) se(3) nomtitles nonotes star(* 0.10 ** 0.05 *** 0.01) 
eststo clear

* ols estimates
* the goal of this section is to compare the results to Ackerman
* note that Ackerman only provides OLS estimates in the main paper - LP is only in the appendix

areg y u s u_i s_i k internet i.indyear if distance < 0.1, a(grid_connect) cluster(grid)
eststo reg7

esttab reg7 using "${pathtab}\OLD_col7.csv" , replace l compress title("OLS estimates") ///
keep(_cons l u s k internet l_i u_i s_i int_k) order(_cons k l u s internet l_i u_i s_i int_k) b(3) se(3) nomtitles nonotes star(* 0.10 ** 0.05 *** 0.01) 
eststo clear

use "${pathdataraw}\lmmis.dta", clear

* FE's
xi i.year i.indcode i.grid_connect i.indyear, noomit

* first step: estimate labor coefficients
reg y u s u_i s_i k* m* _Iyear* _Iindcode* _Igrid* _Iindyear* if distance < 0.1, robust cluster(grid) /*Col5*/
esttab using "${pathtab}\OLD_col8.csv" , replace l compress keep(u s u_i s_i) b(3) se(3) nonotes title("LP labor estimates (SK)") star(* 0.10 ** 0.05 *** 0.01) 
eststo clear

* predict hat(y)
predict phi
replace phi=phi - _b[u]*u -_b[s]*s -_b[u_i]*u_i - _b[s_i]*s_i 
gen phi_lag=L.phi // NEED TO SORT DATA

gen k_lag=L.k
gen internet_lag=L.internet

drop _Iyear* _Iindco* _Igrid* _Iindyear*

* drop missing
sort Id year
drop if y==.
drop if k==.
drop if phi==.
drop if phi_lag==.

* reorganize indcode
egen group=group(indcode)
drop indcode
rename group indcode

* reorganize 10 x 10 km grid
egen group=group(grid)
drop grid
rename group grid

* FE's
xi i.year i.indcode i.grid_connect i.indyear, noomit


clear mata
mata :  mata set matastrict off, permanently 
mata
void GMM_LP_linear2(todo,betas,crit,g,H)
{
	PHI=st_data(.,("phi"))
	PHI_LAG=st_data(.,("phi_lag"))
	Z=st_data(.,("k")) // k in the moment condition
	X=st_data(.,("k")) // k
	X_lag=st_data(.,("k_lag"))
	yearFE=st_data(.,("_Iyear_2007","_Iyear_2008","_Iyear_2009","_Iyear_2010","_Iyear_2011","_Iyear_2012","_Iyear_2013"))
	indcodeFE=st_data(.,("_Iindcode_1","_Iindcode_2","_Iindcode_3","_Iindcode_4","_Iindcode_5","_Iindcode_6","_Iindcode_7","_Iindcode_8","_Iindcode_9", "_Iindcode_10",  ///
	"_Iindcode_11","_Iindcode_12","_Iindcode_13","_Iindcode_14","_Iindcode_15","_Iindcode_16","_Iindcode_17","_Iindcode_18","_Iindcode_19", "_Iindcode_20", ///
	"_Iindcode_21","_Iindcode_22","_Iindcode_23","_Iindcode_24","_Iindcode_25","_Iindcode_26","_Iindcode_27","_Iindcode_28","_Iindcode_29", "_Iindcode_30", ///
	"_Iindcode_31","_Iindcode_32","_Iindcode_33","_Iindcode_34","_Iindcode_35","_Iindcode_36","_Iindcode_37","_Iindcode_38","_Iindcode_39", "_Iindcode_40", ///
	"_Iindcode_41","_Iindcode_42","_Iindcode_43","_Iindcode_44","_Iindcode_45"))
	indyearFE1=st_data(.,("_Iindyear_2","_Iindyear_3","_Iindyear_4","_Iindyear_5","_Iindyear_6","_Iindyear_7","_Iindyear_8","_Iindyear_10","_Iindyear_11","_Iindyear_12","_Iindyear_13","_Iindyear_14","_Iindyear_15","_Iindyear_16","_Iindyear_18","_Iindyear_19","_Iindyear_20","_Iindyear_21","_Iindyear_22","_Iindyear_23","_Iindyear_24","_Iindyear_26","_Iindyear_27","_Iindyear_28","_Iindyear_29","_Iindyear_30","_Iindyear_31","_Iindyear_32","_Iindyear_35","_Iindyear_36","_Iindyear_38","_Iindyear_39","_Iindyear_40","_Iindyear_42","_Iindyear_43","_Iindyear_44","_Iindyear_45","_Iindyear_46","_Iindyear_47","_Iindyear_48","_Iindyear_50","_Iindyear_51","_Iindyear_52","_Iindyear_53","_Iindyear_54","_Iindyear_55","_Iindyear_57","_Iindyear_58","_Iindyear_59","_Iindyear_60","_Iindyear_61","_Iindyear_62","_Iindyear_63","_Iindyear_65","_Iindyear_66","_Iindyear_67","_Iindyear_68","_Iindyear_69","_Iindyear_70","_Iindyear_71","_Iindyear_73","_Iindyear_74","_Iindyear_75","_Iindyear_76","_Iindyear_77","_Iindyear_78","_Iindyear_79","_Iindyear_81","_Iindyear_82","_Iindyear_83","_Iindyear_84","_Iindyear_85","_Iindyear_86","_Iindyear_87","_Iindyear_89","_Iindyear_90","_Iindyear_91","_Iindyear_92","_Iindyear_93","_Iindyear_94","_Iindyear_95","_Iindyear_97","_Iindyear_98","_Iindyear_99","_Iindyear_100","_Iindyear_101","_Iindyear_102","_Iindyear_103","_Iindyear_105","_Iindyear_106","_Iindyear_107","_Iindyear_108","_Iindyear_109","_Iindyear_110"))
	indyearFE2=st_data(.,("_Iindyear_111","_Iindyear_113","_Iindyear_116","_Iindyear_117","_Iindyear_118","_Iindyear_120","_Iindyear_121","_Iindyear_124","_Iindyear_125","_Iindyear_126","_Iindyear_130","_Iindyear_131","_Iindyear_132","_Iindyear_133","_Iindyear_134","_Iindyear_135","_Iindyear_136","_Iindyear_138","_Iindyear_139","_Iindyear_140","_Iindyear_141","_Iindyear_142","_Iindyear_143","_Iindyear_144","_Iindyear_146","_Iindyear_147","_Iindyear_148","_Iindyear_149","_Iindyear_150","_Iindyear_151","_Iindyear_152","_Iindyear_154","_Iindyear_155","_Iindyear_156","_Iindyear_157","_Iindyear_158","_Iindyear_159","_Iindyear_161","_Iindyear_162","_Iindyear_163","_Iindyear_164","_Iindyear_165","_Iindyear_166","_Iindyear_169","_Iindyear_170","_Iindyear_171","_Iindyear_172","_Iindyear_173","_Iindyear_174","_Iindyear_175","_Iindyear_177","_Iindyear_178","_Iindyear_179","_Iindyear_180","_Iindyear_181","_Iindyear_182","_Iindyear_184","_Iindyear_185","_Iindyear_186","_Iindyear_187","_Iindyear_188","_Iindyear_189","_Iindyear_190","_Iindyear_192","_Iindyear_193","_Iindyear_194","_Iindyear_195","_Iindyear_196","_Iindyear_198","_Iindyear_200","_Iindyear_201","_Iindyear_202","_Iindyear_203","_Iindyear_204","_Iindyear_205","_Iindyear_206","_Iindyear_208","_Iindyear_209","_Iindyear_210","_Iindyear_211","_Iindyear_212","_Iindyear_215","_Iindyear_216","_Iindyear_217","_Iindyear_219","_Iindyear_220","_Iindyear_222","_Iindyear_223"))
	indyearFE3=st_data(.,("_Iindyear_224","_Iindyear_225","_Iindyear_226","_Iindyear_227","_Iindyear_228","_Iindyear_230","_Iindyear_231","_Iindyear_232","_Iindyear_233","_Iindyear_234","_Iindyear_236","_Iindyear_237","_Iindyear_238","_Iindyear_240","_Iindyear_243","_Iindyear_244","_Iindyear_245","_Iindyear_246","_Iindyear_247","_Iindyear_248","_Iindyear_249","_Iindyear_251","_Iindyear_252","_Iindyear_253","_Iindyear_254","_Iindyear_255","_Iindyear_256","_Iindyear_257","_Iindyear_259","_Iindyear_260","_Iindyear_261","_Iindyear_262","_Iindyear_263","_Iindyear_264","_Iindyear_265","_Iindyear_267","_Iindyear_268","_Iindyear_269","_Iindyear_270","_Iindyear_271","_Iindyear_272","_Iindyear_275","_Iindyear_276","_Iindyear_277","_Iindyear_278","_Iindyear_279","_Iindyear_280","_Iindyear_281","_Iindyear_283","_Iindyear_285","_Iindyear_286","_Iindyear_287","_Iindyear_288","_Iindyear_291","_Iindyear_292","_Iindyear_293","_Iindyear_294","_Iindyear_295","_Iindyear_298","_Iindyear_299","_Iindyear_300","_Iindyear_306","_Iindyear_307","_Iindyear_308","_Iindyear_311","_Iindyear_314","_Iindyear_315","_Iindyear_316","_Iindyear_318","_Iindyear_321","_Iindyear_322","_Iindyear_323","_Iindyear_326","_Iindyear_327","_Iindyear_328","_Iindyear_329","_Iindyear_330","_Iindyear_331","_Iindyear_332"))
	gridFE=st_data(.,("_Igrid_conn_1","_Igrid_conn_2","_Igrid_conn_3","_Igrid_conn_4","_Igrid_conn_5","_Igrid_conn_6","_Igrid_conn_7","_Igrid_conn_8","_Igrid_conn_9", "_Igrid_conn_10",  ///
	"_Igrid_conn_11","_Igrid_conn_12","_Igrid_conn_13","_Igrid_conn_14","_Igrid_conn_15","_Igrid_conn_16","_Igrid_conn_17","_Igrid_conn_18","_Igrid_conn_19", "_Igrid_conn_20", ///
	"_Igrid_conn_21","_Igrid_conn_22","_Igrid_conn_23","_Igrid_conn_24","_Igrid_conn_25","_Igrid_conn_26","_Igrid_conn_27","_Igrid_conn_28","_Igrid_conn_29", "_Igrid_conn_30", ///
	"_Igrid_conn_31","_Igrid_conn_32","_Igrid_conn_33","_Igrid_conn_34","_Igrid_conn_35","_Igrid_conn_36","_Igrid_conn_37","_Igrid_conn_38","_Igrid_conn_39", "_Igrid_conn_40", ///
	"_Igrid_conn_41","_Igrid_conn_42","_Igrid_conn_43","_Igrid_conn_44","_Igrid_conn_45","_Igrid_conn_46","_Igrid_conn_47","_Igrid_conn_48","_Igrid_conn_49","_Igrid_conn_50","_Igrid_conn_51","_Igrid_conn_53", "_Igrid_conn_54", ///
	"_Igrid_conn_55","_Igrid_conn_56","_Igrid_conn_57","_Igrid_conn_58","_Igrid_conn_59","_Igrid_conn_61","_Igrid_conn_62","_Igrid_conn_63","_Igrid_conn_64","_Igrid_conn_65","_Igrid_conn_66","_Igrid_conn_67","_Igrid_conn_68","_Igrid_conn_69","_Igrid_conn_70","_Igrid_conn_71","_Igrid_conn_72"))
	//FYI=st_data(.,("fyint"))
        //INT=st_data(.,("internet"))
	
	OMEGA=PHI-X*betas'
	OMEGA_lag=PHI_LAG-X_lag*betas'
	OMEGA_lag_pol=(yearFE,indcodeFE,gridFE,indyearFE1,indyearFE2,indyearFE3,OMEGA_lag)
	g_b = invsym(OMEGA_lag_pol'OMEGA_lag_pol)*OMEGA_lag_pol'OMEGA
	XI=OMEGA-OMEGA_lag_pol*g_b
	crit=(Z'XI)'(Z'XI)
}


void MODEL_LP_linear2()
{
S=optimize_init()
optimize_init_evaluator(S, &GMM_LP_linear2())
optimize_init_evaluatortype(S,"d0")
optimize_init_technique(S, "nm")
optimize_init_nmsimplexdeltas(S, 0.1)
optimize_init_which(S,"min")
optimize_init_params(S,(0.3))
p=optimize(S)
p
st_matrix("beta_lin",p)
}

end


* bootstrapped standard errors for capital
program drop _all
program define model_lp2, rclass
        mata: MODEL_LP_linear2()
        return scalar b1 = beta_lin[1,1]
end

xtset, clear
bootstrap b1=r(b1), reps(50) cluster(Id): model_lp2
esttab using "${pathtab}\OLD_col8_2.csv" , b(3) se(3) nolines replace title("LP Capital Estimate (SK)") nonotes

use "${pathdataraw}\lmmis.dta", clear


* second, interaction between skilled unskilled and internet

* FE's
xi i.year i.indcode i.grid_connect i.indyear, noomit

* first step: estimate labor coefficients
reg y u s u_i s_i k* m* internet _Iyear* _Iindcode* _Igrid* _Iindyear* if distance < 0.1, robust cluster(grid) /*Col6*/
esttab using "${pathtab}\OLD_col9.csv", replace l compress keep(u s u_i s_i) b(3) se(3) nonotes title("Adjusted LP labor estimates (SK)") star(* 0.10 ** 0.05 *** 0.01) 
eststo clear

* predict hat(y)
predict phi
replace phi=phi-_b[u]*u-_b[u_i]*u_i-_b[s]*s-_b[s_i]*s_i
gen phi_lag=L.phi

gen k_lag=L.k
gen internet_lag=L.internet

drop _Iyear* _Iindco* _Igrid* _Iindyear*

* drop missing
sort Id year
drop if k==.
drop if phi==.
drop if phi_lag==.

* reorganize indcode
egen group=group(indcode)
drop indcode
rename group indcode

* reorganize grid
egen group=group(grid)
drop grid
rename group grid

* FE's
xi i.year i.indcode i.grid_connect i.indyear, noomit
clear mata
mata:
void GMM_LP_linear2(todo,betas,crit,g,H)
{
	PHI=st_data(.,("phi"))
	PHI_LAG=st_data(.,("phi_lag"))
	Z=st_data(.,("k")) // k in the moment condition
	X=st_data(.,("k")) // k
	X_lag=st_data(.,("k_lag"))
	yearFE=st_data(.,("_Iyear_2007","_Iyear_2008","_Iyear_2009","_Iyear_2010","_Iyear_2011","_Iyear_2012","_Iyear_2013"))
	indcodeFE=st_data(.,("_Iindcode_1","_Iindcode_2","_Iindcode_3","_Iindcode_4","_Iindcode_5","_Iindcode_6","_Iindcode_7","_Iindcode_8","_Iindcode_9", "_Iindcode_10",  ///
	"_Iindcode_11","_Iindcode_12","_Iindcode_13","_Iindcode_14","_Iindcode_15","_Iindcode_16","_Iindcode_17","_Iindcode_18","_Iindcode_19", "_Iindcode_20", ///
	"_Iindcode_21","_Iindcode_22","_Iindcode_23","_Iindcode_24","_Iindcode_25","_Iindcode_26","_Iindcode_27","_Iindcode_28","_Iindcode_29", "_Iindcode_30", ///
	"_Iindcode_31","_Iindcode_32","_Iindcode_33","_Iindcode_34","_Iindcode_35","_Iindcode_36","_Iindcode_37","_Iindcode_38","_Iindcode_39", "_Iindcode_40", ///
	"_Iindcode_41","_Iindcode_42","_Iindcode_43","_Iindcode_44","_Iindcode_45"))
	indyearFE1=st_data(.,("_Iindyear_2","_Iindyear_3","_Iindyear_4","_Iindyear_5","_Iindyear_6","_Iindyear_7","_Iindyear_8","_Iindyear_10","_Iindyear_11","_Iindyear_12","_Iindyear_13","_Iindyear_14","_Iindyear_15","_Iindyear_16","_Iindyear_18","_Iindyear_19","_Iindyear_20","_Iindyear_21","_Iindyear_22","_Iindyear_23","_Iindyear_24","_Iindyear_26","_Iindyear_27","_Iindyear_28","_Iindyear_29","_Iindyear_30","_Iindyear_31","_Iindyear_32","_Iindyear_35","_Iindyear_36","_Iindyear_38","_Iindyear_39","_Iindyear_40","_Iindyear_42","_Iindyear_43","_Iindyear_44","_Iindyear_45","_Iindyear_46","_Iindyear_47","_Iindyear_48","_Iindyear_50","_Iindyear_51","_Iindyear_52","_Iindyear_53","_Iindyear_54","_Iindyear_55","_Iindyear_57","_Iindyear_58","_Iindyear_59","_Iindyear_60","_Iindyear_61","_Iindyear_62","_Iindyear_63","_Iindyear_65","_Iindyear_66","_Iindyear_67","_Iindyear_68","_Iindyear_69","_Iindyear_70","_Iindyear_71","_Iindyear_73","_Iindyear_74","_Iindyear_75","_Iindyear_76","_Iindyear_77","_Iindyear_78","_Iindyear_79","_Iindyear_81","_Iindyear_82","_Iindyear_83","_Iindyear_84","_Iindyear_85","_Iindyear_86","_Iindyear_87","_Iindyear_89","_Iindyear_90","_Iindyear_91","_Iindyear_92","_Iindyear_93","_Iindyear_94","_Iindyear_95","_Iindyear_97","_Iindyear_98","_Iindyear_99","_Iindyear_100","_Iindyear_101","_Iindyear_102","_Iindyear_103","_Iindyear_105","_Iindyear_106","_Iindyear_107","_Iindyear_108","_Iindyear_109","_Iindyear_110"))
	indyearFE2=st_data(.,("_Iindyear_111","_Iindyear_113","_Iindyear_116","_Iindyear_117","_Iindyear_118","_Iindyear_120","_Iindyear_121","_Iindyear_124","_Iindyear_125","_Iindyear_126","_Iindyear_130","_Iindyear_131","_Iindyear_132","_Iindyear_133","_Iindyear_134","_Iindyear_135","_Iindyear_136","_Iindyear_138","_Iindyear_139","_Iindyear_140","_Iindyear_141","_Iindyear_142","_Iindyear_143","_Iindyear_144","_Iindyear_146","_Iindyear_147","_Iindyear_148","_Iindyear_149","_Iindyear_150","_Iindyear_151","_Iindyear_152","_Iindyear_154","_Iindyear_155","_Iindyear_156","_Iindyear_157","_Iindyear_158","_Iindyear_159","_Iindyear_161","_Iindyear_162","_Iindyear_163","_Iindyear_164","_Iindyear_165","_Iindyear_166","_Iindyear_169","_Iindyear_170","_Iindyear_171","_Iindyear_172","_Iindyear_173","_Iindyear_174","_Iindyear_175","_Iindyear_177","_Iindyear_178","_Iindyear_179","_Iindyear_180","_Iindyear_181","_Iindyear_182","_Iindyear_184","_Iindyear_185","_Iindyear_186","_Iindyear_187","_Iindyear_188","_Iindyear_189","_Iindyear_190","_Iindyear_192","_Iindyear_193","_Iindyear_194","_Iindyear_195","_Iindyear_196","_Iindyear_198","_Iindyear_200","_Iindyear_201","_Iindyear_202","_Iindyear_203","_Iindyear_204","_Iindyear_205","_Iindyear_206","_Iindyear_208","_Iindyear_209","_Iindyear_210","_Iindyear_211","_Iindyear_212","_Iindyear_215","_Iindyear_216","_Iindyear_217","_Iindyear_219","_Iindyear_220","_Iindyear_222","_Iindyear_223"))
	indyearFE3=st_data(.,("_Iindyear_224","_Iindyear_225","_Iindyear_226","_Iindyear_227","_Iindyear_228","_Iindyear_230","_Iindyear_231","_Iindyear_232","_Iindyear_233","_Iindyear_234","_Iindyear_236","_Iindyear_237","_Iindyear_238","_Iindyear_240","_Iindyear_243","_Iindyear_244","_Iindyear_245","_Iindyear_246","_Iindyear_247","_Iindyear_248","_Iindyear_249","_Iindyear_251","_Iindyear_252","_Iindyear_253","_Iindyear_254","_Iindyear_255","_Iindyear_256","_Iindyear_257","_Iindyear_259","_Iindyear_260","_Iindyear_261","_Iindyear_262","_Iindyear_263","_Iindyear_264","_Iindyear_265","_Iindyear_267","_Iindyear_268","_Iindyear_269","_Iindyear_270","_Iindyear_271","_Iindyear_272","_Iindyear_275","_Iindyear_276","_Iindyear_277","_Iindyear_278","_Iindyear_279","_Iindyear_280","_Iindyear_281","_Iindyear_283","_Iindyear_285","_Iindyear_286","_Iindyear_287","_Iindyear_288","_Iindyear_291","_Iindyear_292","_Iindyear_293","_Iindyear_294","_Iindyear_295","_Iindyear_298","_Iindyear_299","_Iindyear_300","_Iindyear_306","_Iindyear_307","_Iindyear_308","_Iindyear_311","_Iindyear_314","_Iindyear_315","_Iindyear_316","_Iindyear_318","_Iindyear_321","_Iindyear_322","_Iindyear_323","_Iindyear_326","_Iindyear_327","_Iindyear_328","_Iindyear_329","_Iindyear_330","_Iindyear_331","_Iindyear_332"))
	gridFE=st_data(.,("_Igrid_conn_1","_Igrid_conn_2","_Igrid_conn_3","_Igrid_conn_4","_Igrid_conn_5","_Igrid_conn_6","_Igrid_conn_7","_Igrid_conn_8","_Igrid_conn_9", "_Igrid_conn_10",  ///
	"_Igrid_conn_11","_Igrid_conn_12","_Igrid_conn_13","_Igrid_conn_14","_Igrid_conn_15","_Igrid_conn_16","_Igrid_conn_17","_Igrid_conn_18","_Igrid_conn_19", "_Igrid_conn_20", ///
	"_Igrid_conn_21","_Igrid_conn_22","_Igrid_conn_23","_Igrid_conn_24","_Igrid_conn_25","_Igrid_conn_26","_Igrid_conn_27","_Igrid_conn_28","_Igrid_conn_29", "_Igrid_conn_30", ///
	"_Igrid_conn_31","_Igrid_conn_32","_Igrid_conn_33","_Igrid_conn_34","_Igrid_conn_35","_Igrid_conn_36","_Igrid_conn_37","_Igrid_conn_38","_Igrid_conn_39", "_Igrid_conn_40", ///
	"_Igrid_conn_41","_Igrid_conn_42","_Igrid_conn_43","_Igrid_conn_44","_Igrid_conn_45","_Igrid_conn_46","_Igrid_conn_47","_Igrid_conn_48","_Igrid_conn_49","_Igrid_conn_50","_Igrid_conn_51","_Igrid_conn_53", "_Igrid_conn_54", ///
	"_Igrid_conn_55","_Igrid_conn_56","_Igrid_conn_57","_Igrid_conn_58","_Igrid_conn_59","_Igrid_conn_61","_Igrid_conn_62","_Igrid_conn_63","_Igrid_conn_64","_Igrid_conn_65","_Igrid_conn_66","_Igrid_conn_67","_Igrid_conn_68","_Igrid_conn_69","_Igrid_conn_70","_Igrid_conn_71","_Igrid_conn_72"))
	//FYI=st_data(.,("fyint"))
	//FYI=st_data(.,("fyint"))
        INT=st_data(.,("internet"))
	
	OMEGA=PHI-X*betas'
	OMEGA_lag=PHI_LAG-X_lag*betas'
	OMEGA_lag_pol=(yearFE,indcodeFE,gridFE,indyearFE1,indyearFE2,indyearFE3,OMEGA_lag,INT)
	g_b = invsym(OMEGA_lag_pol'OMEGA_lag_pol)*OMEGA_lag_pol'OMEGA
	XI=OMEGA-OMEGA_lag_pol*g_b
	crit=(Z'XI)'(Z'XI)
}


void MODEL_LP_linear2()
{
S=optimize_init()
optimize_init_evaluator(S, &GMM_LP_linear2())
optimize_init_evaluatortype(S,"d0")
optimize_init_technique(S, "nm")
optimize_init_nmsimplexdeltas(S, 0.1)
optimize_init_which(S,"min")
optimize_init_params(S,(0.3))
p=optimize(S)
p
st_matrix("beta_lin",p)
}

end

* second step: estimate productivity coefficient
mata MODEL_LP_linear2()
gen betak=beta_lin[1,1]
gen omega_l=phi-betak*k

reg omega_l L.omega_l internet _Iyear* _Iindcode* _Igrid* _Iindyear* if distance < 0.1, nocons robust cluster(grid) /*productivity*/
esttab using "${pathtab}\OLD_col9_3.csv", replace l compress keep(L.omega_l internet) b(3) se(3) nonotes title("Adjusted LP Productivity and Internet Estimates (SK)") star(* 0.10 ** 0.05 *** 0.01)
eststo clear

* bootstrapped standard errors for capital
program drop _all
program define model_lp2, rclass
        mata: MODEL_LP_linear2()
        return scalar b1 = beta_lin[1,1]
end

xtset, clear
bootstrap b1=r(b1), reps(50) cluster(Id): model_lp2
esttab using "${pathtab}\OLD_col9_2.csv", b(3) se(3) replace title("Adjusted LP Capital Estimate (SK)") nonotes

