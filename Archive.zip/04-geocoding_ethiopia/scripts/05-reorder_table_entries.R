rm(list=ls())
setwd("C:/Users/emiliogu/Dropbox/internet_replication/newpackage/replies-to-replicators/04-geocoding_ethiopia/results/Tables")
#setwd("C:/Users/giaco/Dropbox (UCL)/internet_replication/replies-to-replicators/06-geocoding_ethiopia/tables")

library(dplyr)

# Load AER table entries (capital is off)
OLD_col1_6 <- read.csv("OLD_col1_6.csv", header=FALSE, row.names=NULL)
OLD_col7 <- read.csv("OLD_col7.csv", header=FALSE, row.names=NULL)
OLD_col8 <- read.csv("OLD_col8.csv", header=FALSE, row.names=NULL)
OLD_col8_2 <- read.csv("OLD_col8_2.csv", header=FALSE, row.names=NULL)
OLD_col9 <- read.csv("OLD_col9.csv", header=FALSE, row.names=NULL)
OLD_col9_2 <- read.csv("OLD_col9_2.csv", header=FALSE, row.names=NULL)
OLD_col9_3 <- read.csv("OLD_col9_3.csv", header=FALSE, row.names=NULL)

# Load DR table entries (with DR's geocoding)
DR_col1_6 <- read.csv("DR_col1_6.csv", header=FALSE, row.names=NULL)
DR_col7 <- read.csv("DR_col7.csv", header=FALSE, row.names=NULL)
DR_col8 <- read.csv("DR_col8.csv", header=FALSE, row.names=NULL)
DR_col8_2 <- read.csv("DR_col8_2.csv", header=FALSE, row.names=NULL)
DR_col9 <- read.csv("DR_col9.csv", header=FALSE, row.names=NULL)
DR_col9_2 <- read.csv("DR_col9_2.csv", header=FALSE, row.names=NULL)
DR_col9_3 <- read.csv("DR_col9_3.csv", header=FALSE, row.names=NULL)

# Load NEW table entries (with new geocoding)
NEW_col1_6 <- read.csv("NEW_col1_6.csv", header=FALSE, row.names=NULL)
NEW_col7 <- read.csv("NEW_col7.csv", header=FALSE, row.names=NULL)
NEW_col8 <- read.csv("NEW_col8.csv", header=FALSE, row.names=NULL)
NEW_col8_2 <- read.csv("NEW_col8_2.csv", header=FALSE, row.names=NULL)
NEW_col9 <- read.csv("NEW_col9.csv", header=FALSE, row.names=NULL)
NEW_col9_2 <- read.csv("NEW_col9_2.csv", header=FALSE, row.names=NULL)
NEW_col9_3 <- read.csv("NEW_col9_3.csv", header=FALSE, row.names=NULL)

render_dataframe <- function(col1_6, col7, col8, col8_2, col9, col9_2, col9_3) {
  
  # Columns 1--6
  internet_1 <- rbind(gsub("=", "", col1_6[c(3), c(2:7)]),
                      gsub("=", "", col1_6[c(4), c(2:7)]))
  obs_1 <- gsub("=", "", col1_6[c(5), c(2:7)])
  all_1 <- rbind(internet_1, c(""), c(""), c(""), c(""), c(""), c(""), c(""), c(""),
                 c(""), c(""), c(""), c(""), c(""), c(""), c(""), c(""), c(""), c(""),
                 obs_1)
  
  # Column 7
  internet_7 <- gsub("=", "", col7[c(5:23), 2])
  all_7 <- c(c(""), c(""), internet_7[c(1,2,5:8)],
             c(""), c(""), internet_7[c(13:16)],
             c("No"), c("No"), c(""), c(""), c(""), c(""), internet_7[c(19)])
  
  # Column 8
  unskilled_8 <- gsub("=", "", col8[c(4:11), 2])
  capital_8 <- gsub("=", "", col8_2[c(4,5), 2])
  obs_8 <- gsub("=", "", col8[12, 2])
  all_8 <- c(c(""), c(""), capital_8, unskilled_8[c(1:4)],
             c(""), c(""), unskilled_8[c(5:8)],
             c("Yes"), c("No"), c(""),  c(""), c(""), c(""), obs_8)
  
  # Column 9
  unskilled_9 <- gsub("=", "", col9[c(4:11), 2])
  capital_9 <- gsub("=", "", col9_2[c(4,5), 2])
  productivity_9 <- gsub("=", "", col9_3[c(6,7), 2])
  obs_9 <- gsub("=", "", col9[12, 2])
  all_9 <- c(c(""), c(""), capital_9, unskilled_9[c(1:4)],
             c(""), c(""), unskilled_9[c(5:8)],
             c("Yes"), c("Yes"), c(""), c("Productivity"), productivity_9, obs_9)
  
  # Assemble final dataset
  all <- data.frame(cbind(all_1, V7 = all_7, V8 = all_8, all_9))
  all_names <- data.frame(names = c("SMCs X Connected", "", "Capital", "", "Unskilled", "",
                      "Skilled", "", "", "SMCs X Connected", "X Unskilled", "",
                      "X Skilled", "", "Control for Productivity", "Control for SMCs",
                      "X Connected X Productivity", "Outcome", "SMCs X Connected",
                      "", "Observations"), all)
  return(all_names)
  
}

# Render AER; DR; and NEW tables as dataframe from reg output
aer <- render_dataframe(OLD_col1_6, OLD_col7, OLD_col8, OLD_col8_2,
                        OLD_col9, OLD_col9_2, OLD_col9_3)
dr <- render_dataframe(DR_col1_6, DR_col7, DR_col8, DR_col8_2,
                       DR_col9, DR_col9_2, DR_col9_3)
new <- render_dataframe(NEW_col1_6, NEW_col7, NEW_col8, NEW_col8_2,
                        NEW_col9, NEW_col9_2, NEW_col9_3)

# Convert the output to a .TeX file
to_latex <- function(data) {
  
  # Function to format data frame row as a LaTeX table row
  format_row <- function(row_data, row_name){
    row_string <- paste(row_data, collapse = " & ")
    return(paste(row_name, " & ", row_string, " \\\\"))
  }
  
  # Define row names
  row_names <- c("SMCs X Connected", "",
                 "Capital", "",
                 "Unskilled", "",
                 "Skilled", "", "", "SMCs X Connected", "X Unskilled", "",
                 "X Skilled", "", "Control for Productivity", "Control for SMCs",
                 "X Connected X Productivity", "Outcome", "SMCs X Connected",
                 "", "Observations")
  
  # Format each row
  rows <- mapply(format_row, as.data.frame(t(data[,-c(1)])), row_names, USE.NAMES = FALSE)
  
  # Begin constructing the LaTeX table string
  latex_entries <- paste(
    rows[1], rows[2], # SMCs X Connected
    rows[3], rows[4], # Capital
    rows[5], rows[6], # Unskilled
    rows[7], rows[8], # Skilled
    rows[9], rows[10], rows[11], rows[12], # SMCs X Connected X Unskilled
    rows[13], rows[14], # SMCs X Connected X Skilled
    rows[15], rows[16], rows[17], rows[18], # Controls
    rows[19], rows[20], # Outcome
    "\\\\", # Empty line
    rows[21],# Observations
    sep = "\n")
  
  return(latex_entries)
}
latex_aer <- to_latex(aer)
latex_dr <- to_latex(dr)
latex_new <- to_latex(new)
writeLines(latex_aer, "T8_OLD.tex")
writeLines(latex_dr, "T8_DR.tex")
writeLines(latex_new, "T8_NEW.tex")
