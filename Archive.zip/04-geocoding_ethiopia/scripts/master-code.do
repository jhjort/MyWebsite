*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
version 17.0
*version 18.0
clear all
macro drop _all 
cap log close

********************************************************************************
** # 0. Setting 
********************************************************************************

local PC = "EGUIO"

if "`PC'"=="EG"{
	global id = "C:\Users\ASUS\Dropbox\internet_replication\newpackage\replies-to-replicators\04-geocoding_ethiopia"
} 
if "`PC'"=="EGUIO"{
	global id = "C:\Users\emiliogu\Dropbox\internet_replication\newpackage\replies-to-replicators\04-geocoding_ethiopia"
} 

cd "${id}"
global pathdo 	   = "${id}\scripts"
global pathtemp    = "${id}\processed"
global pathout 	   = "${id}\results"
global pathfig	   = "${id}\results\Figures"
global pathtab     = "${id}\results\Tables"
global pathdataraw = "${id}\raw_data"
global pathdata    = "${id}\final"

* Folders creation
cap mkdir "${pathdo}"
cap mkdir "${pathtemp}"
cap mkdir "${pathout}"
cap mkdir "${pathfig}"
cap mkdir "${pathtab}"
cap mkdir "${pathdata}"
cap mkdir "${pathdataraw}"


********************************************************************************
* # 1.- Tables and Figures
********************************************************************************
*NOTE: The directory "C:\Program Files\R\R-4.3.2\bin\x64\R.exe" should be modified according to the location of R in the replicator's computer

* # Produces new Afro geocoding
shell "C:\Program Files\R\R-4.3.2\bin\x64\R.exe" CMD BATCH "${pathdo}\01-geocoding2023.R"
*Uses Google API Key
*Produces LMMIS_new_geocoding.dta

* # T8 Old
do "${pathdo}\02-T8_old.do"
/*This generates: 
OLD_col1_6.csv, OLD_col7.csv
OLD_col8.csv
OLD_col8_2.csv
OLD_col9.csv
OLD_col9_3.csv
OLD_col9_2.csv
*/


* # T8 New
do "${pathdo}\03-T8_new.do"
/*
This generates:
NEW_col1_6.csv
NEW_col7.csv
NEW_col8.csv
NEW_col8_2.csv
NEW_col9.csv
NEW_col9_3.csv
NEW_col9_2.csv
lmmis_new.dta
*/


* # T8 DR
do "${pathdo}\04-T8_DR.do"
/*
This generates:
DR_col1_6.csv
DR_col7.csv
DR_col8.csv
DR_col8_2.csv
DR_col9.csv
DR_col9_3.csv
DR_col9_2.csv
lmmis_DR.dta
*/

* # 05-reorder_table_entries
shell "C:\Program Files\R\R-4.3.2\bin\x64\R.exe" CMD BATCH "${pathdo}\05-reorder_table_entries.R"
/*Produces
T8_OLD.tex
T8_DR.tex
T8_NEW.tex
*/






