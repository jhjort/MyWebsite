# Store dataset with NEW Geocoding
# and add sitances to Roodman's geocoding

# Set working directory - and clean environment
rm(list=ls())
setwd("C:/Users/emiliogu/Dropbox/internet_replication") # DB directory
#setwd("C:/Users/giaco/Dropbox (UCL)/internet_replication") # DB directory

# Load required packages
library(sf)
library(geosphere)
library(tools)
library(dplyr)
library(haven)
library(ggmap) # Maps API

# Load Google Maps API key
register_google(key = "00000000000000") # key has to be valid and active

# Load LMMIS Datasets -- on AER and Patrick
final <- read_dta("internet_replication/newpackage/replies-to-replicators/04-geocoding_ethiopia/raw_data/lmmis.dta")
patrick <- read_dta("internet_replication/newpackage/replies-to-replicators/04-geocoding_ethiopia/raw_data/ethfinal.dta")

# Load SS2014 w/o Ghana NITA (but with, e.g., SA-DFA)
ss_cables <- st_read("internet_replication/newpackage/replies-to-replicators/04-geocoding_ethiopia/raw_data/ss_cables.shp")

# Keep only unique locations (disregard worcode, has different cities for weird spelling, e.g., /TOWN/)
final_clean <- final[!duplicated(final[, c("Regcode", "Zoncode", "Worcode", "city")]), # city instead of Worcode
                     c("Regcode", "Zoncode", "Worcode", "city", "distance")]
patrick_clean <- patrick[!duplicated(patrick[, c("Regcode", "Zoncode", "Worcode", "city")]),
                         c("Regcode", "Zoncode", "Worcode", "city", "distance", "longitude", "latitude")]

# Retrieve coords from Patrick for final cities
coords <- merge(final_clean,
                patrick_clean[,c("Regcode", "Zoncode", "Worcode",
                                 "city", "longitude", "latitude")], # take distance from final_clean
                all.x = T, all.y = F)
sum(is.na(coords$longitude)) + sum(is.na(coords$latitude)) # all coords available

# Re-compute distances to check network used
shortest_distance <- function(data, network, distance_col) {
  
  # Define data as SF object with GIS info
  data_sf <- st_as_sf(data, coords = c("longitude", "latitude"))
  
  # Render sf_infrastructure with NA CRS to get angular distances
  st_crs(network) <- NA
  
  # Compute closest distance
  distance_matrix <- st_distance(data_sf, network)
  data[[distance_col]] <- apply(distance_matrix, 1, min)
  
  return(data)
}
coords <- shortest_distance(coords, ss_cables, "dist_ss")
hist(coords$dist_ss - coords$distance) # basically 0 -- so ss_cables (in Ethipia) likely corresponds to network used

# Construct address (ignore Worcode, same as city)
factor_woreda <- data.frame(
  Worcode = as_factor(coords$Worcode),
  Zoncode = as_factor(coords$Zoncode),
  Regcode = as_factor(coords$Regcode)) # retrieve these
coords$address <- paste(
  toTitleCase(tolower(as.character(coords$city))),
  toTitleCase(tolower(as.character(factor_woreda$Zoncode))),
  toTitleCase(tolower(as.character(factor_woreda$Regcode))),
  "Ethiopia, Africa", sep = ", ")

# Geocode using Maps API
coords_geo <-  geocode(location = coords$address, output = "latlon")
sum(is.na(coords_geo$lon)) + sum(is.na(coords_geo$lat)) # all coords are geocoded for

# Compute distance to the network using new locations
coords_geo <- coords_geo %>% rename(longitude = lon, latitude = lat)
coords_geo <- shortest_distance(coords_geo, ss_cables, "distance")

# Save new dataset as DTA
save <- cbind(coords_geo, coords[,c("city", "Zoncode", "Regcode", "Worcode")])
write_dta(save, "internet_replication/newpackage/replies-to-replicators/04-geocoding_ethiopia/processed/LMMIS_new_geocoding.dta")
