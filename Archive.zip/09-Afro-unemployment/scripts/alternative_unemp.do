
*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
version 17.0
clear all
macro drop _all 
cap log close

********************************************************************************
** # 0. Setting 
********************************************************************************
local PC = "EGUIO"

if "`PC'"=="EG"{
	global id = "C:\Users\ASUS\Dropbox\internet_replication\newpackage\replies-to-replicators\09-Afro-unemployment"
} 
if "`PC'"=="EGUIO"{
	global id = "C:\Users\emiliogu\Dropbox\internet_replication\newpackage\replies-to-replicators\09-Afro-unemployment"
} 

cd "${id}"
global pathdo 	   = "${id}\scripts"
global pathtemp    = "${id}\processed"
global pathout 	   = "${id}\results"
global pathfig	   = "${id}\results\Figures"
global pathtab     = "${id}\results\Tables"
global pathdataraw = "${id}\raw_data"
global pathdata    = "${id}\final"

* Folders creation
cap mkdir "${pathdo}"
cap mkdir "${pathtemp}"
cap mkdir "${pathout}"
cap mkdir "${pathfig}"
cap mkdir "${pathtab}"
cap mkdir "${pathdata}"
cap mkdir "${pathdataraw}"

********************************************************************************
* # 1.- Tables
********************************************************************************

use "${pathdataraw}\afro_res_final.dta"

/*

            Tabulation: Freq.   Numeric  Label
                            8        -1  Missing
                        4,194         0  No (not looking)
                        4,437         1  No (looking)
                        1,560         2  Yes, part time (not looking)
                        2,945         3  Yes, part time (looking)
                        1,115         4  Yes, full time (not looking)
                          563         5  Yes, full time (looking)
                           48         9  Don't know

*/

*** Create outcome variables ***
cap drop employed employed2
gen employed = 1 if employment == 2 | employment == 3 | employment == 4 | employment == 5
replace employed = 0 if employment == 1

gen employed2 = 1 if employment == 2 | employment == 3 | employment == 4 | employment == 5
replace employed2 = 0 if employment == 0 | employment == 1

* country x time FE's
drop country_year
egen country_year = group(country year)

* grid-cell x connected FE's
drop grid_connect
egen grid_connect = group(grid10 connected)


*T3 estimate under original definition of unemployment
areg employed treatment i.country_year if employment != -9 & age < 65 & distance < 0.1, a(grid_connect) cluster(grid10)
estadd ysumm, mean
eststo reg1

*T3 estimate under broader definition of unemployment
areg employed2 treatment i.country_year if employment != -9 & age < 65 & distance < 0.1, a(grid_connect) cluster(grid10)
estadd ysumm, mean
eststo reg2


*Mean of outcome under alternative defintion: 0.43
*Estimated pp increase: 0.065
*SE: 0.034
*Percentage increase evaluated at the mean: 14.92 %

*Export results\Figures
esttab reg2 using "${pathtab}\afro_unemp.tex", replace se b(3) stats(N ymean, fmt(0  %9.2f)  labels("Observations" "Mean of Outcome")) label alignment(center) nogaps fragment nonumbers mlabels(none) drop(*year* _cons) collabels()  nocon starlevels(* 0.10 ** 0.05 *** 0.01) nolines



