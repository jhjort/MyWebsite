
********************************************************************
** #Construct Afro dataset using paper distances and new grid filter
********************************************************************

use "${pathdataraw}\original\afro_distances_final_paper.dta", replace

replace country = "BJ" if country == "benin"
replace country = "BW" if country == "botswana"
replace country = "BF" if country == "burkina faso"
replace country = "GH" if country == "ghana"
replace country = "KE" if country == "kenya"
replace country = "LS" if country == "lesotho"
replace country = "MG" if country == "madagascar"
replace country = "ML" if country == "mali"
replace country = "MZ" if country == "mozambique"
replace country = "NG" if country == "nigeria"
replace country = "SN" if country == "senegal"
replace country = "ZA" if country == "south africa"
replace country = "TZ" if country == "tanzania"
replace country = "ZM" if country == "zambia"
replace country = "ZW" if country == "zimbabwe"

merge m:m country survey townvill using "${pathdataraw}\original\afromerge.dta"
keep if _merge == 3
drop _merge


*** Create outcome variables ***
gen employed = 1 if employment == 2 | employment == 3 | employment == 4 | employment == 5
replace employed = 0 if employment == 1 & employment != 9

gen employed2 = 1 if employment == 2 | employment == 3 | employment == 4 | employment == 5
replace employed2 = 0 if employment == 0 & employment != 9 | employment == 1 & employment != 9

*** Generate additative submarine cable indicator ***
gen cable20093 = 1 if country == "DJ" & time >= 20093 | country == "KE" & time >= 20093 | country == "MZ" & time >= 20093 | country == "TZ" & time >= 20093 | country == "ZA" & time >= 20093
replace cable20093 = 0 if cable20093 == .

gen cable20093_2 = 1 if country == "KE" & time >= 20093
replace cable20093_2 = 0 if cable20093_2 == .

gen cable20094 = 1 if country == "MU" & time >= 20094
replace cable20094 = 0 if cable20094 == .

gen cable20103 = 1 if country == "DJ" & time >= 20103 | country == "KE" & time >= 20103 | country == "KM" & time >= 20103 | country == "MG" & time >= 20103 | country == "MZ" & time >= 20103 | country == "SD" & time >= 20103 | country == "SO" & time >= 20103 | country == "TZ" & time >= 20103
replace cable20103 = 0 if cable20103 == .

gen cable20103_2 = 1 if country == "BF" & time >= 20103 | country == "BJ" & time >= 20103 | country == "CI" & time >= 20103 | country == "GH" & time >= 20103 | country == "MA" & time >= 20103 | country == "NG" & time >= 20103 | country == "SN" & time >= 20103 | country == "TG" & time >= 20103
replace cable20103_2 = 0 if cable20103_2 == .

gen cable20112 = 1 if country == "GH" & time >= 20112 | country == "MA" & time >= 20112 | country == "MR" & time >= 20112 | country == "NG" & time >= 20112 | country == "SN" & time >= 20112
replace cable20112 = 0 if cable20112 == .

gen cable20122 = 1 if country == "KE" & time >= 20122
replace cable20122 = 0 if cable20122 == .

gen cable20122_2 = 1 if country == "KE" & time >= 20122 | country == "RW" & time >= 20122 | country == "UG" & time >= 20122 | country == "ZA" & time >= 20122 | country == "ZW" & time >= 20122
replace cable20122_2 = 0 if cable20122_2 == .

gen cable20122_3 = 1 if country == "AO" & time >= 20122 | country == "CD" & time >= 20122 | country == "CG" & time >= 20122 | country == "CI" & time >= 20122 | country == "CM" & time >= 20122 | country == "CV" & time >= 20122 | country == "GA" & time >= 20122 | country == "GH" & time >= 20122 | country == "NA" & time >= 20122 | country == "NG" & time >= 20122 | country == "TG" & time >= 20122
replace cable20122_3 = 0 if cable20122_3 == .

gen cable20124 = 1 if country == "AO" & time >= 20124 | country == "BJ" & time >= 20124 | country == "CD" & time >= 20124 | country == "CI" & time >= 20124 | country == "CM" & time >= 20124 | country == "GA" & time >= 20124 | country == "GH" & time >= 20124 | country == "GM" & time >= 20124 | country == "GN" & time >= 20124 | country == "GQ" & time >= 20124 | country == "LR" & time >= 20124 | country == "MR" & time >= 20124 | country == "MR" & time >= 20124 | country == "NA" & time >= 20124 | country == "NG" & time >= 20124 | country == "SL" & time >= 20124 | country == "SN" & time >= 20124 | country == "ST" & time >= 20124
replace cable20124 = 0 if cable20124 == .

* grid size
glo	gridsize = 0.1 // side of each square in degrees
* generate grid cell variable
g 	latitude_grid = 100*${gridsize}*round(latitude/${gridsize})
g 	longitude_grid = 100*${gridsize}*round(longitude/${gridsize})
tostring latitude_grid longitude_grid, replace force
g 	grid = latitude_grid + "_" + longitude_grid


sort country grid time
egen submarines = rowtotal(cable20093 cable20093_2 cable20094 cable20103 cable20103_2 cable20112 cable20122 cable20122_2 cable20122_3 cable20124)


drop if distance < 0

*Keep two observations per grid cell
preserve,
gen count = 1
collapse (mean) count, by(grid year)
duplicates tag grid, gen(tag)
keep if tag== 1 
keep grid year
tempfile to_keep
save `to_keep', replace
restore

merge m:1 grid year using `to_keep', keep(3) nogen


replace submarines = 1 if submarines > 0
gen connected = 1 if distance <= 0.005
replace connected = 0 if connected == .
gen treatment = connected * submarines

egen country_year = group(country year)
egen grid_connect = group(grid connected)


areg employed treatment i.country_year if employment != -9 & q1 < 65 & distance < 0.1, a(grid_connect) cluster(grid)


* create educational variables to match those of dhs
gen noeducation = 1 if education == 0 | education == 1 | education == 2
replace noeducation = 0 if noeducation == . & education != 99
gen primary = 1 if education == 3 | education == 4
replace primary = 0 if primary == . & education != 99
gen secondary = 1 if education == 5
replace secondary = 0 if secondary == . & education != 99
gen higher = 1 if education == 6 | education == 7 | education == 8
replace higher = 0 if higher == . & education != 99

* interactions
gen intnoedu 	= treatment * noeducation
gen intprimary = treatment * primary
gen intsecondary = treatment * secondary
gen inthigh = treatment * higher

rename q1 age

set matsize 11000

reg employed2 noeducation primary secondary higher intnoedu intprimary intsecondary inthigh i.country_year i.grid_connect if employment != -9 & age < 65 & distance < 0.1, nocons cluster(grid)


* grid size
glo	gridsize10 = 0.1 // side of each square in degrees
* generate grid cell variable
g 	latitude_grid10 = 100*${gridsize10}*round(latitude/${gridsize10})
g 	longitude_grid10 = 100*${gridsize10}*round(longitude/${gridsize10})
tostring latitude_grid10 longitude_grid10, replace force
g 	grid10 = latitude_grid10 + "_" + longitude_grid10

save "${pathdata}\afhp19", replace

