*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
version 17.0
*version 18.0
clear all
macro drop _all 
cap log close

********************************************************************************
** # 0. Setting 
********************************************************************************

local PC = "EGUIO"

if "`PC'"=="EG"{
	global id = "C:\Users\ASUS\Dropbox\internet_replication\newpackage\replies-to-replicators\08-T4C4"
} 
if "`PC'"=="EGUIO"{
	global id = "C:\Users\emiliogu\Dropbox\internet_replication\newpackage\replies-to-replicators\08-T4C4"
} 
if "`PC'"=="JAC"{
	global id= "C:\Users\jacci\Dropbox (Personal)\internet_replication\newpackage\replies-to-replicators\08-T4C4"
}

cd "${id}"
global pathdo 	   = "${id}\scripts"
global pathtemp    = "${id}\processed"
global pathout 	   = "${id}\results"
global pathfig	   = "${id}\results\Figures"
global pathtab     = "${id}\results\Tables"
global pathdataraw = "${id}\raw_data"
global pathdata    = "${id}\final"

* Folders creation
cap mkdir "${pathdo}"
cap mkdir "${pathtemp}"
cap mkdir "${pathout}"
cap mkdir "${pathfig}"
cap mkdir "${pathtab}"
cap mkdir "${pathdata}"
cap mkdir "${pathdataraw}"


********************************************************************************
* # 1.- Tables and Figures
********************************************************************************

*# T3 vs. T4C4 Afro estimates under the different versions
do "${pathdo}\afrot4_orig.do"
*Produces afrot4_orig.tex

