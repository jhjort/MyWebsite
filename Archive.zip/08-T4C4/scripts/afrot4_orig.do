

********************************************************************
** # 1.- Replicate paper results
********************************************************************
use "${pathdataraw}\original\afro_res_final.dta", clear

* nonlinear trends
tab year, gen(dtime)
forvalues i = 1/4 {
gen difftrends`i' = dtime`i' * connected
}

* country x time FE's
drop country_year
egen country_year = group(country year)

* grid-cell x connected FE's
drop grid_connect
egen grid_connect = group(grid10 connected)


*Reg of t3
reghdfe employed treatment if employment != -9 & age < 65 & distance < 0.1, a(grid_connect country_year) cluster(grid10)
estadd ysumm, mean
eststo t3aer

*Reg of t4c4
reghdfe employed treatment difftrends* if employment != -9 & age < 65 & distance < 0.1, a(grid_connect country_year) cluster(grid10)
estadd ysumm, mean
eststo t4aer

********************************************************************
** # 2.- Using Aid Geocoding 
********************************************************************
use "${pathdataraw}\aid\afro_aid.dta", clear

*Keep only the 9 countries
keep if inlist(year,2008,2011,2012,2013)
keep if inlist(country,"BJ","GH","KE","MG","MZ","NG","SN","TZ","ZA")

*Selecting grids as in the paper
ren grid10 grid
merge m:1 grid year using "${pathdataraw}\afropanel10.dta"
keep if _merge==3
drop _merge
ren grid grid10

* nonlinear trends
tab year, gen(dtime)
forvalues i = 1/4 {
gen difftrends`i' = dtime`i' * connected
}

* country x time FE's
drop country_year
egen country_year = group(country year)

* grid-cell x connected FE's
drop grid_connect
egen grid_connect = group(grid10 connected)

*T3 regression
reghdfe employed treatment if employment != -9 & age < 65 & distance < 0.1, a(grid_connect country_year) cluster(grid10)
estadd ysumm, mean
eststo t3aid

*T4C4 regression
reghdfe employed treatment difftrends* if employment != -9 & age < 65 & distance < 0.1, a(grid_connect country_year) cluster(grid10)
estadd ysumm, mean
eststo t4aid


********************************************************************
** # 3.- Using DR data (his data and Aid geocoding)
********************************************************************

*Open DR Afro dataset
use "${pathdataraw}\DR\Afrobarometer.dta", replace

*Code used by Roodman to perform the T3 regressions
gen long gridid   = round(latitude  , .1) * 10 * 1e3 + round(longitude  , .1) * 10 + 1e6
gen long grididHP = round(latitudeHP, .1) * 10 * 1e3 + round(longitudeHP, .1) * 10 + 1e6
recode distanceNetHP (-1 = .)
gen byte connectedNet = distanceNet   < .005
gen byte connectedNetHP = distanceNetHP < .005
gen byte connectedNode = distanceNode < .1
gen int year = cond(date==., yearHP, year(date))
gen sampleHP = distanceNetHP<.1
gen sample = distanceNet<.1
replace country = substr(respno, 1, 3)
egen countryid = group(country)
cap label drop countryid
label define countryid 1 "Benin" 2 "Ghana" 3 "Kenya" 4 "Madagascar" 5 "Mozambique" 6 "Nigeria" 7 "South Africa" 8 "Senegal" 9 "Tanzania", replace
label values countryid countryid
egen geogid = group(country region district townvill)

* table 3
gen grid = string(10*round(latitudeHP/.1)) + "_" + string(10*round(longitudeHP/.1))
*merge m:1 grid year using "D:\OneDrive\Documents\Work\Clients & prospects\GiveWell\Connectivity\Hjort & Poulsen\data 2022-06-17\data\afro\afropanel10.dta"
*Selecting grids as in the paper
merge m:1 grid year using "${pathdataraw}\afropanel10.dta"
keep if _merge==3
drop _merge

*egen grid_connectHP = group(grididHP connectedNetHP)
gen treatment_hp = submarines*connectedNetHP
egen country_year = group(countryid year)

*Using Roodman's new computation of distance to the whole fiber optic network
*Clustering by grid as we do in the paper

egen grid_connectdr = group(gridid connectedNet)
gen treatment_dr = submarines * connectedNet

***********************
*Table 3
***********************
cap drop treatment
gen treatment = treatment_dr
reghdfe employed treatment if age<65 & distanceNet<.1, a(grid_connectdr country_year) cluster(gridid)
estadd ysumm, mean
eststo t3df

***********************
*Table 4
***********************

*Generate connected-year FEs
*drop dtime*
tab year, gen(dtime)
forvalues i = 1/4 {
gen difftrends`i' = dtime`i' * connectedNet
}

reghdfe employed treatment difftrends* if age<65 & distanceNet<.1, a(grid_connectdr country_year) cluster(gridid)
estadd ysumm, mean
eststo t4df


//Export tables
esttab t3aer t4aer t3aid t4aid t3df t4df using "${pathtab}\afrot4_orig.tex", replace se b(3) stats(N ymean, fmt(0  %9.2f 0)  labels("Observations" "Mean of Outcome")) label alignment(center) nogaps fragment nonumbers mlabels(none) drop(difftrends* _cons) collabels()  nocon starlevels(* 0.10 ** 0.05 *** 0.01) nolines



