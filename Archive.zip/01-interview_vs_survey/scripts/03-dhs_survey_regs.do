*cd "C:\Users\jacci\Dropbox\internet_replication"
clear all
set more off

* Effect on employment
* DHS
* original code: we use the interview year for the merge between dhs and the distance+> we loose some observations
* now : we survey year for the merge (we keep extra observation)
* we know that the distance database use the survey year and NOT the interview year

***** Full sample *****
use "${pathdata}\dhs_women_final.dta", clear
append using "${pathdata}\dhs_men_final.dta"

// filter by grid points: Keep only twice
preserve,
gen count = 1
collapse count, by(grid year)
duplicates tag grid, gen(dups)
keep if dups == 1
keep grid year
tempfile to_keep
save `to_keep', replace
restore
merge m:1 grid year using `to_keep'
keep if _merge == 3
drop _merge

* treatment
replace submarines = 1 if submarines > 0
gen connected = 1 if distance <= 0.005
replace connected = 0 if connected == .
gen treatment = connected * submarines

* aggregated categories
gen veryskilled = 1 if skill4 == 1 | skill2 == 1
replace veryskilled = 0 if skill4 == 0 & skill2 == 0

gen notskilled = 1 if skill1 == 1
replace notskilled = 0 if skill1 == 0

* interactions
gen intnoedu = treatment * noeducation
gen intprimary = treatment * primary
gen intsecondary = treatment * secondary
gen inthigh = treatment * higher
save "${pathdata}\dhs_res_final", replace

///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
* Original regression
use "${pathdataraw}\aer_final\dhs_res_final.dta", clear
glo	gridsize10 = 0.1
g 	latitude_grid10 = 100*${gridsize10}*round(latitude/${gridsize10})
g 	longitude_grid10 = 100*${gridsize10}*round(longitude/${gridsize10})
tostring latitude_grid10 longitude_grid10, replace force
g 	grid10 = latitude_grid10 + "_" + longitude_grid10
replace submarines = 1 if submarines > 0
drop grid_connect
drop country_year
egen grid_connect = group(grid10 connected)
egen country_year = group(country year)
areg employed treatment i.country_year if distance < 0.1, a(grid_connect) cluster(grid10)
estadd ysumm, mean
eststo reg_og


// T3 regression
use "${pathdata}\dhs_res_final", clear
* grid size
glo	gridsize10 = 0.1 // side of each square in degrees
* generate grid cell variable
g 	latitude_grid10 = 100*${gridsize10}*round(latitude/${gridsize10})
g 	longitude_grid10 = 100*${gridsize10}*round(longitude/${gridsize10})
tostring latitude_grid10 longitude_grid10, replace force
g 	grid10 = latitude_grid10 + "_" + longitude_grid10

* country x time FE's
egen country_year = group(country year)

* grid-cell x connected FE's
egen grid_connect = group(grid10 connected)

* regression
areg employed treatment i.country_year if distance < 0.1, a(grid_connect) cluster(grid10)
estadd ysumm, mean
eststo reg_year

* Export results
esttab reg_og reg_year, replace se b(3) stats(N ymean, fmt(0  %9.2f)  labels("Observations" "Mean of Outcome")) label alignment(center) nogaps fragment nonumbers mlabels(none) drop(*year* _cons) collabels() nocon starlevels(* 0.10 ** 0.05 *** 0.01) nolines rename(treatment "Treatment")

esttab reg_og reg_year using "${pathtab}\t3_dhs_syear.tex", replace se b(3) stats(N ymean, fmt(0  %9.2f)  labels("Observations" "Mean of Outcome")) label alignment(center) nogaps fragment nonumbers mlabels(none) drop(*year* _cons) collabels() nocon starlevels(* 0.10 ** 0.05 *** 0.01) nolines rename(treatment "Treatment")

di 61822-59914
*1908 added observations