
clear all
set more off

***		Congo 2007

use "${pathdataraw}\women\drcongo\dhs2007.dta"

* Keep variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v106 v130 v131 v155 v190 v191 v714 v119 v120 v121 v201 v157 v133 v717 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605 v741

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2007

save "${pathtemp}\congomerged2007_wm.dta", replace

********************************************************************************

clear all
set more off

***		Congo 2013
use "${pathdataraw}\women\drcongo\dhs20132014.dta"

* Keep variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v130 v131 v155 v190 v191 v714 v119 v120 v121 v201 v157 v133 v717 v106 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605 v741

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2013


save "${pathtemp}\congomerged20132014_wm.dta", replace


********************************************************************************

clear all
set more off

***		Nigeria 2008
use "${pathdataraw}\women\nigeria\dhs2008.dta"

* Keep variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v130 v131 v155 v190 v191 v714 v119 v120 v121 v201 v157 v133 v717 v106 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605 v741

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2008

save "${pathtemp}\nigeriamerged2008_wm.dta", replace

********************************************************************************

clear all
set more off

***		Nigeria 2013
use "${pathdataraw}\women\nigeria\dhs2013.dta"

* Keep variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v130 v131 v155 v190 v191 v714 v119 v120 v121 v201 v157 v133 v717 v106 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605 v741

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2013

save "${pathtemp}\nigeriamerged2013_wm.dta", replace




********************************************************************************

clear all
set more off

***		Tanzania 1999
use "${pathdataraw}\women\tanzania\dhs1999.dta"

* Keep variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v130 v131 v714 v119 v120 v121 v201 v133 v717 v106 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 1999

save "${pathtemp}\tanzaniamerged1999_wm.dta", replace

********************************************************************************

clear all
set more off

***		Tanzania 2010
use "${pathdataraw}\women\tanzania\dhs2010.dta"

* Keep variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v130 v131 v155 v190 v191 v714 v119 v120 v121 v201 v157 v133 v717 v106 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605 v741

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2010

save "${pathtemp}\tanzaniamerged2010_wm.dta", replace

********************************************************************************

clear all
set more off

***		Benin 2001
use "${pathdataraw}\women\benin\dhs2001.dta"


* Keep variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v130 v131 v714 v119 v120 v121 v201 v133 v717 v106 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605 v741

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2001

save "${pathtemp}\beninmerged2001_wm.dta", replace

clear all

********************************************************************************

clear all
set more off

***		Benin 2011/2012
use "${pathdataraw}\women\benin\dhs20112012.dta"


* Keep relevant variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v130 v131 v714 v119 v120 v121 v201 v133 v717 v106 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605 v741

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2012

save "${pathtemp}\beninmerged20112012_wm.dta", replace

********************************************************************************

clear all
set more off

***		Togo 1998
use "${pathdataraw}\women\togo\dhs1998.dta"


* Keep variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v130 v131 v714 v119 v120 v121 v201 v133 v717 v106 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 1998

save "${pathtemp}\togomerged1998_wm.dta", replace

********************************************************************************

clear all
set more off

***		Togo 2013/2014
use "${pathdataraw}\women\togo\dhs20132014.dta"


* Keep variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v130 v131 v714 v119 v120 v121 v201 v133 v717 v106 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605 v741

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2013

save "${pathtemp}\togomerged20132014_wm.dta", replace

********************************************************************************

clear all
set more off

***		Ghana 2008
use "${pathdataraw}\women\ghana\dhs2008.dta"


* Keep variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v130 v131 v714 v119 v120 v121 v201 v133 v717 v106 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2008

save "${pathtemp}\ghanamerged2008_wm.dta", replace

clear all


********************************************************************************

clear all
set more off

***		Ghana 2014
use "${pathdataraw}\women\ghana\dhs2014.dta"


* Keep variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v130 v131 v714 v119 v120 v121 v201 v133 v717 v106 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605 v741

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2014

save "${pathtemp}\ghanamerged2014_wm.dta", replace

********************************************************************************

clear all
set more off

***		Kenya 2008/2009
use "${pathdataraw}\women\kenya\dhs20082009.dta"


* Keep variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v130 v131 v714 v119 v120 v121 v201 v133 v717 v106 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2008

save "${pathtemp}\kenyamerged20082009_wm.dta", replace

********************************************************************************

clear all
set more off

***		Kenya 2014
use "${pathdataraw}\women\kenya\dhs2014.dta"


* Keep variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v130 v131 v714 v119 v120 v121 v201 v133 v717 v106 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605 v741

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2014

save "${pathtemp}\kenyamerged2014_wm.dta", replace

********************************************************************************

clear all
set more off

***		Namibia 2006/2007
use "${pathdataraw}\women\namibia\dhs20062007.dta"


* Keep variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v130 v131 v714 v119 v120 v121 v201 v133 v717 v106 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2006

save "${pathtemp}\namibiamerged20062007_wm.dta", replace

clear all


********************************************************************************

clear all
set more off

***		Namibia 2013
use "${pathdataraw}\women\namibia\dhs2013.dta"


* Keep relevant variables
keep v000 v001 v002 v003 v004 v006 v008 v009 v010 v011 v012 v130 v131 v714 v119 v120 v121 v201 v133 v717 v106 v104 v025 v113 v116 v119 v122 v125 v129 v437 v445 v605 v741

gen year = int((v008-1)/12)
gen month = v008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2013

save "${pathtemp}\namibiamerged2013_wm.dta", replace

clear all
set more off




****************************************************
****************************************************
***** Append all the created datasets together *****
****************************************************
****************************************************

use "${pathtemp}\congomerged2007_wm.dta", clear
append using "${pathtemp}\congomerged20132014_wm.dta"
gen country = "CD"
append using "${pathtemp}\nigeriamerged2008_wm.dta"
append using "${pathtemp}\nigeriamerged2013_wm.dta"
replace country = "NG" if country == ""
append using "${pathtemp}\tanzaniamerged1999_wm.dta"
append using "${pathtemp}\tanzaniamerged2010_wm.dta"
replace country = "TZ" if country == ""
append using "${pathtemp}\beninmerged2001_wm.dta"
append using "${pathtemp}\beninmerged20112012_wm.dta"
replace country = "BJ" if country == ""
append using "${pathtemp}\togomerged1998_wm.dta"
append using "${pathtemp}\togomerged20132014_wm.dta"
replace country = "TG" if country == ""
append using "${pathtemp}\ghanamerged2008_wm.dta"
append using "${pathtemp}\ghanamerged2014_wm.dta"
replace country = "GH" if country == ""
append using "${pathtemp}\kenyamerged20082009_wm.dta"
append using "${pathtemp}\kenyamerged2014_wm.dta"
replace country = "KE" if country == ""
append using "${pathtemp}\namibiamerged20062007_wm.dta"
append using "${pathtemp}\namibiamerged2013_wm.dta"
replace country = "NA" if country == ""


// Merge for Distances (using survey year)
preserve,
use "${pathdataraw}\dhs_distances.dta", clear
rename year survey_year
tempfile distances
save `distances'
restore
merge m:1 v001 country survey_year using `distances'
keep if _merge == 3
drop _merge


* Create grids as the panel variable

rename LATNUM latitude
rename LONGNUM longitude



save "${pathtemp}\dhsappended_wm.dta", replace



*** Generate additative submarine cable indicator ***
gen cable20093 = 1 if country == "DJ" & time >= 20093 | country == "KE" & time >= 20093 | country == "MZ" & time >= 20093 | country == "TZ" & time >= 20093 | country == "ZA" & time >= 20093
replace cable20093 = 0 if cable20093 == .

gen cable20093_2 = 1 if country == "KE" & time >= 20093
replace cable20093_2 = 0 if cable20093_2 == .

gen cable20094 = 1 if country == "MU" & time >= 20094
replace cable20094 = 0 if cable20094 == .

gen cable20103 = 1 if country == "DJ" & time >= 20103 | country == "KE" & time >= 20103 | country == "KM" & time >= 20103 | country == "MG" & time >= 20103 | country == "MZ" & time >= 20103 | country == "SD" & time >= 20103 | country == "SO" & time >= 20103 | country == "TZ" & time >= 20103
replace cable20103 = 0 if cable20103 == .

gen cable20103_2 = 1 if country == "BF" & time >= 20103 | country == "BJ" & time >= 20103 | country == "CI" & time >= 20103 | country == "GH" & time >= 20103 | country == "MA" & time >= 20103 | country == "NG" & time >= 20103 | country == "SN" & time >= 20103 | country == "TG" & time >= 20103
replace cable20103_2 = 0 if cable20103_2 == .

gen cable20112 = 1 if country == "GH" & time >= 20112 | country == "MA" & time >= 20112 | country == "MR" & time >= 20112 | country == "NG" & time >= 20112 | country == "SN" & time >= 20112
replace cable20112 = 0 if cable20112 == .

gen cable20122 = 1 if country == "KE" & time >= 20122
replace cable20122 = 0 if cable20122 == .

gen cable20122_2 = 1 if country == "KE" & time >= 20122 | country == "RW" & time >= 20122 | country == "UG" & time >= 20122 | country == "ZA" & time >= 20122 | country == "ZW" & time >= 20122
replace cable20122_2 = 0 if cable20122_2 == .

gen cable20122_3 = 1 if country == "AO" & time >= 20122 | country == "CD" & time >= 20122 | country == "CG" & time >= 20122 | country == "CI" & time >= 20122 | country == "CM" & time >= 20122 | country == "CV" & time >= 20122 | country == "GA" & time >= 20122 | country == "GH" & time >= 20122 | country == "NA" & time >= 20122 | country == "NG" & time >= 20122 | country == "TG" & time >= 20122
replace cable20122_3 = 0 if cable20122_3 == .

gen cable20124 = 1 if country == "AO" & time >= 20124 | country == "BJ" & time >= 20124 | country == "CD" & time >= 20124 | country == "CI" & time >= 20124 | country == "CM" & time >= 20124 | country == "GA" & time >= 20124 | country == "GH" & time >= 20124 | country == "GM" & time >= 20124 | country == "GN" & time >= 20124 | country == "GQ" & time >= 20124 | country == "LR" & time >= 20124 | country == "MR" & time >= 20124 | country == "MR" & time >= 20124 | country == "NA" & time >= 20124 | country == "NG" & time >= 20124 | country == "SL" & time >= 20124 | country == "SN" & time >= 20124 | country == "ST" & time >= 20124
replace cable20124 = 0 if cable20124 == .

* grid size
glo	gridsize = 0.1 // side of each square in degrees
* generate grid cell variable
g 	latitude_grid = 100*${gridsize}*round(latitude/${gridsize})
g 	longitude_grid = 100*${gridsize}*round(longitude/${gridsize})
tostring latitude_grid longitude_grid, replace force
g 	grid = latitude_grid + "_" + longitude_grid

sort country grid time
egen submarines = rowtotal(cable20093 cable20093_2 cable20094 cable20103 cable20103_2 cable20112 cable20122 cable20122_2 cable20122_3 cable20124)



/* Outcome variables */
rename v714 employed
drop if employed == 9


* Type of occupation:
gen professional = 1 if v717 == 1
replace professional = 0 if professional == . & employed != .
gen clerical = 1 if v717 == 2
replace clerical = 0 if clerical == . & employed != .
gen sales = 1 if v717 == 3
replace sales = 0 if sales == . & employed != .
gen agri_self_emp = 1 if v717 == 4
replace agri_self_emp = 0 if agri_self_emp == . & employed != .
gen agri_emp = 1 if v717 == 5
replace agri_emp = 0 if agri_emp == . & employed != .
gen domestic = 1 if v717 == 6
replace domestic = 0 if domestic == . & employed != .
gen services = 1 if v717 == 7
replace services = 0 if services == . & employed != .
gen manual_skilled = 1 if v717 == 8
replace manual_skilled = 0 if manual_skilled == . & employed != .
gen manual_unskilled = 1 if v717 == 9
replace manual_unskilled = 0 if manual_unskilled == . & employed != .

gen missing = 1 if v717 == 10 | v717 == 96 | v717 == 97 | v717 == 98 | v717 == 99
replace missing = 0 if missing == .

gen informal = 1 if missing == 0 & v717 != 0 & employed == 0
replace informal = 0 if informal == . & missing == 0


gen occu = 1 if professional == 1 | clerical == 1 | sales == 1 | agri_self_emp == 1 | agri_emp == 1 | domestic == 1 | services == 1 | manual_skilled == 1 | manual_unskilled == 1
replace occu = 0 if occu == .


* Compiled 2
gen skilled = 1 if professional == 1 | sales == 1 | services == 1 | manual_skilled == 1
replace skilled = 0 if skilled == .

gen unskilled = 1 if clerical == 1 | agri_self_emp == 1 | agri_emp == 1 | domestic == 1 | manual_unskilled == 1
replace unskilled = 0 if unskilled == .

gen skilled_isco = 1 if professional == 1 | manual_skilled == 1
replace skilled_isco = 0 if skilled_isco == .

gen unskilled_isco = 1 if clerical == 1 | agri_self_emp == 1 | agri_emp == 1 | domestic == 1 | manual_unskilled == 1 | sales == 1 | services == 1
replace unskilled_isco = 0 if unskilled_isco == .


gen skill4 = 1 if professional == 1
replace skill4 = 0 if skill4 == . & employed != .


gen skill2 = 1 if clerical == 1 | manual_skilled == 1 | sales == 1 | services == 1 | agri_emp == 1
replace skill2 = 0 if skill2 == . & employed != .

gen skill1 = 1 if manual_unskilled == 1 | domestic == 1 | agri_self_emp == 1
replace skill1 = 0 if skill1 == . & employed != .



* Education
drop if v106 == 9
gen noeducation = 1 if v106 == 0
replace noeducation = 0 if noeducation == .
gen primary = 1 if v106 == 1
replace primary = 0 if primary == .
gen secondary = 1 if v106 == 2
replace secondary = 0 if secondary == .
gen higher = 1 if v106 == 3
replace higher = 0 if higher == .

keep skill4 skill2 skill1 v001 employed year time country latitude longitude distance* grid submarines professional clerical sales agri_self_emp agri_emp domestic services manual_skilled manual_unskilled missing noeducation primary secondary higher DHSID survey_year



save "${pathdata}\dhs_women_final.dta", replace
