*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
version 17.0
*version 18.0
clear all
macro drop _all 
cap log close

********************************************************************************
** # 0. Setting 
********************************************************************************

local PC = "EG"

if "`PC'"=="EG"{
	global id = "C:\Users\ASUS\Dropbox\internet_replication\newpackage\replies-to-replicators\01-interview_vs_survey"
} 
if "`PC'"=="EGUIO"{
	global id = "C:\Users\emiliogu\Dropbox\internet_replication\newpackage\replies-to-replicators\01-interview_vs_survey"
} 

cd "${id}"
global pathdo 	   = "${id}\scripts"
global pathtemp    = "${id}\processed"
global pathout 	   = "${id}\results"
global pathfig	   = "${id}\results\Figures"
global pathtab     = "${id}\results\Tables"
global pathdataraw = "${id}\raw_data"
global pathdata    = "${id}\final"

* Folders creation
cap mkdir "${pathdo}"
cap mkdir "${pathtemp}"
cap mkdir "${pathout}"
cap mkdir "${pathfig}"
cap mkdir "${pathtab}"
cap mkdir "${pathdata}"
cap mkdir "${pathdataraw}"


********************************************************************************
* # 1.- Tables and Figures
********************************************************************************
* # DHS men
do "${pathdo}\01-dhs_men_surveyyear_only.do"

* # DHS women
do "${pathdo}\02-dhs_women_surveyyear_only.do"

*# Table
do "${pathdo}\03-dhs_survey_regs.do"


