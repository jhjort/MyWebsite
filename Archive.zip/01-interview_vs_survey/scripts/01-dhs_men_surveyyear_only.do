clear all
set more off


***		Congo 2007

use "${pathdataraw}\men\drcongo2007.dta"


* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv106 mv130 mv131 mv155 mv190 mv191 mv714    mv201 mv157 mv133 mv717 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2007

save "${pathtemp}\congomerged2007.dta", replace

********************************************************************************

clear all
set more off

***		Congo 2013
use "${pathdataraw}\men\drcongo2013.dta"

* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv130 mv131 mv155 mv190 mv191 mv714    mv201 mv157 mv133 mv717 mv106 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2013


save "${pathtemp}\congomerged20132014.dta", replace


********************************************************************************

clear all
set more off

***		Ghana 2008

use "${pathdataraw}\men\ghana2008.dta"


* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv106 mv130 mv131 mv155 mv190 mv191 mv714    mv201 mv157 mv133 mv717 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2008

save "${pathtemp}\ghanamerged2008.dta", replace



********************************************************************************

clear all
set more off

***		Ghana 2015
use "${pathdataraw}\men\ghana2014.dta"

* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv130 mv131 mv155 mv190 mv191 mv714    mv201 mv157 mv133 mv717 mv106 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2014

save "${pathtemp}\ghanamerged2014.dta", replace


********************************************************************************

clear all
set more off

***		Kenya 2008

use "${pathdataraw}\men\kenya2008.dta"


* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv106 mv130 mv131 mv155 mv190 mv191 mv714 mv201 mv157 mv133 mv717 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2008

save "${pathtemp}\kenyamerged2008.dta", replace



********************************************************************************

clear all
set more off

***		Kenya 2014
use "${pathdataraw}\men\kenya2014.dta"

* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv130 mv131 mv155 mv190 mv191 mv714    mv201 mv157 mv133 mv717 mv106 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2014

save "${pathtemp}\kenyamerged2014.dta", replace



********************************************************************************

clear all
set more off

***		Namibia 2006

use "${pathdataraw}\men\namibia2006.dta"


* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv106 mv130 mv131 mv155 mv190 mv191 mv714    mv201 mv157 mv133 mv717 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2006

save "${pathtemp}\namibiamerged2006.dta", replace



********************************************************************************

clear all
set more off

***		Namibia 2013
use "${pathdataraw}\men\namibia2013.dta"

* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv130 mv131 mv155 mv190 mv191 mv714    mv201 mv157 mv133 mv717 mv106 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2013


save "${pathtemp}\namibiamerged2013.dta", replace


********************************************************************************

clear all
set more off

***		Nigeria 2008
use "${pathdataraw}\men\nigeria2008.dta"

* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv130 mv131 mv155 mv190 mv191 mv714    mv201 mv157 mv133 mv717 mv106 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2008

save "${pathtemp}\nigeriamerged2008.dta", replace


********************************************************************************

clear all
set more off

***		Nigeria 2013
use "${pathdataraw}\men\nigeria2013.dta"


* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv130 mv131 mv155 mv190 mv191 mv714    mv201 mv157 mv133 mv717 mv106 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2013

save "${pathtemp}\nigeriamerged2013.dta", replace



********************************************************************************

clear all
set more off

***		Benin 2001
use "${pathdataraw}\men\benin2001.dta"


* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv130 mv131 mv714    mv201 mv133 mv717 mv106 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2001

save "${pathtemp}\beninmerged2001.dta", replace

clear all

********************************************************************************

clear all
set more off

***		Benin 2011/2012
use "${pathdataraw}\men\benin2012.dta"


* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv130 mv131 mv714    mv201 mv133 mv717 mv106 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2012

save "${pathtemp}\beninmerged20112012.dta", replace

********************************************************************************

clear all
set more off

***		Tanzania 1999

use "${pathdataraw}\men\tanzania1999.dta"


* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv106 mv130 mv131 mv714    mv201 mv133 mv717 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 1999

save "${pathtemp}\tanzaniamerged1999.dta", replace

********************************************************************************

clear all
set more off

***		Tanzania 2010
use "${pathdataraw}\men\tanzania2010.dta"

* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv130 mv131 mv155 mv190 mv191 mv714    mv201 mv157 mv133 mv717 mv106 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2010

save "${pathtemp}\tanzaniamerged2010.dta", replace

********************************************************************************

clear all
set more off

***		Togo 1998
use "${pathdataraw}\men\togo1998.dta"


* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv130 mv131 mv714    mv201 mv133 mv717 mv106 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 1998

save "${pathtemp}\togomerged1998.dta", replace

clear all


********************************************************************************

clear all
set more off

***		Togo 2013/2014
use "${pathdataraw}\men\togo2013.dta"


* Keep variables
keep mv000 mv001 mv002 mv003 mv004 mv006 mv008 mv009 mv010 mv011 mv012 mv130 mv131 mv714    mv201 mv133 mv717 mv106 mv104 mv025

gen year = int((mv008-1)/12)
gen month = mv008 - (year*12)
replace year = year + 1900
gen quarter = 1 if month == 1 | month == 2 | month == 3
replace quarter = 2 if month == 4 | month == 5 | month == 6
replace quarter = 3 if month == 7 | month == 8 | month == 9
replace quarter = 4 if month == 10 | month == 11 | month == 12
tostring year quarter, replace
gen time = year + quarter
destring time, replace
destring year, replace
drop quarter

gen survey_year = 2013

save "${pathtemp}\togomerged20132014.dta", replace

clear all

****************************************************
****************************************************
***** Append all the created datasets together *****
****************************************************
****************************************************

use "${pathtemp}\congomerged2007.dta", clear
append using "${pathtemp}\congomerged20132014.dta"
gen country = "CD"
append using "${pathtemp}\nigeriamerged2008.dta"
append using "${pathtemp}\nigeriamerged2013.dta"
replace country = "NG" if country == ""
append using "${pathtemp}\beninmerged2001.dta"
append using "${pathtemp}\beninmerged20112012.dta"
replace country = "BJ" if country == ""
append using "${pathtemp}\togomerged1998.dta"
append using "${pathtemp}\togomerged20132014.dta"
replace country = "TG" if country == ""
append using "${pathtemp}\ghanamerged2008.dta"
append using "${pathtemp}\ghanamerged2014.dta"
replace country = "GH" if country == ""
append using "${pathtemp}\kenyamerged2008.dta"
append using "${pathtemp}\kenyamerged2014.dta"
replace country = "KE" if country == ""
append using "${pathtemp}\namibiamerged2006.dta"
append using "${pathtemp}\namibiamerged2013.dta"
replace country = "NA" if country == ""
append using "${pathtemp}\tanzaniamerged1999.dta"
append using "${pathtemp}\tanzaniamerged2010.dta"
replace country = "TZ" if country == ""

rename mv001 v001

// Merge for Distances (using survey year)
preserve,
use "${pathdataraw}\dhs_distances.dta", clear
rename year survey_year
tempfile distances
save `distances'
restore
merge m:1 v001 country survey_year using `distances'
keep if _merge == 3
drop _merge

* Create grids as the panel variable

rename LATNUM latitude
rename LONGNUM longitude


*** Generate additative submarine cable indicator ***
gen cable20093 = 1 if country == "DJ" & time >= 20093 | country == "KE" & time >= 20093 | country == "MZ" & time >= 20093 | country == "TZ" & time >= 20093 | country == "ZA" & time >= 20093
replace cable20093 = 0 if cable20093 == .

gen cable20093_2 = 1 if country == "KE" & time >= 20093
replace cable20093_2 = 0 if cable20093_2 == .

gen cable20094 = 1 if country == "MU" & time >= 20094
replace cable20094 = 0 if cable20094 == .

gen cable20103 = 1 if country == "DJ" & time >= 20103 | country == "KE" & time >= 20103 | country == "KM" & time >= 20103 | country == "MG" & time >= 20103 | country == "MZ" & time >= 20103 | country == "SD" & time >= 20103 | country == "SO" & time >= 20103 | country == "TZ" & time >= 20103
replace cable20103 = 0 if cable20103 == .

gen cable20103_2 = 1 if country == "BF" & time >= 20103 | country == "BJ" & time >= 20103 | country == "CI" & time >= 20103 | country == "GH" & time >= 20103 | country == "MA" & time >= 20103 | country == "NG" & time >= 20103 | country == "SN" & time >= 20103 | country == "TG" & time >= 20103
replace cable20103_2 = 0 if cable20103_2 == .

gen cable20112 = 1 if country == "GH" & time >= 20112 | country == "MA" & time >= 20112 | country == "MR" & time >= 20112 | country == "NG" & time >= 20112 | country == "SN" & time >= 20112
replace cable20112 = 0 if cable20112 == .

gen cable20122 = 1 if country == "KE" & time >= 20122
replace cable20122 = 0 if cable20122 == .

gen cable20122_2 = 1 if country == "KE" & time >= 20122 | country == "RW" & time >= 20122 | country == "UG" & time >= 20122 | country == "ZA" & time >= 20122 | country == "ZW" & time >= 20122
replace cable20122_2 = 0 if cable20122_2 == .

gen cable20122_3 = 1 if country == "AO" & time >= 20122 | country == "CD" & time >= 20122 | country == "CG" & time >= 20122 | country == "CI" & time >= 20122 | country == "CM" & time >= 20122 | country == "CV" & time >= 20122 | country == "GA" & time >= 20122 | country == "GH" & time >= 20122 | country == "NA" & time >= 20122 | country == "NG" & time >= 20122 | country == "TG" & time >= 20122
replace cable20122_3 = 0 if cable20122_3 == .

gen cable20124 = 1 if country == "AO" & time >= 20124 | country == "BJ" & time >= 20124 | country == "CD" & time >= 20124 | country == "CI" & time >= 20124 | country == "CM" & time >= 20124 | country == "GA" & time >= 20124 | country == "GH" & time >= 20124 | country == "GM" & time >= 20124 | country == "GN" & time >= 20124 | country == "GQ" & time >= 20124 | country == "LR" & time >= 20124 | country == "MR" & time >= 20124 | country == "MR" & time >= 20124 | country == "NA" & time >= 20124 | country == "NG" & time >= 20124 | country == "SL" & time >= 20124 | country == "SN" & time >= 20124 | country == "ST" & time >= 20124
replace cable20124 = 0 if cable20124 == .

* grid size
glo	gridsize = 0.1 // side of each square in degrees
* generate grid cell variable
g 	latitude_grid = 100*${gridsize}*round(latitude/${gridsize})
g 	longitude_grid = 100*${gridsize}*round(longitude/${gridsize})
tostring latitude_grid longitude_grid, replace force
g 	grid = latitude_grid + "_" + longitude_grid

sort country grid time
egen submarines = rowtotal(cable20093 cable20093_2 cable20094 cable20103 cable20103_2 cable20112 cable20122 cable20122_2 cable20122_3 cable20124)



/* Outcome variables */
rename mv714 employed
drop if employed == 9


* Type of occupation:
gen professional = 1 if mv717 == 1
replace professional = 0 if professional == .
gen clerical = 1 if mv717 == 2
replace clerical = 0 if clerical == .
gen sales = 1 if mv717 == 3
replace sales = 0 if sales == .
gen agri_self_emp = 1 if mv717 == 4
replace agri_self_emp = 0 if agri_self_emp == .
gen agri_emp = 1 if mv717 == 5
replace agri_emp = 0 if agri_emp == .
gen domestic = 1 if mv717 == 6
replace domestic = 0 if domestic == .
gen services = 1 if mv717 == 7
replace services = 0 if services == .
gen manual_skilled = 1 if mv717 == 8
replace manual_skilled = 0 if manual_skilled == .
gen manual_unskilled = 1 if mv717 == 9
replace manual_unskilled = 0 if manual_unskilled == .
gen missing = 1 if mv717 == 10 | mv717 == 96 | mv717 == 97 | mv717 == 98 | mv717 == 99
replace missing = 0 if missing == .


gen skill4 = 1 if professional == 1
replace skill4 = 0 if skill4 == . & employed != .


gen skill2 = 1 if clerical == 1 | manual_skilled == 1 | sales == 1 | services == 1 | agri_emp == 1
replace skill2 = 0 if skill2 == . & employed != .

gen skill1 = 1 if manual_unskilled == 1 | domestic == 1 | agri_self_emp == 1
replace skill1 = 0 if skill1 == . & employed != .

* Education
drop if mv106 == 9
gen noeducation = 1 if mv106 == 0
replace noeducation = 0 if noeducation == .
gen primary = 1 if mv106 == 1
replace primary = 0 if primary == .
gen secondary = 1 if mv106 == 2
replace secondary = 0 if secondary == .
gen higher = 1 if mv106 == 3
replace higher = 0 if higher == .



keep skill4 skill2 skill1 v001 employed year time country latitude longitude distance* grid submarines professional clerical sales agri_self_emp agri_emp domestic services manual_skilled manual_unskilled missing noeducation primary secondary higher DHSID survey_year

gen male = 1

save "${pathdata}\dhs_men_final.dta", replace

