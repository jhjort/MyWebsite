*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
version 17.0
*version 18.0
clear all
macro drop _all 
cap log close

********************************************************************************
** # 0. Setting 
********************************************************************************

local PC = "EGUIO"

if "`PC'"=="EG"{
	global id = "C:\Users\ASUS\Dropbox\internet_replication\newpackage\replies-to-replicators\02-nearest_point_country"
} 
if "`PC'"=="EGUIO"{
	global id = "C:\Users\emiliogu\Dropbox\internet_replication\newpackage\replies-to-replicators\02-nearest_point_country"
} 

cd "${id}"
global pathdo 	   = "${id}\scripts"
global pathtemp    = "${id}\processed"
global pathout 	   = "${id}\results"
global pathfig	   = "${id}\results\Figures"
global pathtab     = "${id}\results\Tables"
global pathdataraw = "${id}\raw_data"
global pathdata    = "${id}\final"

* Folders creation
cap mkdir "${pathdo}"
cap mkdir "${pathtemp}"
cap mkdir "${pathout}"
cap mkdir "${pathfig}"
cap mkdir "${pathtab}"
cap mkdir "${pathdata}"
cap mkdir "${pathdataraw}"


********************************************************************************
* # 1.- Tables and Figures
********************************************************************************
*NOTE: The directory "C:\Program Files\R\R-4.3.2\bin\x64\R.exe" should be modified according to the location of R in the replicator's computer

* # Compute within border and within owner distances
shell "C:\Program Files\R\R-4.3.2\bin\x64\R.exe" CMD BATCH "${pathdo}\01-compute_distance_owner_national.R"
/*
produces
afrobarometer_national.dta
dhs_national.dta
qlfs_national.dta
*/

* # Produce treatment tables
shell "C:\Program Files\R\R-4.3.2\bin\x64\R.exe" CMD BATCH "${pathdo}\02-treatment_tables.R"
/*
produces
treatment_owner_t3.tex
treatment_border_t3.tex
*/

* # Compute Table 3
do "${pathdo}\03-T3_within_country.do"

/*
produces
t3_national.tex
*/