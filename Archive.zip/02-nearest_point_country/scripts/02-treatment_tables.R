# Assess T/C/D status
# For both the full dataset and the T3 sample

# Clean env. and set directory
rm(list=ls())
setwd("C:/Users/emiliogu/Dropbox") # DropBox folder
# setwd("C:/Users/giaco/DropBox (UCL)") # DropBox folder

# Load required packages
library(haven)
library(dplyr)

# Load data
afro <- read_dta("internet_replication/newpackage/replies-to-replicators/02-nearest_point_country/final/afrobarometer_national.dta")
dhs <- read_dta("internet_replication/newpackage/replies-to-replicators/02-nearest_point_country/final/dhs_national.dta")
qlfs <- read_dta("internet_replication/newpackage/replies-to-replicators/02-nearest_point_country/final/qlfs_national.dta")

# Assess treatment/constrol/drop status across different datasets
treatmentColumns <- function(data) {
  # Initialize the three columns with NA values
  data$og_treatment <- NA
  data$owner_treatment <- NA
  data$national_treatment <- NA
  
  # Assign values based on the specified conditions
  data$og_treatment[data$distance <= 0.005] <- "Treatment"
  data$og_treatment[data$distance > 0.005 & data$distance <= 0.1] <- "Control"
  data$og_treatment[data$distance > 0.1] <- "Drop"
  
  data$owner_treatment[data$distance_owner <= 0.005] <- "Treatment"
  data$owner_treatment[data$distance_owner > 0.005 & data$distance_owner <= 0.1] <- "Control"
  data$owner_treatment[data$distance_owner > 0.1] <- "Drop"
  data$owner_treatment[is.na(data$distance_owner)] <- "Drop" # for Benin
  
  data$national_treatment[data$distance_national <= 0.005] <- "Treatment"
  data$national_treatment[data$distance_national > 0.005 & data$distance_national <= 0.1] <- "Control"
  data$national_treatment[data$distance_national > 0.1] <- "Drop"
  
  # Return the updated dataframe
  return(data)
}
afro <- treatmentColumns(afro)
dhs <- treatmentColumns(dhs)
qlfs <- treatmentColumns(qlfs)

# Table treatment assignments
table_treatment <- function(data) {
  table1 <- as.data.frame.matrix(table(factor(data$og_treatment, levels = c("Treatment", "Control", "Drop")),
                                      factor(data$owner_treatment, levels = c("Treatment", "Control", "Drop"))))
  table2 <- as.data.frame.matrix(table(factor(data$og_treatment, levels = c("Treatment", "Control", "Drop")),
                                       factor(data$national_treatment, levels = c("Treatment", "Control", "Drop"))))
  
  table3 <- cbind(table1, table2)
  colnames(table3) <- c("Owner T.", "Owner C.", "Owner D.", "National T.", "National C.", "National D.")
  table3 <- mutate_all(table3, function(x) format(x, big.mark = ",")) # usa commas for thousands
  
  return(table3)
}
table <- rbind(table_treatment(afro), table_treatment(dhs), table_treatment(qlfs))

# Convert the output to a .TeX file
to_latex <- function(data, owner, t3) {
  
  # Choose the columns based on the 'owner' parameter
  if(owner) {
    data <- data[,c(1:3)] # 'owner' columns
    within_txt <- "Within Owner"
  } else {
    data <- data[,c(4:6)] # 'national' columns
    within_txt <- "Within Border"
  }
  
  # Function to format data frame row as a LaTeX table row
  format_row <- function(row_data, row_name){
    row_string <- paste(row_data, collapse = " & ")
    return(paste(row_name, " & ", row_string, " \\\\"))
  }
  
  # Define row names
  row_names <- c("Treatment", "Control", "Drop",
                 "Treatment", "Control","Drop",
                 "Treatment", "Control", "Drop")
  
  # Format each row
  row_strings <- mapply(format_row, as.data.frame(t(data)), row_names, USE.NAMES = FALSE)
  
  # Begin constructing the LaTeX table string
  latex_table <- paste(
    "\\begin{table}[H]\n",
    "\t\\centering\n",
    "\t\\caption{Treatment/Control",
    if(t3) " in T3", # Add 'in T3' if 't3' parameter is TRUE
    " -- according to the nearest point ", if(owner) "on the country's proprietary backbone}\n", 
    if(!owner) "on the backbone within the country's borders}\n",
    "\t\\vspace{1ex}\n",
    "\t\t\\begin{tabular}{lccc}\n",
    "\t\t\t\\hline\\hline\n",
    "\t\t\t \\multicolumn{1}{l}{} & \\multicolumn{3}{c}{\\textbf{", within_txt, "}}\\\\\n",
    "\t\t\t& Treatment & Control & Drop \\\\\n",
    "\t\t\t\\hline\n",
    "\t\t\t\\multicolumn{1}{l}{\\textit{Panel A.}} & \\multicolumn{3}{l}{\\textit{Afrobarometer}} \\\\\n",
    row_strings[1], "\n",
    row_strings[2], "\n",
    if(!t3) row_strings[3], "\n",
    "\t\t\t\\hline\n",
    "\t\t\t\\multicolumn{1}{l}{\\textit{Panel B.}} & \\multicolumn{3}{l}{\\textit{DHS}} \\\\\n",
    row_strings[4], "\n",
    row_strings[5], "\n",
    if(!t3) row_strings[6], "\n",
    "\t\t\t\\hline\n",
    "\t\t\t\\multicolumn{1}{l}{\\textit{Panel C.}} & \\multicolumn{3}{l}{\\textit{SA-QLFS}} \\\\\n",
    row_strings[7], "\n",
    row_strings[8], "\n",
    if(!t3) row_strings[9], "\n",
    "\t\t\t\\hline\\hline\n",
    "\t\t\\end{tabular}\n",
    "\\end{table}\n", 
    sep = "")
  
  return(latex_table)
}

# Now do the same process but sub-setting the original dataframes according to T3 regression
afro <- afro %>% subset(employment != -9 & age < 65 & distance < 0.1 & !is.na(employed))
dhs <- dhs %>% subset(distance < 0.1 & !is.na(employed))
qlfs <- qlfs %>% subset(time < 20103 & distance < 0.1 & !is.na(employed))

table <- rbind(table_treatment(afro), table_treatment(dhs), table_treatment(qlfs)) # drop is just 0s given subsetting

latex_owner_t3 <- to_latex(table, owner = TRUE, t3 = TRUE)
writeLines(latex_owner_t3, "internet_replication/newpackage/replies-to-replicators/02-nearest_point_country/results/Tables/treatment_owner_t3.tex")

latex_national_t3 <- to_latex(table, owner = FALSE, t3 = TRUE)
writeLines(latex_national_t3, "internet_replication/newpackage/replies-to-replicators/02-nearest_point_country/results/Tables/treatment_border_t3.tex")

