clear all

*****************AFRO**************************
* Load final Afro dataset
use "${pathdata}\afrobarometer_national.dta"

* country x time FE's
drop country_year
egen country_year = group(country year)

* Redefine treatment, connected, and grid-cell x connected FE's according to distance to national/owner backbone
* 1: Original AER distance
gen connected_og = 1 if distance <= 0.005
replace connected_og = 0 if connected_og == .
gen treatment_og = connected_og * submarines
egen grid_connect_og = group(grid10 connected_og)

* 2: Distance to the Proprietary backbone
gen connected_owner = 1 if distance_owner <= 0.005
replace connected_owner = 0 if connected_owner == .
gen treatment_owner = connected_owner * submarines
egen grid_connect_owner = group(grid10 connected_owner)

* 3: Distance to the National backbone (within borders)
gen connected_national = 1 if distance_national <= 0.005
replace connected_national = 0 if connected_national == .
gen treatment_national = connected_national * submarines
egen grid_connect_national = group(grid10 connected_national)

* Run the model (from table 3) for each 1-3
* 1
areg employed treatment_og i.country_year if employment != -9 & age < 65 & distance < 0.1, a(grid_connect_og) cluster(grid10)
estadd ysumm, mean
eststo afro_og

* 2
areg employed treatment_owner i.country_year if employment != -9 & age < 65 & distance_owner < 0.1, a(grid_connect_owner) cluster(grid10)
estadd ysumm, mean
eststo afro_owner

* 3
areg employed treatment_national i.country_year if employment != -9 & age < 65 & distance_national < 0.1, a(grid_connect_national) cluster(grid10)
estadd ysumm, mean
eststo afro_national


*****************DHS**************************

* Load final DHS Dataset
use "${pathdata}\dhs_national.dta", clear

* grid size
glo	gridsize10 = 0.1 // side of each square in degrees
* generate grid cell variable
g 	latitude_grid10 = 100*${gridsize10}*round(latitude/${gridsize10})
g 	longitude_grid10 = 100*${gridsize10}*round(longitude/${gridsize10})
tostring latitude_grid10 longitude_grid10, replace force
g 	grid10 = latitude_grid10 + "_" + longitude_grid10

* country x time FE's
drop country_year
egen country_year = group(country year)

* Redefine treatment, connected, and grid-cell x connected FE's according to distance to national/owner backbone
* 1: Original AER distance
gen connected_og = 1 if distance <= 0.005
replace connected_og = 0 if connected_og == .
gen treatment_og = connected_og * submarines
egen grid_connect_og = group(grid10 connected_og)

* 2: Distance to the Proprietary backbone
gen connected_owner = 1 if distance_owner <= 0.005
replace connected_owner = 0 if connected_owner == .
gen treatment_owner = connected_owner * submarines
egen grid_connect_owner = group(grid10 connected_owner)

* 3: Distance to the National backbone (within borders)
gen connected_national = 1 if distance_national <= 0.005
replace connected_national = 0 if connected_national == .
gen treatment_national = connected_national * submarines
egen grid_connect_national = group(grid10 connected_national)

* Run the model (from table 3) for each 1-3
* 1
areg employed treatment_og i.country_year if distance < 0.1, a(grid_connect_og) cluster(grid10)
estadd ysumm, mean
eststo dhs_og

* 2
areg employed treatment_owner i.country_year if distance_owner < 0.1, a(grid_connect_owner) cluster(grid10)
estadd ysumm, mean
eststo dhs_owner

* 3
areg employed treatment_national i.country_year if distance_national < 0.1, a(grid_connect_national) cluster(grid10)
estadd ysumm, mean
eststo dhs_national


*****************QLFS**************************

* Load final QLFS dataset
use "${pathdata}\qlfs_national.dta", clear

* Redefine treatment, connected
* 1: Original AER distance
gen connected_og = 1 if distance <= 0.005
replace connected_og = 0 if connected_og == .
gen treatment_og = connected_og * submarines

* 2: Distance to the Proprietary backbone
gen connected_owner = 1 if distance_owner <= 0.005
replace connected_owner = 0 if connected_owner == .
gen treatment_owner = connected_owner * submarines

* 3: Distance to the National backbone (within borders)
gen connected_national = 1 if distance_national <= 0.005
replace connected_national = 0 if connected_national == .
gen treatment_national = connected_national * submarines

* Run the model (from table 3) for each 1-4
* 1
areg employed treatment_og i.time if time < 20103 & distance < 0.1, a(eacode) cluster(eacode)
estadd ysumm, mean
eststo qlfs_og

* 2
areg employed treatment_owner i.time if time < 20103 & distance_owner < 0.1, a(eacode) cluster(eacode)
estadd ysumm, mean
eststo qlfs_owner

* 3
areg employed treatment_national i.time if time < 20103 & distance_national < 0.1, a(eacode) cluster(eacode)
estadd ysumm, mean
eststo qlfs_national


* Export results
esttab afro_og afro_owner afro_national dhs_og dhs_owner dhs_national qlfs_og qlfs_owner qlfs_national using "${pathtab}\t3_national.tex", replace se b(3) stats(N ymean, fmt(0  %9.2f)  labels("Observations" "Mean of Outcome")) label alignment(center) nogaps fragment nonumbers mlabels(none) drop(*year* *time* _cons) collabels() nocon starlevels(* 0.10 ** 0.05 *** 0.01) nolines rename(treatment_og "HP2019Distance" treatment_owner "OwnerDistance" treatment_national "NationalDistance")
