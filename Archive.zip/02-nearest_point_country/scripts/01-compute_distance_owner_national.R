# Compute the distance to the closest cable by country owner/surface

# Clean env. and set directory
rm(list=ls())
setwd("C:/Users/emiliogu/Dropbox") # DropBox folder
#setwd("C:/Users/giaco/DropBox (UCL)") # DropBox folder

# Load required packages
library(sf)
library(haven)
library(dplyr)
library(rnaturalearth)
library(rnaturalearthdata)

# Load highest possible resolution polygon of world countries
world <- ne_countries(scale = 10, returnclass = "sf")
world$postal <- ifelse(world$postal == "DRC", "CD", world$postal)

# Load network
terrestrial <- st_read("internet_replication/newpackage/replies-to-replicators/02-nearest_point_country/raw_data/ss_cables.shp")

# Load final datasets
afro <- read_dta("internet_replication/newpackage/replies-to-replicators/02-nearest_point_country/raw_data/afro_res_final.dta")
dhs <- read_dta("internet_replication/newpackage/replies-to-replicators/02-nearest_point_country/raw_data/dhs_res_final.dta")
qlfs <- read_dta("internet_replication/newpackage/replies-to-replicators/02-nearest_point_country/raw_data/qlfs_final.dta")

# To ease computations drop points with same longitude and latitude (distance will be the same)
afro_coords <- afro[!duplicated(afro[, c("longitude", "latitude")]), c("country", "longitude", "latitude", "distance")]
dhs_coords <- dhs[!duplicated(dhs[, c("longitude", "latitude")]), c("country", "longitude", "latitude", "distance")]
qlfs_coords <- qlfs[!duplicated(qlfs[, c("longitude", "latitude")]), c("country", "longitude", "latitude", "distance")]

# Construct function to compute distance to nearest cable - with country = country of cable owner
distance_within_owner <- function(data, network) {
  # Check if the dataset is qlfs
  if (deparse(substitute(data)) == "qlfs") {
    network <- network[network$country == "ZA",]
    data_geometry <- st_as_sf(data, coords = c("longitude", "latitude"))
    st_crs(network) <- NA
    dist_matrix <- st_distance(data_geometry, network$geometry)
    shortest_distances <- apply(dist_matrix, 1, min)
    return(shortest_distances)
  }
  
  # Initialize a vector to store results
  shortest_distances <- vector(mode = "numeric", length = nrow(data))
  
  # Convert data to SF (with CRS = NA to get angular distances)
  data_geometry <- st_as_sf(data, coords = c("longitude", "latitude"))
  st_crs(network) <- NA
  
  for(i in 1:nrow(data)){
    # Filter network based on the country of the current row in data
    network_country <- network[network$country == data$country[i],]
    
    # Check if the filtered network dataframe is empty
    if(nrow(network_country) == 0){
      # Assign NA to the shortest_distance for the current row if no data is available
      shortest_distances[i] <- NA
      next
    }
    
    # Calculate distance
    dist_matrix <- st_distance(data_geometry$geometry[i], network_country$geometry)
    shortest_distances[i] <- min(dist_matrix)
    cat("Inside loop - iteration", i, "\n")
  }
  
  return(shortest_distances)
}

# Construct function to compute distance to nearest cable - with country = country where cable lies
distance_within_borders <- function(data, network, world) {
  # Check if the dataset is qlfs
  if (deparse(substitute(data)) == "qlfs") {
    network <- st_intersection(network, world[world$postal == "ZA",])
    data_geometry <- st_as_sf(data, coords = c("longitude", "latitude"))
    st_crs(network) <- NA
    st_crs(world) <- NA
    dist_matrix <- st_distance(data_geometry, network$geometry)
    distance_vec <- apply(dist_matrix, 1, min)
    return(distance_vec)
  }
  
  # Convert data to SF (with CRS = NA to get angular distances)
  data_geometry <- st_as_sf(data, coords = c("longitude", "latitude"))
  st_crs(network) <- NA
  st_crs(world) <- NA
  
  # Initialize distance vector
  distance_vec <- vector("numeric", nrow(data))
  
  # Calculate distance for each point
  for (i in seq_len(nrow(data))) {
    
    # Subset world to the country polygon
    country_polygon <- world %>%
      filter(postal == data$country[i]) %>%
      st_geometry()
    
    # Subset the network to keep only the part intersecting the polygon
    network_subset <- st_intersection(network, country_polygon)
    
    # Compute the min. distance
    distance_vec[i] <- min(st_distance(data_geometry[i, ], network_subset))
    cat("Inside loop - iteration", i, "\n")
  }
  
  # Return distances
  return(distance_vec)
}

# Compute these various distances
afro_coords$distance_owner <- distance_within_owner(afro_coords, terrestrial) # NA for Benin since it owns no cables
afro_coords$distance_national <- distance_within_borders(afro_coords, terrestrial, world)

dhs_coords$distance_owner <- distance_within_owner(dhs_coords, terrestrial) # NA for Benin since it owns no cables
dhs_coords$distance_national <- distance_within_borders(dhs_coords, terrestrial, world)

qlfs_coords$distance_owner <- distance_within_owner(qlfs_coords, terrestrial) # NA for Benin since it owns no cables
qlfs_coords$distance_national <- distance_within_borders(qlfs_coords, terrestrial, world)

# Merge back to the original in order to save the new distances
merged_afro <- merge(afro, afro_coords)
nrow(merged_afro) == nrow(afro)
dhs_coords <- dhs_coords[,c("longitude", "latitude", "distance_owner", "distance_national")] # avoid distance, prevents perfect merge when lat & lon == 0
merged_dhs <- merge(dhs, dhs_coords)
nrow(merged_dhs) == nrow(dhs)
merged_qlfs <- merge(qlfs, qlfs_coords)
nrow(merged_qlfs) == nrow(qlfs)

# Save data with new distances
write_dta(merged_afro, "internet_replication/newpackage/replies-to-replicators/02-nearest_point_country/final/afrobarometer_national.dta")
write_dta(merged_dhs, "internet_replication/newpackage/replies-to-replicators/02-nearest_point_country/final/dhs_national.dta")
write_dta(merged_qlfs, "internet_replication/newpackage/replies-to-replicators/02-nearest_point_country/final/qlfs_national.dta")
