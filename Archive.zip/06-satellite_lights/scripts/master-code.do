*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
*------------------------------------------------------------------------------*
version 17.0
*version 18.0
clear all
macro drop _all 
cap log close

********************************************************************************
** # 0. Setting 
********************************************************************************

local PC = "EGUIO"

if "`PC'"=="EG"{
	global id = "C:\Users\ASUS\Dropbox\internet_replication\newpackage\replies-to-replicators\06-satellite_lights"
} 
if "`PC'"=="EGUIO"{
	global id = "C:\Users\emiliogu\Dropbox\internet_replication\newpackage\replies-to-replicators\06-satellite_lights"
} 

cd "${id}"
global pathdo 	   = "${id}\scripts"
global pathtemp    = "${id}\processed"
global pathout 	   = "${id}\results"
global pathfig	   = "${id}\results\Figures"
global pathtab     = "${id}\results\Tables"
global pathdataraw = "${id}\raw_data"
global pathdata    = "${id}\final"

* Folders creation
cap mkdir "${pathdo}"
cap mkdir "${pathtemp}"
cap mkdir "${pathout}"
cap mkdir "${pathfig}"
cap mkdir "${pathtab}"
cap mkdir "${pathdata}"
cap mkdir "${pathdataraw}"


********************************************************************************
* # 1.- Tables and Figures
********************************************************************************
*NOTE: The directory "C:\Program Files\R\R-4.3.2\bin\x64\R.exe" should be modified according to the location of R in the replicator's computer

* # AER lights
do "${pathdo}\01-lights_AER.do"
*produces lights_AER.dta

* # Process calibrated
shell "C:\Program Files\R\R-4.3.2\bin\x64\R.exe" CMD BATCH "${pathdo}\02-process_calibrated.R"

*# 	Lights calibrated Li
do "${pathdo}\03-lights_calibrated_Li.do"
*produces lights_calibrated_Li.dta

*# 	Lights calibrated EOG
do "${pathdo}\04-lights_calibrated_EOG.do"
*produces lights_calibrated_EOG.dta

* Table 1
do "${pathdo}\05-regressions_tab.do"
/*produces 
t9_calibrated.tex
*/
