*cd "C:\Users\giaco\Dropbox (UCL)\internet_replication\replies-to-replicators\08-satellite_ligths"
*cd "C:\Users\jacci\Dropbox\Data center\internet_replication\replies-to-replicators\08-satellite_ligths"
clear all
set more off

// Table 9 regressions
* AER data
use "${pathdata}\lights_AER", clear

areg lnlight treatment i.country_year if allcountries == 1 & distance < 0.1, a(grid_connect) cluster(grid)
estadd ysumm, mean
eststo reg1_AER

areg lnlight treatment i.country_year i.connect_year if allcountries == 1 & distance < 0.1, a(grid_connect) cluster(grid)
estadd ysumm, mean
eststo reg2_AER

* Li et al. data
use "${pathdata}\lights_calibrated_Li.dta", clear

areg lnlight treatment i.country_year if allcountries == 1 & distance < 0.1, a(grid_connect) cluster(grid)
estadd ysumm, mean
eststo reg1_Li

areg lnlight treatment i.country_year i.connect_year if allcountries == 1 & distance < 0.1, a(grid_connect) cluster(grid)
estadd ysumm, mean
eststo reg2_Li

* Earth Observation Group
use "${pathdata}\lights_calibrated_EOG.dta", replace

areg lnlight treatment i.country_year if allcountries == 1 & distance < 0.1, a(grid_connect) cluster(grid)
estadd ysumm, mean
eststo reg1_EOG

areg lnlight treatment i.country_year i.connect_year if allcountries == 1 & distance < 0.1, a(grid_connect) cluster(grid)
estadd ysumm, mean
eststo reg2_EOG

// Export AER results
label var treatment "\textit{Treatment}"

// Export all results
esttab reg1_AER reg2_AER reg1_Li reg2_Li reg1_EOG reg2_EOG using "${pathtab}\t9_calibrated.tex"  , replace se b(3) stats(N ymean, fmt(0  %9.2f)  labels("Observations" "Mean of Outcome")) label alignment(center) nogaps fragment nonumbers mlabels(none) drop(*year* *country_year* *connect_year* _cons) collabels()  nocon starlevels(* 0.10 ** 0.05 *** 0.01) nolines

