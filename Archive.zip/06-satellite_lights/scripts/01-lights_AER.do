*cd "C:\Users\giaco\Dropbox (UCL)\internet_replication"
clear all
set more off

use "${pathdataraw}\light2007.dta"
append using "${pathdataraw}\light2008.dta"
append using "${pathdataraw}\light2009.dta"
append using "${pathdataraw}\light2010.dta"
append using "${pathdataraw}\light2011.dta"
append using "${pathdataraw}\light2012.dta"
append using "${pathdataraw}\light2013.dta"

merge m:1 ID using "${pathdataraw}\light_distance.dta" // Uses the ORIGINAL light_distance.dta file from "\internet_replication\raw_data\lights"
*merge m:1 ID using "raw_data\lights\light_distance.dta"
drop _merge

* where "ID" is a pixel

merge m:1 longitude latitude using "${pathdataraw}\light_country.dta"
keep if _merge == 3
drop _merge


*** Generate additative submarine cable indicator ***
gen cable2009 = 1 if country == "Djibouti" & year >= 2009 | country == "Kenya" & year >= 2009 | country == "Mozambique" & year >= 2009 | country == "Tanzania" & year >= 2009 | country == "South Africa" & year >= 2009
replace cable2009 = 0 if cable2009 == .

gen cable2009_2 = 1 if country == "Kenya" & year >= 2009
replace cable2009_2 = 0 if cable2009_2 == .

gen cable2009_3 = 1 if country == "Mauritius" & year >= 2009
replace cable2009_3 = 0 if cable2009_3 == .

gen cable2010 = 1 if country == "Djibouti" & year >= 2010 | country == "Kenya" & year >= 2010 | country == "Comoros" & year >= 2010 | country == "Madagascar" & year >= 2010 | country == "Mozambique" & year >= 2010 | country == "Sudan" & year >= 2010 | country == "Somalia" & year >= 2010 | country == "Tanzania" & year >= 2010
replace cable2010 = 0 if cable2010 == .

gen cable2010_2 = 1 if country == "Burkina Faso" & year >= 2010 | country == "Benin" & year >= 2010 | country == "Cote d`Ivoire" & year >= 2010 | country == "Ghana" & year >= 2010 | country == "Morocco" & year >= 2010 | country == "Nigeria" & year >= 2010 | country == "Senegal" & year >= 2010 | country == "Togo" & year >= 2010
replace cable2010_2 = 0 if cable2010_2 == .

gen cable2011 = 1 if country == "Ghana" & year >= 2011 | country == "Morocco" & year >= 2011 | country == "Mauritania" & year >= 2011 | country == "Nigeria" & year >= 2011 | country == "Senegal" & year >= 2011
replace cable2011 = 0 if cable2011 == .

gen cable2012 = 1 if country == "Kenya" & year >= 2012
replace cable2012 = 0 if cable2012 == .

gen cable2012_2 = 1 if country == "Kenya" & year >= 2012 | country == "Rwanda" & year >= 2012 | country == "Uganda" & year >= 2012 | country == "South Africa" & year >= 2012 | country == "Zimbabwe" & year >= 2012
replace cable2012_2 = 0 if cable2012_2 == .

gen cable2012_3 = 1 if country == "Angola" & year >= 2012 | country == "Democratic Republic of Congo" & year >= 2012 | country == "Congo-Brazzaville" & year >= 2012 | country == "Cote d`Ivoire" & year >= 2012 | country == "Cameroon" & year >= 2012 | country == "Cape Verde" & year >= 2012 | country == "Gabon" & year >= 2012 | country == "Ghana" & year >= 2012 | country == "Namibia" & year >= 2012 | country == "Nigeria" & year >= 2012 | country == "Togo" & year >= 2012
replace cable2012_3 = 0 if cable2012_3 == .

gen cable2012_4 = 1 if country == "Angola" & year >= 2012 | country == "Benin" & year >= 2012 | country == "Democratic Republic of Congo" & year >= 2012 | country == "Cote d`Ivoire" & year >= 2012 | country == "Cameroon" & year >= 2012 | country == "Gabon" & year >= 2012 | country == "Ghana" & year >= 2012 | country == "Gambia" & year >= 2012 | country == "Guinea" & year >= 2012 | country == "Equatorial Guinea" & year >= 2012 | country == "Liberia" & year >= 2012 | country == "Mauritania" & year >= 2012 | country == "Mauritania" & year >= 2012 | country == "Namibia" & year >= 2012 | country == "Nigeria" & year >= 2012 | country == "Sierra Leone" & year >= 2012 | country == "Senegal" & year >= 2012 | country == "Sao Tome and Principe" & year >= 2012
replace cable2012_4 = 0 if cable2012_4 == .

*** Lead ***
gen cable2009_lead = 1 if country == "Djibouti" & year >= 2009 + 1 | country == "Kenya" & year >= 2009 + 1 | country == "Mozambique" & year >= 2009 + 1 | country == "Tanzania" & year >= 2009 + 1 | country == "South Africa" & year >= 2009 + 1
replace cable2009_lead = 0 if cable2009_lead == .

gen cable2009_2_lead = 1 if country == "Kenya" & year >= 2009 + 1
replace cable2009_2_lead = 0 if cable2009_2_lead == .

gen cable2009_3_lead = 1 if country == "Mauritius" & year >= 2009 + 1
replace cable2009_3_lead = 0 if cable2009_3_lead == .

gen cable2010_lead = 1 if country == "Djibouti" & year >= 2010 + 1 | country == "Kenya" & year >= 2010 + 1 | country == "Comoros" & year >= 2010 + 1 | country == "Madagascar" & year >= 2010 + 1 | country == "Mozambique" & year >= 2010 + 1 | country == "Sudan" & year >= 2010 + 1 | country == "Somalia" & year >= 2010 + 1 | country == "Tanzania" & year >= 2010 + 1
replace cable2010_lead = 0 if cable2010_lead == .

gen cable2010_2_lead = 1 if country == "Burkina Faso" & year >= 2010 + 1 | country == "Benin" & year >= 2010 + 1 | country == "Cote d`Ivoire" & year >= 2010 + 1 | country == "Ghana" & year >= 2010 + 1 | country == "Morocco" & year >= 2010 + 1 | country == "Nigeria" & year >= 2010 + 1 | country == "Senegal" & year >= 2010 + 1 | country == "Togo" & year >= 2010 + 1
replace cable2010_2_lead = 0 if cable2010_2_lead == .

gen cable2011_lead = 1 if country == "Ghana" & year >= 2011 + 1 | country == "Morocco" & year >= 2011 + 1 | country == "Mauritania" & year >= 2011 + 1 | country == "Nigeria" & year >= 2011 + 1 | country == "Senegal" & year >= 2011 + 1
replace cable2011_lead = 0 if cable2011_lead == .

gen cable2012_lead = 1 if country == "Kenya" & year >= 2012 + 1
replace cable2012_lead = 0 if cable2012_lead == .

gen cable2012_2_lead = 1 if country == "Kenya" & year >= 2012 + 1 | country == "Rwanda" & year >= 2012 + 1 | country == "Uganda" & year >= 2012 + 1 | country == "South Africa" & year >= 2012 + 1 | country == "Zimbabwe" & year >= 2012 + 1
replace cable2012_2_lead = 0 if cable2012_2_lead == .

gen cable2012_3_lead = 1 if country == "Angola" & year >= 2012 + 1 | country == "Democratic Republic of Congo" & year >= 2012 + 1 | country == "Congo-Brazzaville" & year >= 2012 + 1 | country == "Cote d`Ivoire" & year >= 2012 + 1 | country == "Cameroon" & year >= 2012 + 1 | country == "Cape Verde" & year >= 2012 + 1 | country == "Gabon" & year >= 2012 + 1 | country == "Ghana" & year >= 2012 + 1 | country == "Namibia" & year >= 2012 + 1 | country == "Nigeria" & year >= 2012 + 1 | country == "Togo" & year >= 2012 + 1
replace cable2012_3_lead = 0 if cable2012_3_lead == .

gen cable2012_4_lead = 1 if country == "Angola" & year >= 2012 + 1 | country == "Benin" & year >= 2012 + 1 | country == "Democratic Republic of Congo" & year >= 2012 + 1 | country == "Cote d`Ivoire" & year >= 2012 + 1 | country == "Cameroon" & year >= 2012 + 1 | country == "Gabon" & year >= 2012 + 1 | country == "Ghana" & year >= 2012 + 1 | country == "Gambia" & year >= 2012 + 1 | country == "Guinea" & year >= 2012 + 1 | country == "Equatorial Guinea" & year >= 2012 + 1 | country == "Liberia" & year >= 2012 + 1 | country == "Mauritania" & year >= 2012 + 1 | country == "Mauritania" & year >= 2012 + 1 | country == "Namibia" & year >= 2012 + 1 | country == "Nigeria" & year >= 2012 + 1 | country == "Sierra Leone" & year >= 2012 + 1 | country == "Senegal" & year >= 2012 + 1 | country == "Sao Tome and Principe" & year >= 2012 + 1
replace cable2012_4_lead = 0 if cable2012_4_lead == .

*** Lag ***
gen cable2009_lag = 1 if country == "Djibouti" & year >= 2009 - 1 | country == "Kenya" & year >= 2009 - 1 | country == "Mozambique" & year >= 2009 - 1 | country == "Tanzania" & year >= 2009 - 1 | country == "South Africa" & year >= 2009 - 1
replace cable2009_lag = 0 if cable2009_lag == .

gen cable2009_2_lag = 1 if country == "Kenya" & year >= 2009 - 1
replace cable2009_2_lag = 0 if cable2009_2_lag == .

gen cable2009_3_lag = 1 if country == "Mauritius" & year >= 2009 - 1
replace cable2009_3_lag = 0 if cable2009_3_lag == .

gen cable2010_lag = 1 if country == "Djibouti" & year >= 2010 - 1 | country == "Kenya" & year >= 2010 - 1 | country == "Comoros" & year >= 2010 - 1 | country == "Madagascar" & year >= 2010 - 1 | country == "Mozambique" & year >= 2010 - 1 | country == "Sudan" & year >= 2010 - 1 | country == "Somalia" & year >= 2010 - 1 | country == "Tanzania" & year >= 2010 - 1
replace cable2010_lag = 0 if cable2010_lag == .

gen cable2010_2_lag = 1 if country == "Burkina Faso" & year >= 2010 - 1 | country == "Benin" & year >= 2010 - 1 | country == "Cote d`Ivoire" & year >= 2010 - 1 | country == "Ghana" & year >= 2010 - 1 | country == "Morocco" & year >= 2010 - 1 | country == "Nigeria" & year >= 2010 - 1 | country == "Senegal" & year >= 2010 - 1 | country == "Togo" & year >= 2010 - 1
replace cable2010_2_lag = 0 if cable2010_2_lag == .

gen cable2011_lag = 1 if country == "Ghana" & year >= 2011 - 1 | country == "Morocco" & year >= 2011 - 1 | country == "Mauritania" & year >= 2011 - 1 | country == "Nigeria" & year >= 2011 - 1 | country == "Senegal" & year >= 2011 - 1
replace cable2011_lag = 0 if cable2011_lag == .

gen cable2012_lag = 1 if country == "Kenya" & year >= 2012 - 1
replace cable2012_lag = 0 if cable2012_lag == .

gen cable2012_2_lag = 1 if country == "Kenya" & year >= 2012 - 1 | country == "Rwanda" & year >= 2012 - 1 | country == "Uganda" & year >= 2012 - 1 | country == "South Africa" & year >= 2012 - 1 | country == "Zimbabwe" & year >= 2012 - 1
replace cable2012_2_lag = 0 if cable2012_2_lag == .

gen cable2012_3_lag = 1 if country == "Angola" & year >= 2012 - 1 | country == "Democratic Republic of Congo" & year >= 2012 - 1 | country == "Congo-Brazzaville" & year >= 2012 - 1 | country == "Cote d`Ivoire" & year >= 2012 - 1 | country == "Cameroon" & year >= 2012 - 1 | country == "Cape Verde" & year >= 2012 - 1 | country == "Gabon" & year >= 2012 - 1 | country == "Ghana" & year >= 2012 - 1 | country == "Namibia" & year >= 2012 - 1 | country == "Nigeria" & year >= 2012 - 1 | country == "Togo" & year >= 2012 - 1
replace cable2012_3_lag = 0 if cable2012_3_lag == .

gen cable2012_4_lag = 1 if country == "Angola" & year >= 2012 - 1 | country == "Benin" & year >= 2012 - 1 | country == "Democratic Republic of Congo" & year >= 2012 - 1 | country == "Cote d`Ivoire" & year >= 2012 - 1 | country == "Cameroon" & year >= 2012 - 1 | country == "Gabon" & year >= 2012 - 1 | country == "Ghana" & year >= 2012 - 1 | country == "Gambia" & year >= 2012 - 1 | country == "Guinea" & year >= 2012 - 1 | country == "Equatorial Guinea" & year >= 2012 - 1 | country == "Liberia" & year >= 2012 - 1 | country == "Mauritania" & year >= 2012 - 1 | country == "Mauritania" & year >= 2012 - 1 | country == "Namibia" & year >= 2012 - 1 | country == "Nigeria" & year >= 2012 - 1 | country == "Sierra Leone" & year >= 2012 - 1 | country == "Senegal" & year >= 2012 - 1 | country == "Sao Tome and Principe" & year >= 2012 - 1
replace cable2012_4_lag = 0 if cable2012_4_lag == .


sort country ID year
egen submarines = rowtotal(cable2009 cable2009_2 cable2009_3 cable2010 cable2010_2 cable2011 cable2012 cable2012_2 cable2012_3 cable2012_4)
egen submarines_lag = rowtotal(cable2009_lag cable2009_2_lag cable2009_3_lag cable2010_lag cable2010_2_lag cable2011_lag cable2012_lag cable2012_2_lag cable2012_3_lag cable2012_4_lag)
egen submarines_lead = rowtotal(cable2009_lead cable2009_2_lead cable2009_3_lead cable2010_lead cable2010_2_lead cable2011_lead cable2012_lead cable2012_2_lead cable2012_3_lead cable2012_4_lead)

gen allcountries = 1 if country == "Benin" | country == "Democratic Republic of Congo" | country == "Nigeria" | country == "Namibia" | country == "Senegal" | country == "Tanzania" | country == "Togo" | country == "Ghana" | country == "Kenya" | country == "Madagascar" | country == "Mozambique" | country == "South Africa"
replace allcountries = 0 if allcountries == .

gen connected = 1 if distance <= 0.005
replace connected = 0 if connected == .
gen treatment = connected * submarines

gen lnlight = ln(light + (light^2 + 1)^(1/2))

* grid size
glo	gridsize = 0.1 // side of each square in degrees
* generate grid cell variable
g 	latitude_grid = 100*${gridsize}*round(latitude/${gridsize})
g 	longitude_grid = 100*${gridsize}*round(longitude/${gridsize})
tostring latitude_grid longitude_grid, replace force
g 	grid = latitude_grid + "_" + longitude_grid

* FEs
egen connect_year = group(connected year)
egen country_year = group(country year)
egen grid_connect = group(grid connected)

rename ID id

save "${pathdata}\lights_AER", replace

