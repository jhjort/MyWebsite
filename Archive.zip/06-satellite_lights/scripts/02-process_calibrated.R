# Clean env. and set directory
rm(list=ls())
setwd("C:/Users/emiliogu/Dropbox/internet_replication/newpackage")
#setwd("C:/Users/giaco/DropBox (UCL)/internet_replication")

# Load required libraries
library(raster)
library(sf)
library(haven)
library(dplyr)
library(rnaturalearth)
library(rnaturalearthdata)
library(rmapshaper)
library(ggplot2)

# Load network (SS2014 w/o Ghana NITA and w/o SA-DFA)
terrestrial <- st_read("replies-to-replicators/06-satellite_lights/raw_data/terrestrial_with_dbf/terrestrial.shp")#terrestrial.shx should also be in the folder for this to run!
terrestrial <- terrestrial[terrestrial$name != "",]
st_crs(terrestrial) <- NA # Set CRS to NA to get angular distances

# Load sampling points
sampling <- read_dta("replies-to-replicators/06-satellite_lights/raw_data/light_country.dta")
sampling <- st_as_sf(sampling, coords = c("longitude", "latitude"))

# Keep only sampling points in countries of analysis
sampling <- sampling %>% filter(country == "Benin" |
                                  country == "Democratic Republic of Congo" | 
                                  country == "Nigeria" | country == "Namibia" | 
                                  country == "Senegal" | country == "Tanzania" |
                                  country == "Togo" | country == "Ghana" |
                                  country == "Kenya" | country == "Madagascar" |
                                  country == "Mozambique" | country == "South Africa")

# Compute distance to nearest cable
nearest_indices <- st_nearest_feature(sampling$geometry, terrestrial$geometry) # closest neighbour
sampling$distance <- sapply(seq_along(nearest_indices), function(i) {
  st_distance(sampling$geometry[i], terrestrial$geometry[nearest_indices[i]])
})

# Input TIF for 2007--2013
# Li et al. (2020)
dir <- "replies-to-replicators/06-satellite_lights/raw_data/calibrated_data/Li et al/"
lights2007 <- raster(paste0(dir, "downsampled/calibrated_lights2007.tif"))
lights2008 <- raster(paste0(dir, "downsampled/calibrated_lights2008.tif"))
lights2009 <- raster(paste0(dir, "downsampled/calibrated_lights2009.tif"))
lights2010 <- raster(paste0(dir, "downsampled/calibrated_lights2010.tif"))
lights2011 <- raster(paste0(dir, "downsampled/calibrated_lights2011.tif"))
lights2012 <- raster(paste0(dir, "downsampled/calibrated_lights2012.tif"))
lights2013 <- raster(paste0(dir, "downsampled/calibrated_lights2013.tif"))

# Earth Obs. Group
dir_EOG <- "replies-to-replicators/06-satellite_lights/raw_data/calibrated_data/Earth Obs Group/"
lights2007_EOG <- raster(paste0(dir_EOG, "downsampled/EOG_F16_2007.tif"))
lights2008_EOG <- raster(paste0(dir_EOG, "downsampled/EOG_F16_2008.tif"))
lights2009_EOG <- raster(paste0(dir_EOG, "downsampled/EOG_F16_2009.tif"))
lights2010_EOG <- raster(paste0(dir_EOG, "downsampled/EOG_F18_2010.tif"))
lights2011_EOG <- raster(paste0(dir_EOG, "downsampled/EOG_F18_2011.tif"))
lights2012_EOG <- raster(paste0(dir_EOG, "downsampled/EOG_F18_2012.tif"))
lights2013_EOG <- raster(paste0(dir_EOG, "downsampled/EOG_F18_2013.tif"))

# Construct function to extract raster value
extractRaster <- function(raster, sampling, year) {
  # Sample Raster light value from raster
  sampling$light <- extract(raster, st_coordinates(sampling))
  
  # Add coordinates and year; drop geometry
  sampling_coords <- st_coordinates(sampling)
  sampling <- st_drop_geometry(sampling)
  sampling$longitude <- sampling_coords[,1]
  sampling$latitude <- sampling_coords[,2]
  sampling$year <- year
  
  return(sampling)
}

# Apply function to Li et al. calibrations
lights2007 <- extractRaster(lights2007, sampling, 2007)
lights2008 <- extractRaster(lights2008, sampling, 2008)
lights2009 <- extractRaster(lights2009, sampling, 2009)
lights2010 <- extractRaster(lights2010, sampling, 2010)
lights2011 <- extractRaster(lights2011, sampling, 2011)
lights2012 <- extractRaster(lights2012, sampling, 2012)
lights2013 <- extractRaster(lights2013, sampling, 2013)

# Apply function to EOG calibrations
lights2007_EOG <- extractRaster(lights2007_EOG, sampling, 2007)
lights2008_EOG <- extractRaster(lights2008_EOG, sampling, 2008)
lights2009_EOG <- extractRaster(lights2009_EOG, sampling, 2009)
lights2010_EOG <- extractRaster(lights2010_EOG, sampling, 2010)
lights2011_EOG <- extractRaster(lights2011_EOG, sampling, 2011)
lights2012_EOG <- extractRaster(lights2012_EOG, sampling, 2012)
lights2013_EOG <- extractRaster(lights2013_EOG, sampling, 2013)

# Save output for Li et al. (2020)
write_dta(lights2007, paste0(dir, "with_distance/calibrated_lights2007.dta"))
write_dta(lights2008, paste0(dir, "with_distance/calibrated_lights2008.dta"))
write_dta(lights2009, paste0(dir, "with_distance/calibrated_lights2009.dta"))
write_dta(lights2010, paste0(dir, "with_distance/calibrated_lights2010.dta"))
write_dta(lights2011, paste0(dir, "with_distance/calibrated_lights2011.dta"))
write_dta(lights2012, paste0(dir, "with_distance/calibrated_lights2012.dta"))
write_dta(lights2013, paste0(dir, "with_distance/calibrated_lights2013.dta"))


# Save output for EOG
write_dta(lights2007_EOG, paste0(dir_EOG, "with_distance/calibrated_lights2007.dta"))
write_dta(lights2008_EOG, paste0(dir_EOG, "with_distance/calibrated_lights2008.dta"))
write_dta(lights2009_EOG, paste0(dir_EOG, "with_distance/calibrated_lights2009.dta"))
write_dta(lights2010_EOG, paste0(dir_EOG, "with_distance/calibrated_lights2010.dta"))
write_dta(lights2011_EOG, paste0(dir_EOG, "with_distance/calibrated_lights2011.dta"))
write_dta(lights2012_EOG, paste0(dir_EOG, "with_distance/calibrated_lights2012.dta"))
write_dta(lights2013_EOG, paste0(dir_EOG, "with_distance/calibrated_lights2013.dta"))

# Check how distances differ when using SS2014 w/o Ghana NITA BUT w/SA-DFA
ss_cables <- st_read("replies-to-replicators/06-satellite_lights/raw_data/ss_cables.shp")
st_crs(ss_cables) <- NA # Set CRS to NA to get angular distances
nearest_indices2 <- st_nearest_feature(sampling$geometry, ss_cables$geometry) # closest neighbour
sampling$distance2 <- sapply(seq_along(nearest_indices2), function(i) {
  st_distance(sampling$geometry[i], ss_cables$geometry[nearest_indices2[i]])
})

# Assess connected/unconnected/drop status with different shapefiles
treatmentColumns <- function(data) {
  # Initialize the columns with NA values
  sampling <- st_drop_geometry(sampling)
  data$connected1 <- NA
  data$connected2 <- NA
  
  # Assign values based on the specified conditions
  data$connected1[data$distance <= 0.005] <- "Connected"
  data$connected1[data$distance > 0.005 & data$distance <= 0.1] <- "Not Connected"
  data$connected1[data$distance > 0.1] <- "Dropped"
  
  data$connected2[data$distance2 <= 0.005] <- "Connected"
  data$connected2[data$distance2 > 0.005 & data$distance2 <= 0.1] <- "Not Connected"
  data$connected2[data$distance2 > 0.1] <- "Dropped"
  
  # Return the updated dataframe
  return(data)
}
sampling_connected <- treatmentColumns(sampling)
table <- as.data.frame.matrix(table(factor(sampling_connected$connected1, levels = c("Connected", "Not Connected", "Dropped")),
                                    factor(sampling_connected$connected2, levels = c("Connected", "Not Connected", "Dropped"))))
table <- mutate_all(table, function(x) format(x, big.mark = ","))

